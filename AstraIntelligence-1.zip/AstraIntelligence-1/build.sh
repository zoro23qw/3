#!/bin/bash
# Build script for the application using webpack

echo "Building client with webpack..."
npx webpack --mode production

echo "Building server with esbuild..."
npx esbuild server/index.ts --platform=node --packages=external --bundle --format=esm --outdir=dist

echo "Build completed successfully!"

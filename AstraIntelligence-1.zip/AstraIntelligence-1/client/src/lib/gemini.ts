// Integration with Google's Generative AI (Gemini)
import { GoogleGenerativeAI } from "@google/generative-ai";
import { apiRequest } from "./queryClient";

// We'll load the API key dynamically
let genAI: GoogleGenerativeAI | null = null;

// Function to initialize the API with key from server
export async function initializeGeminiAPI() {
  try {
    const response = await apiRequest("GET", "/api/config");
    const config = await response.json();
    
    if (config.geminiApiKey) {
      genAI = new GoogleGenerativeAI(config.geminiApiKey);
      return true;
    } else {
      console.error("Gemini API key not found in server response");
      return false;
    }
  } catch (error) {
    console.error("Failed to initialize Gemini API:", error);
    return false;
  }
}

// Function to generate a synthetic dataset of customer interactions for demo purposes
export async function generateBusinessDataset(businessInfo: any, count: number = 10, language: string = 'en-IN') {
  try {
    const response = await apiRequest('POST', '/api/ai/generate-dataset', {
      businessInfo,
      count,
      language
    });

    if (!response.ok) {
      throw new Error(`Server returned ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    return data.dataset || [];
  } catch (error) {
    console.error("Error generating business dataset:", error);
    return [];
  }
}

// Function to handle customer queries using Gemini AI
export async function handleCustomerQuery(query: string, businessInfo: any, language: string = 'auto') {
  try {
    const response = await apiRequest('POST', '/api/ai/query', {
      query,
      businessInfo,
      language
    });

    if (!response.ok) {
      throw new Error(`Server returned ${response.status}: ${response.statusText}`);
    }

    const data = await response.json();
    return data.response || "I apologize, but I'm experiencing some technical difficulties at the moment.";
  } catch (error) {
    console.error("Error handling customer query:", error);
    return "I apologize, but I'm experiencing some technical difficulties at the moment. Please try again later or leave a message, and someone will get back to you.";
  }
}
import { gsap } from "gsap";

// Animations for elements coming into view
export const fadeInUp = (element: HTMLElement, delay: number = 0) => {
  gsap.fromTo(
    element,
    {
      y: 50,
      opacity: 0,
    },
    {
      y: 0,
      opacity: 1,
      duration: 0.8,
      delay,
      ease: "power2.out",
    }
  );
};

export const fadeInLeft = (element: HTMLElement, delay: number = 0) => {
  gsap.fromTo(
    element,
    {
      x: 50,
      opacity: 0,
    },
    {
      x: 0,
      opacity: 1,
      duration: 0.8,
      delay,
      ease: "power2.out",
    }
  );
};

export const fadeInRight = (element: HTMLElement, delay: number = 0) => {
  gsap.fromTo(
    element,
    {
      x: -50,
      opacity: 0,
    },
    {
      x: 0,
      opacity: 1,
      duration: 0.8,
      delay,
      ease: "power2.out",
    }
  );
};

// Create staggered animation for multiple elements
export const staggerFadeIn = (elements: HTMLElement[], stagger: number = 0.1, delay: number = 0) => {
  gsap.fromTo(
    elements,
    {
      y: 30,
      opacity: 0,
    },
    {
      y: 0,
      opacity: 1,
      duration: 0.6,
      stagger,
      delay,
      ease: "power2.out",
    }
  );
};

// Setup scroll-triggered animations
export const setupScrollAnimations = () => {
  // Fade in up elements with data-animation="fade-in-up"
  gsap.utils.toArray<HTMLElement>('[data-animation="fade-in-up"]').forEach((element) => {
    const delay = parseFloat(element.getAttribute("data-delay") || "0");
    
    gsap.fromTo(
      element,
      {
        y: 50,
        opacity: 0,
      },
      {
        y: 0,
        opacity: 1,
        duration: 0.8,
        delay,
        ease: "power2.out",
        scrollTrigger: {
          trigger: element,
          start: "top 85%",
          toggleActions: "play none none none",
        },
      }
    );
  });

  // Fade in left elements with data-animation="fade-in-left"
  gsap.utils.toArray<HTMLElement>('[data-animation="fade-in-left"]').forEach((element) => {
    const delay = parseFloat(element.getAttribute("data-delay") || "0");
    
    gsap.fromTo(
      element,
      {
        x: 50,
        opacity: 0,
      },
      {
        x: 0,
        opacity: 1,
        duration: 0.8,
        delay,
        ease: "power2.out",
        scrollTrigger: {
          trigger: element,
          start: "top 85%",
          toggleActions: "play none none none",
        },
      }
    );
  });

  // Fade in right elements with data-animation="fade-in-right"
  gsap.utils.toArray<HTMLElement>('[data-animation="fade-in-right"]').forEach((element) => {
    const delay = parseFloat(element.getAttribute("data-delay") || "0");
    
    gsap.fromTo(
      element,
      {
        x: -50,
        opacity: 0,
      },
      {
        x: 0,
        opacity: 1,
        duration: 0.8,
        delay,
        ease: "power2.out",
        scrollTrigger: {
          trigger: element,
          start: "top 85%",
          toggleActions: "play none none none",
        },
      }
    );
  });
};

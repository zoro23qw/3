// This file handles browser-based text-to-speech functionality

// List of voices for different languages
interface VoiceOption {
  name: string;
  lang: string;
  gender: 'male' | 'female';
}

// Supported languages for the application
export const SUPPORTED_LANGUAGES = [
  { code: 'en-IN', name: 'English (India)' },
  { code: 'hi-IN', name: 'Hindi' },
  { code: 'gu-IN', name: 'Gujarati' }
];

// Available connection types for phone integration
export const PHONE_CONNECTION_TYPES = [
  { id: 'twilio', name: 'Twilio', description: 'Connect using Twilio APIs (requires Twilio account)' },
  { id: 'voip', name: 'VoIP', description: 'Use Voice over IP protocols like SIP' },
  { id: 'webhook', name: 'Webhook', description: 'Connect via web hooks with your existing phone system' },
  { id: 'api', name: 'Custom API', description: 'Use your own telephony API integration' },
];

// Browser-based TTS function
export const speakText = (text: string, language: string = 'en-IN'): Promise<void> => {
  return new Promise((resolve, reject) => {
    if (!('speechSynthesis' in window)) {
      console.error('Text-to-speech not supported in this browser');
      reject(new Error('Text-to-speech not supported in this browser'));
      return;
    }

    // Cancel any ongoing speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    
    // Find the appropriate voice based on language
    let voices = window.speechSynthesis.getVoices();
    
    // If voices aren't loaded yet, wait for them
    if (voices.length === 0) {
      window.speechSynthesis.onvoiceschanged = () => {
        voices = window.speechSynthesis.getVoices();
        setVoice();
      };
    } else {
      setVoice();
    }

    function setVoice() {
      // First try to find a voice that matches the language exactly
      const exactMatch = voices.find(voice => voice.lang === language);
      
      // If no exact match, try to find a voice that starts with the language code
      const partialMatch = voices.find(voice => voice.lang.startsWith(language.split('-')[0]));
      
      // Set the best matching voice
      if (exactMatch) {
        utterance.voice = exactMatch;
      } else if (partialMatch) {
        utterance.voice = partialMatch;
      }
      
      // Set language for the utterance
      utterance.lang = language;
      
      // Set a slightly slower rate for non-English languages
      if (language !== 'en-IN') {
        utterance.rate = 0.9;
      }
      
      // Events for handling completion and errors
      utterance.onend = () => resolve();
      utterance.onerror = (event) => reject(new Error(`Speech synthesis error: ${event.error}`));
      
      // Speak the text
      window.speechSynthesis.speak(utterance);
    }
  });
};

// Get all available voices in the browser
export const getAvailableVoices = (): Promise<VoiceOption[]> => {
  return new Promise((resolve) => {
    let voices = window.speechSynthesis.getVoices();
    
    if (voices.length === 0) {
      window.speechSynthesis.onvoiceschanged = () => {
        voices = window.speechSynthesis.getVoices();
        processVoices();
      };
    } else {
      processVoices();
    }
    
    function processVoices() {
      const voiceOptions: VoiceOption[] = voices
        .filter(voice => {
          // Filter for Indian languages and English
          return (
            voice.lang.includes('en-IN') || 
            voice.lang.includes('hi-IN') || 
            voice.lang.includes('gu-IN') ||
            voice.lang.includes('en-US') // Fallback to US English if Indian English isn't available
          );
        })
        .map(voice => {
          // Determine gender based on voice name (approximation)
          const gender = voice.name.toLowerCase().includes('female') || 
                         voice.name.toLowerCase().includes('girl') ? 
                         'female' : 'male';
          
          return {
            name: voice.name,
            lang: voice.lang,
            gender
          };
        });
      
      resolve(voiceOptions);
    }
  });
};

// Connect a physical phone number to Astra Assistant
export interface PhoneConnectionConfig {
  connectionType: 'twilio' | 'voip' | 'webhook' | 'api';
  phoneNumber: string;
  accountSid?: string;
  authToken?: string;
  webhookUrl?: string;
  apiKey?: string;
  region?: string;
}

export const connectPhoneNumber = async (config: PhoneConnectionConfig): Promise<boolean> => {
  // This is a placeholder function that would be implemented to connect 
  // with actual telephony APIs in production
  console.log(`Attempting to connect phone number: ${config.phoneNumber} using ${config.connectionType}`);
  
  // In a real implementation, this would:
  // 1. Validate the connection details
  // 2. Set up the appropriate API connections
  // 3. Configure webhooks/callbacks
  // 4. Test the connection
  // 5. Return success/failure
  
  try {
    // Simulate API connection
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Log success (in a real implementation, we'd actually verify the connection)
    console.log(`Successfully connected phone number ${config.phoneNumber}`);
    return true;
  } catch (error) {
    console.error("Error connecting phone number:", error);
    return false;
  }
};

// Detect language of text (enhanced version)
export const detectLanguage = (text: string): string => {
  // Skip detection for empty text
  if (!text || text.trim().length === 0) {
    return 'en-IN'; // Default to English
  }
  
  console.log(`Detecting language for: "${text.substring(0, 50)}${text.length > 50 ? '...' : ''}"`);
  
  // Unicode ranges for script detection
  const hindiPattern = /[\u0900-\u097F]/g; // Unicode range for Hindi (Devanagari)
  const gujaratiPattern = /[\u0A80-\u0AFF]/g; // Unicode range for Gujarati
  
  // Count occurrences of each language's script characters
  const hindiMatches = text.match(hindiPattern);
  const gujaratiMatches = text.match(gujaratiPattern);
  
  const hindiCount = hindiMatches ? hindiMatches.length : 0;
  const gujaratiCount = gujaratiMatches ? gujaratiMatches.length : 0;
  
  console.log(`Script detection - Hindi characters: ${hindiCount}, Gujarati characters: ${gujaratiCount}`);
  
  // If we have actual script characters, they're the strongest signal
  if (gujaratiCount > 0 || hindiCount > 0) {
    // We favor the script with more characters
    if (gujaratiCount > hindiCount) {
      console.log('Language detected: Gujarati (by script)');
      return 'gu-IN';
    } else {
      console.log('Language detected: Hindi (by script)');
      return 'hi-IN';
    }
  }
  
  // Transliteration detection for when non-Latin scripts aren't used
  
  // Common Hindi words and phrases (transliterated)
  const hindiTransliterated = [
    'namaste', 'namaskar', 'dhanyavaad', 'shukriya', 'haan', 'nahi', 'theek hai', 'accha', 
    'bahut accha', 'kya', 'kaise', 'khana', 'pani', 'menu', 'samay', 'kitna', 'kitne', 
    'aap', 'mai', 'hum', 'kab', 'kahan', 'aaj', 'kal', 'subah', 'shaam', 'raat',
    'bhojan', 'khaana', 'peena', 'paani', 'chai', 'coffee', 'doodh', 'meetha',
    'tikha', 'namak', 'mirch', 'masala', 'roti', 'chawal', 'daal', 'sabzi'
  ];
  
  // Common Gujarati words and phrases (transliterated)
  const gujaratiTransliterated = [
    'kem cho', 'saru che', 'tamne', 'mane', 'khavanu', 'pani', 'dhanyavad', 'aabhaar',
    'namaste', 'ha', 'na', 'saru', 'kya', 'ketla', 'kyare', 'kya', 'aaje', 'kale',
    'savare', 'sanje', 'ratri', 'jaman', 'khavanu', 'pivanu', 'pani', 'cha', 'coffee', 
    'dudh', 'mithash', 'tikh', 'mith', 'marchu', 'masalo', 'rotli', 'bhaat', 'daal', 'shaak'
  ];
  
  // Convert to lowercase and tokenize
  const lowercaseText = text.toLowerCase();
  // Better tokenization to handle punctuation and different separators
  const words = lowercaseText.split(/[\s,.!?;:()\[\]{}"']+/).filter(word => word.length > 1);
  
  let hindiWordMatches = 0;
  let gujaratiWordMatches = 0;
  let matchedHindiWords: string[] = [];
  let matchedGujaratiWords: string[] = [];
  
  // Analyze each word
  for (const word of words) {
    // Check for Hindi transliterated words
    for (const hindiWord of hindiTransliterated) {
      if (word.includes(hindiWord) || (hindiWord.length > 3 && hindiWord.includes(word))) {
        hindiWordMatches++;
        matchedHindiWords.push(hindiWord);
        break; // Count each word only once
      }
    }
    
    // Check for Gujarati transliterated words
    for (const gujaratiWord of gujaratiTransliterated) {
      if (word.includes(gujaratiWord) || (gujaratiWord.length > 3 && gujaratiWord.includes(word))) {
        gujaratiWordMatches++;
        matchedGujaratiWords.push(gujaratiWord);
        break; // Count each word only once
      }
    }
  }
  
  console.log(`Transliteration detection - Hindi matches: ${hindiWordMatches}, Gujarati matches: ${gujaratiWordMatches}`);
  if (matchedHindiWords.length > 0) {
    console.log(`Hindi matched words: ${matchedHindiWords.join(', ')}`);
  }
  if (matchedGujaratiWords.length > 0) {
    console.log(`Gujarati matched words: ${matchedGujaratiWords.join(', ')}`);
  }
  
  // Apply threshold and comparison
  const CONFIDENCE_THRESHOLD = 1; // At least one match needed for confidence
  
  if (gujaratiWordMatches >= CONFIDENCE_THRESHOLD && gujaratiWordMatches > hindiWordMatches) {
    console.log('Language detected: Gujarati (by transliteration)');
    return 'gu-IN';
  } else if (hindiWordMatches >= CONFIDENCE_THRESHOLD) {
    console.log('Language detected: Hindi (by transliteration)');
    return 'hi-IN';
  }
  
  // Language identification patterns
  // Words/patterns that strongly indicate English rather than transliterated Hindi/Gujarati
  const englishPatterns = [
    'a', 'the', 'is', 'are', 'was', 'were', 'have', 'has', 'will', 'would',
    'can', 'could', 'do', 'does', 'did', 'may', 'might', 'should', 'must',
    'and', 'or', 'but', 'if', 'when', 'because', 'although', 'while',
    'table', 'reservation', 'book', 'time', 'available', 'please', 'thank',
    'menu', 'food', 'drink', 'water', 'restaurant', 'dinner', 'lunch',
    'today', 'tomorrow', 'yesterday', 'now', 'later'
  ];
  
  let englishWordMatches = 0;
  
  for (const word of words) {
    if (englishPatterns.includes(word)) {
      englishWordMatches++;
    }
  }
  
  console.log(`English word matches: ${englishWordMatches}`);
  
  // Default to English
  console.log('Language detected: English (default)');
  return 'en-IN';
};
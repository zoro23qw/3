// Import the necessary functions from the Firebase SDKs
import { initializeApp } from "firebase/app";
import { 
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  GoogleAuthProvider,
  signInWithPopup
} from "firebase/auth";

// Firebase configuration using environment variables
let firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: "",
};

// Initialize Firebase app with empty config first (will be updated later)
const app = initializeApp(firebaseConfig);

// Function to initialize Firebase with config from server
export async function initializeFirebase() {
  try {
    const response = await fetch('/api/config');
    if (!response.ok) {
      throw new Error('Failed to fetch Firebase configuration');
    }
    
    const config = await response.json();
    
    if (config.firebaseConfig) {
      // Update the app with real config
      firebaseConfig = config.firebaseConfig;
      console.log('Firebase configured successfully');
      return true;
    } else {
      console.error('Firebase configuration missing from server response');
      return false;
    }
  } catch (error) {
    console.error('Error initializing Firebase:', error);
    return false;
  }
}

// Initialize Firebase Authentication and get a reference to the service
const auth = getAuth(app);

// Google Auth Provider
const googleProvider = new GoogleAuthProvider();

// Function to sign in with Google
const signInWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result;
  } catch (error) {
    console.error("Error signing in with Google: ", error);
    throw error;
  }
};

// Export the Firebase authentication functions we'll need
export {
  auth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  updateProfile,
  signInWithGoogle,
  googleProvider,
};
import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/use-auth';
import { TutorialStep } from '@/components/ui/tutorial-card';

// Steps for the dashboard tutorial
const dashboardTutorialSteps: TutorialStep[] = [
  {
    title: "Welcome to Astra Intelligence!",
    description: "Let us guide you through your new AI voice assistant. This brief tutorial will help you get started with the key features.",
    image: "/assets/tutorial/welcome.webp"
  },
  {
    title: "Your Dashboard",
    description: "This is your command center. Here you can see call statistics, recent interactions, and quick access to all features.",
    image: "/assets/tutorial/dashboard.webp"
  },
  {
    title: "Business Setup",
    description: "Make sure to complete your business profile for optimal AI responses. The more information you provide, the better your AI assistant will perform.",
    actionLabel: "Go to Business Setup",
    action: () => window.location.href = '/business-setup'
  },
  {
    title: "Test Your Microphone",
    description: "Ensure your microphone is working properly for testing the voice assistant functionality.",
    actionLabel: "Test Microphone",
    action: () => window.location.href = '/mic-test'
  },
  {
    title: "Connect Your Phone Number",
    description: "Link your business phone number to start receiving and handling calls with AI.",
    actionLabel: "Connect Number",
    action: () => window.location.href = '/connect-number'
  },
  {
    title: "You're All Set!",
    description: "Congratulations! Your AI voice assistant is now ready to help your business. If you need help at any time, check the Settings page for additional resources.",
    image: "/assets/tutorial/complete.webp"
  }
];

// Interface for the tutorial context
interface TutorialContextType {
  showTutorial: boolean;
  startTutorial: () => void;
  completeTutorial: () => void;
  dismissTutorial: () => void;
  tutorialSteps: TutorialStep[];
}

// Create the context
const TutorialContext = createContext<TutorialContextType | null>(null);

// Custom hook to use the tutorial context
export function useTutorial() {
  const context = useContext(TutorialContext);
  if (!context) {
    throw new Error('useTutorial must be used within a TutorialProvider');
  }
  return context;
}

// Provider component
export function TutorialProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const [showTutorial, setShowTutorial] = useState(false);
  const [hasCompletedTutorial, setHasCompletedTutorial] = useState(false);
  const [tutorialSteps] = useState<TutorialStep[]>(dashboardTutorialSteps);

  // Check if user has completed tutorial
  useEffect(() => {
    if (user && user.id) {
      // First check if we have settings for this user
      apiRequest('GET', `/api/settings/${user.id}`)
        .then(response => {
          if (response.ok) {
            return response.json();
          } else if (response.status === 404) {
            // If no settings exist, create default settings
            return apiRequest('POST', '/api/settings', {
              userId: user.id,
              hasCompletedTutorial: false,
              aiResponseStyle: 'professional',
              inputLanguage: 'auto',
              outputLanguage: 'en-IN',
              autoDetectLanguage: true,
              aiCallHandlingEnabled: true,
              calendarSyncEnabled: false
            })
            .then(res => res.json());
          }
          throw new Error('Failed to get user settings');
        })
        .then(settings => {
          setHasCompletedTutorial(settings.hasCompletedTutorial);
          // Show tutorial automatically for new users
          if (!settings.hasCompletedTutorial) {
            setShowTutorial(true);
          }
        })
        .catch(error => {
          console.error('Error checking tutorial status:', error);
        });
    }
  }, [user]);

  // Function to start the tutorial
  const startTutorial = () => {
    setShowTutorial(true);
  };

  // Function to mark tutorial as completed
  const completeTutorial = () => {
    if (user && user.id) {
      apiRequest('PATCH', `/api/settings/${user.id}`, {
        hasCompletedTutorial: true
      })
      .then(() => {
        setHasCompletedTutorial(true);
        setShowTutorial(false);
      })
      .catch(error => {
        console.error('Error marking tutorial as completed:', error);
      });
    }
  };

  // Function to dismiss the tutorial without marking it as completed
  const dismissTutorial = () => {
    setShowTutorial(false);
  };

  return (
    <TutorialContext.Provider value={{
      showTutorial,
      startTutorial,
      completeTutorial,
      dismissTutorial,
      tutorialSteps
    }}>
      {children}
    </TutorialContext.Provider>
  );
}
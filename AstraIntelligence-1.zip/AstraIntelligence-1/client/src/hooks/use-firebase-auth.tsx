import { createContext, ReactNode, useContext, useEffect, useState } from "react";
import {
  useQuery,
  useMutation,
  UseMutationResult,
} from "@tanstack/react-query";
import { User as SelectUser, InsertUser } from "@shared/schema";
import { apiRequest, queryClient } from "../lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  auth, 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  signOut,
  updateProfile
} from "@/lib/firebase";
import { User as FirebaseUser } from "firebase/auth";

// Extended user type that combines our schema with Firebase auth
type AuthUser = (SelectUser | null) & {
  firebaseUser?: FirebaseUser | null;
};

interface LoginCredentials {
  email: string;
  password: string;
}

interface RegisterCredentials extends LoginCredentials {
  name: string;
  businessName?: string;
  phone?: string;
}

type AuthContextType = {
  user: AuthUser;
  isLoading: boolean;
  error: Error | null;
  loginMutation: UseMutationResult<AuthUser, Error, LoginCredentials>;
  logoutMutation: UseMutationResult<void, Error, void>;
  registerMutation: UseMutationResult<AuthUser, Error, RegisterCredentials>;
};

export const FirebaseAuthContext = createContext<AuthContextType | null>(null);

export function FirebaseAuthProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [firebaseLoading, setFirebaseLoading] = useState(true);
  const [firebaseError, setFirebaseError] = useState<Error | null>(null);

  // Setup Firebase auth state listener
  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(
      (user) => {
        setFirebaseUser(user);
        setFirebaseLoading(false);
      },
      (error) => {
        console.error("Firebase auth error:", error);
        setFirebaseError(error as Error);
        setFirebaseLoading(false);
      }
    );

    // Cleanup subscription
    return () => unsubscribe();
  }, []);

  // If we have a Firebase user, fetch the user profile from our API
  const {
    data: apiUser,
    error: apiError,
    isLoading: apiLoading,
  } = useQuery<SelectUser | undefined, Error>({
    queryKey: ["/api/firebase-user"],
    queryFn: async () => {
      try {
        if (!firebaseUser) return undefined;
        
        const token = await firebaseUser.getIdToken();
        const res = await apiRequest("GET", "/api/firebase-user", { 
          headers: { Authorization: `Bearer ${token}` } 
        });
        
        if (res.status === 404) {
          // User exists in Firebase but not in our API yet
          return undefined;
        }
        
        return await res.json();
      } catch (error) {
        console.error("Error fetching user profile:", error);
        return undefined;
      }
    },
    enabled: !!firebaseUser, // Only run this query if we have a Firebase user
  });

  // Combine Firebase and API user data
  const user: AuthUser = firebaseUser ? {
    ...(apiUser || {}),
    firebaseUser,
  } : null;

  // Determine overall loading and error state
  const isLoading = firebaseLoading || (!!firebaseUser && apiLoading);
  const error = firebaseError || apiError || null;

  // Login with Firebase auth then get user profile from API
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginCredentials) => {
      // First authenticate with Firebase
      const firebaseResult = await signInWithEmailAndPassword(
        auth,
        credentials.email,
        credentials.password
      );
      
      // Then get the user profile from our API
      const token = await firebaseResult.user.getIdToken();
      const res = await apiRequest("POST", "/api/firebase-login", { token });
      const apiUser = await res.json();
      
      return {
        ...apiUser,
        firebaseUser: firebaseResult.user,
      };
    },
    onSuccess: (user: AuthUser) => {
      queryClient.setQueryData(["/api/firebase-user"], user);
      toast({
        title: "Login successful",
        description: `Welcome back, ${user?.name || user?.firebaseUser?.displayName || 'User'}!`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Login failed",
        description: error.message || "Invalid email or password",
        variant: "destructive",
      });
    },
  });

  // Register with Firebase auth then create user profile in API
  const registerMutation = useMutation({
    mutationFn: async (userData: RegisterCredentials) => {
      // First create user in Firebase
      const firebaseResult = await createUserWithEmailAndPassword(
        auth,
        userData.email,
        userData.password
      );
      
      // Update profile with display name
      await updateProfile(firebaseResult.user, {
        displayName: userData.name,
      });
      
      // Then create the user profile in our API
      const token = await firebaseResult.user.getIdToken();
      const res = await apiRequest("POST", "/api/firebase-register", { 
        name: userData.name,
        email: userData.email,
        businessName: userData.businessName,
        phone: userData.phone,
        token, 
      });
      const apiUser = await res.json();
      
      return {
        ...apiUser,
        firebaseUser: firebaseResult.user,
      };
    },
    onSuccess: (user: AuthUser) => {
      queryClient.setQueryData(["/api/firebase-user"], user);
      toast({
        title: "Registration successful",
        description: "Your account has been created. Let's set up your AI assistant!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration failed",
        description: error.message || "Could not create your account. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Logout from Firebase auth and API
  const logoutMutation = useMutation({
    mutationFn: async () => {
      // First logout from Firebase
      await signOut(auth);
      
      // Then logout from our API
      await apiRequest("POST", "/api/logout");
    },
    onSuccess: () => {
      queryClient.setQueryData(["/api/firebase-user"], null);
      toast({
        title: "Logged out",
        description: "You have been successfully logged out.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Logout failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  return (
    <FirebaseAuthContext.Provider
      value={{
        user,
        isLoading,
        error,
        loginMutation,
        logoutMutation,
        registerMutation,
      }}
    >
      {children}
    </FirebaseAuthContext.Provider>
  );
}

export function useFirebaseAuth() {
  const context = useContext(FirebaseAuthContext);
  if (!context) {
    throw new Error("useFirebaseAuth must be used within a FirebaseAuthProvider");
  }
  return context;
}
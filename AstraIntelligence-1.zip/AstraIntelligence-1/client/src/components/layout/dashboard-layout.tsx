import React, { useEffect, useState } from "react";
import { Link, useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { useAuth } from "@/hooks/use-auth";
import {
  LayoutDashboard,
  Brain,
  Mic,
  Phone,
  Settings,
  Calendar,
  LogOut,
  Menu,
  X,
  ChevronRight
} from "lucide-react";
import GradientText from "@/components/ui/gradient-text";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

interface DashboardLayoutProps {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ 
  children, 
  title,
  subtitle
}) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [currentPath, navigate] = useLocation();
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  
  // Close sidebar on route change or window resize
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsSidebarOpen(false);
      }
    };
    
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [currentPath]);
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };
  
  // Sidebar navigation items
  const navItems = [
    { 
      icon: <LayoutDashboard size={20} />, 
      label: "Dashboard", 
      path: "/dashboard",
      color: "text-purple-500" 
    },
    { 
      icon: <Brain size={20} />, 
      label: "AI Training", 
      path: "/business-setup",
      color: "text-teal-500" 
    },
    { 
      icon: <Mic size={20} />, 
      label: "Mic Test", 
      path: "/mic-test",
      color: "text-purple-500" 
    },
    { 
      icon: <Phone size={20} />, 
      label: "Call History", 
      path: "/call-history",
      color: "text-teal-500" 
    },
    { 
      icon: <Calendar size={20} />, 
      label: "Calendar", 
      path: "/calendar",
      color: "text-purple-500" 
    },
    { 
      icon: <Settings size={20} />, 
      label: "Settings", 
      path: "/settings",
      color: "text-teal-500" 
    },
  ];
  
  return (
    <div className="min-h-screen bg-gray-900 text-gray-200">
      {/* Desktop Sidebar */}
      <aside className="fixed inset-y-0 left-0 hidden lg:flex flex-col w-64 bg-gray-800 border-r border-gray-700 z-20">
        <div className="p-4 border-b border-gray-700">
          <Link href="/dashboard">
            <div className="flex items-center cursor-pointer">
              <div className="text-2xl font-['Playfair_Display'] text-white font-bold flex items-center">
                <span className="text-purple-600 mr-1">A</span>stra <span className="text-teal-500 ml-2">Intelligence</span>
              </div>
            </div>
          </Link>
        </div>
        
        <nav className="flex-1 pt-6 px-2 space-y-1 overflow-y-auto">
          {navItems.map((item) => (
            <Link key={item.path} href={item.path}>
              <div className={cn(
                "flex items-center px-3 py-3 text-sm rounded-md group transition-colors cursor-pointer",
                currentPath === item.path
                  ? "bg-gray-700/70 text-white"
                  : "text-gray-400 hover:bg-gray-700/50 hover:text-white"
              )}>
                <div className={cn(
                  "flex-shrink-0 w-8 h-8 rounded-md flex items-center justify-center mr-3",
                  currentPath === item.path
                    ? "bg-gray-600"
                    : "bg-gray-800"
                )}>
                  <span className={item.color}>{item.icon}</span>
                </div>
                <span>{item.label}</span>
                {currentPath === item.path && (
                  <div className="ml-auto w-1.5 h-6 rounded-full bg-gradient-to-b from-purple-500 to-teal-500"></div>
                )}
              </div>
            </Link>
          ))}
        </nav>
        
        <div className="p-4 border-t border-gray-700">
          {user && (
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
                  <span className="text-sm font-medium">
                    {user.name.split(' ').map(part => part[0]).join('').toUpperCase()}
                  </span>
                </div>
              </div>
              <div className="ml-3 overflow-hidden">
                <p className="text-sm font-medium text-white truncate">{user.name}</p>
                <p className="text-xs text-gray-400 truncate">{user.businessName}</p>
              </div>
            </div>
          )}
          
          <button
            onClick={handleLogout}
            className="mt-4 w-full flex items-center px-3 py-2 text-sm text-gray-300 rounded-md hover:bg-gray-700 hover:text-white transition-colors"
          >
            <LogOut size={18} className="mr-3 text-gray-400" />
            <span>Log out</span>
          </button>
        </div>
      </aside>
      
      {/* Mobile Header */}
      <header className="lg:hidden bg-gray-800 border-b border-gray-700 fixed top-0 left-0 right-0 z-20">
        <div className="px-4 flex items-center justify-between h-16">
          <div className="flex items-center">
            <button
              onClick={() => setIsSidebarOpen(true)}
              className="text-gray-400 hover:text-white focus:outline-none"
            >
              <Menu size={24} />
            </button>
            <Link href="/dashboard">
              <div className="ml-4 text-xl font-['Playfair_Display'] text-white font-bold flex items-center cursor-pointer">
                <span className="text-purple-600 mr-1">A</span>stra
              </div>
            </Link>
          </div>
          
          {user && (
            <div className="flex items-center">
              <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
                <span className="text-xs font-medium">
                  {user.name.split(' ').map(part => part[0]).join('').toUpperCase()}
                </span>
              </div>
            </div>
          )}
        </div>
      </header>
      
      {/* Mobile Sidebar */}
      <AnimatePresence>
        {isSidebarOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="fixed inset-0 bg-black/50 z-30 lg:hidden"
              onClick={() => setIsSidebarOpen(false)}
            />
            
            <motion.aside
              initial={{ x: -300 }}
              animate={{ x: 0 }}
              exit={{ x: -300 }}
              transition={{ type: "spring", damping: 25 }}
              className="fixed inset-y-0 left-0 w-64 bg-gray-800 border-r border-gray-700 z-40 lg:hidden"
            >
              <div className="p-4 border-b border-gray-700 flex items-center justify-between">
                <Link href="/dashboard">
                  <div className="flex items-center cursor-pointer">
                    <div className="text-xl font-['Playfair_Display'] text-white font-bold flex items-center">
                      <span className="text-purple-600 mr-1">A</span>stra <span className="text-teal-500 ml-2">Intelligence</span>
                    </div>
                  </div>
                </Link>
                <button
                  onClick={() => setIsSidebarOpen(false)}
                  className="text-gray-400 hover:text-white focus:outline-none"
                >
                  <X size={20} />
                </button>
              </div>
              
              {user && (
                <div className="p-4 border-b border-gray-700">
                  <div className="flex items-center">
                    <div className="flex-shrink-0">
                      <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
                        <span className="text-sm font-medium">
                          {user.name.split(' ').map(part => part[0]).join('').toUpperCase()}
                        </span>
                      </div>
                    </div>
                    <div className="ml-3 overflow-hidden">
                      <p className="text-sm font-medium text-white truncate">{user.name}</p>
                      <p className="text-xs text-gray-400 truncate">{user.businessName}</p>
                    </div>
                  </div>
                </div>
              )}
              
              <nav className="flex-1 pt-4 px-2 space-y-1 overflow-y-auto">
                {navItems.map((item) => (
                  <Link key={item.path} href={item.path}>
                    <div 
                      className={cn(
                        "flex items-center px-3 py-3 text-sm rounded-md group transition-colors cursor-pointer",
                        currentPath === item.path
                          ? "bg-gray-700/70 text-white"
                          : "text-gray-400 hover:bg-gray-700/50 hover:text-white"
                      )}
                      onClick={() => setIsSidebarOpen(false)}
                    >
                      <div className={cn(
                        "flex-shrink-0 w-8 h-8 rounded-md flex items-center justify-center mr-3",
                        currentPath === item.path
                          ? "bg-gray-600"
                          : "bg-gray-800"
                      )}>
                        <span className={item.color}>{item.icon}</span>
                      </div>
                      <span>{item.label}</span>
                      {currentPath === item.path && (
                        <div className="ml-auto w-1.5 h-6 rounded-full bg-gradient-to-b from-purple-500 to-teal-500"></div>
                      )}
                    </div>
                  </Link>
                ))}
                
                <button
                  onClick={() => {
                    handleLogout();
                    setIsSidebarOpen(false);
                  }}
                  className="w-full flex items-center px-3 py-3 text-sm text-gray-400 rounded-md hover:bg-gray-700/50 hover:text-white transition-colors"
                >
                  <div className="flex-shrink-0 w-8 h-8 rounded-md flex items-center justify-center mr-3 bg-gray-800">
                    <LogOut size={20} className="text-gray-400" />
                  </div>
                  <span>Log out</span>
                </button>
              </nav>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
      
      {/* Content Area */}
      <main className="lg:pl-64 pt-16 lg:pt-0 min-h-screen">
        {/* Page Header */}
        <div className="bg-gray-800 border-b border-gray-700">
          <div className="py-6 px-4 sm:px-6 lg:px-8">
            <div className="flex items-center">
              <h1 className="text-2xl font-semibold text-white">{title}</h1>
              {subtitle && (
                <div className="ml-4 flex items-center text-sm text-gray-400">
                  <ChevronRight size={16} className="mx-1" />
                  <span>{subtitle}</span>
                </div>
              )}
            </div>
          </div>
        </div>
        
        {/* Page Content */}
        <div className="py-6 px-4 sm:px-6 lg:px-8">
          {children}
        </div>
      </main>
    </div>
  );
};

export default DashboardLayout;

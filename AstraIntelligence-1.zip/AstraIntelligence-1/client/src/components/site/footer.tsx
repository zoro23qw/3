import React from 'react';
import { Link } from "wouter";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-gray-900 border-t border-gray-800 relative">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 pt-12 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          <div className="col-span-1 md:col-span-2">
            <div className="text-2xl font-['SF Pro Display', 'Inter', 'sans-serif'] text-white font-extrabold tracking-tight flex items-center mb-4">
              <span className="bg-gradient-to-r from-purple-500 via-purple-600 to-indigo-600 text-transparent bg-clip-text">ASTRA</span>
              <div className="w-1 h-6 mx-2 bg-gradient-to-b from-purple-500 to-indigo-600 rounded-full opacity-80"></div>
              <span className="bg-gradient-to-r from-teal-400 via-teal-500 to-emerald-600 text-transparent bg-clip-text">INTELLIGENCE</span>
            </div>
            <p className="text-gray-400 mb-6 max-w-md">
              Fully automated AI voice assistant that integrates with your real phone number. No Twilio, no new numbers—just pure AI-powered customer service.
            </p>
            <div className="bg-gray-800 rounded-md px-4 py-3 border border-gray-700">
              <p className="text-gray-300 text-sm">
                Looking for enterprise solutions? Contact us at <span className="text-purple-400">support@astraintelligence.com</span>
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Product</h3>
            <ul className="space-y-2">
              <li><a href="#features" className="text-gray-400 hover:text-white transition-colors duration-200">Features</a></li>
              <li><a href="#pricing" className="text-gray-400 hover:text-white transition-colors duration-200">Pricing</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Integrations</a></li>
              <li><a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">Roadmap</a></li>
            </ul>
          </div>
          
          <div>
            <h3 className="text-white font-semibold mb-4">Support</h3>
            <ul className="space-y-2">
              <li><Link href="/contact-us" className="text-gray-400 hover:text-white transition-colors duration-200">Contact Us</Link></li>
              <li><Link href="/privacy-policy" className="text-gray-400 hover:text-white transition-colors duration-200">Privacy Policy</Link></li>
              <li><Link href="/terms-of-service" className="text-gray-400 hover:text-white transition-colors duration-200">Terms of Service</Link></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-500 text-sm">
            © {currentYear} Astra Intelligence. All rights reserved.
          </p>
          <div className="mt-4 md:mt-0">
            <Link href="/privacy-policy" className="text-gray-500 hover:text-white text-sm transition-colors duration-200 ml-4">Privacy</Link>
            <Link href="/terms-of-service" className="text-gray-500 hover:text-white text-sm transition-colors duration-200 ml-4">Terms</Link>
            <Link href="/contact-us" className="text-gray-500 hover:text-white text-sm transition-colors duration-200 ml-4">Contact</Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

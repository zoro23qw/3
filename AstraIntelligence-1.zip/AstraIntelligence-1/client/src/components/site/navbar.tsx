import React, { useState, useEffect } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X } from "lucide-react";
import GradientBorder from "@/components/ui/gradient-border";
import { cn } from "@/lib/utils";

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user, logoutMutation } = useAuth();
  const [location] = useLocation();

  // Check if we're on the landing page
  const isLandingPage = location === "/";

  // Handle scroll effect for transparent navbar
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 10) {
        setIsScrolled(true);
      } else {
        setIsScrolled(false);
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu when changing routes
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location]);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  // Conditionally show different menu items based on auth state
  const getLinkItems = () => {
    if (user) {
      return (
        <>
          <Link href="/dashboard">
            <div className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200 cursor-pointer">
              Dashboard
            </div>
          </Link>
          <Link href="/business-setup">
            <div className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200 cursor-pointer">
              AI Training
            </div>
          </Link>
          <Link href="/mic-test">
            <div className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200 cursor-pointer">
              Mic Test
            </div>
          </Link>
          <Link href="/call-history">
            <div className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200 cursor-pointer">
              Call History
            </div>
          </Link>
          <Link href="/settings">
            <div className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200 cursor-pointer">
              Settings
            </div>
          </Link>
          <button 
            onClick={handleLogout}
            className="ml-4 px-4 py-2 rounded-md text-sm font-medium bg-purple-700 hover:bg-purple-600 text-white transition-colors duration-200"
          >
            Logout
          </button>
        </>
      );
    }

    // For non-authenticated users on landing page
    if (isLandingPage) {
      return (
        <>
          <a href="#features" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200">
            Features
          </a>
          <a href="#how-it-works" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200">
            How It Works
          </a>
          <a href="#pricing" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200">
            Pricing
          </a>
          <a href="#faq" className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200">
            FAQ
          </a>
          <Link href="/auth">
            <div className="ml-4 px-4 py-2 rounded-md text-sm font-medium bg-purple-700 hover:bg-purple-600 text-white transition-colors duration-200 cursor-pointer">
              Login
            </div>
          </Link>
          <GradientBorder>
            <Link href="/auth">
              <div className="px-4 py-2 rounded-md text-sm font-medium bg-gray-900 text-white transition-colors duration-200 block cursor-pointer">
                Sign Up
              </div>
            </Link>
          </GradientBorder>
        </>
      );
    }

    // Default links for non-landing pages when not logged in
    return (
      <>
        <Link href="/">
          <div className="text-gray-300 hover:text-white px-3 py-2 text-sm font-medium transition-colors duration-200 cursor-pointer">
            Home
          </div>
        </Link>
        <Link href="/auth">
          <div className="ml-4 px-4 py-2 rounded-md text-sm font-medium bg-purple-700 hover:bg-purple-600 text-white transition-colors duration-200 cursor-pointer">
            Login
          </div>
        </Link>
        <GradientBorder>
          <Link href="/auth">
            <div className="px-4 py-2 rounded-md text-sm font-medium bg-gray-900 text-white transition-colors duration-200 block cursor-pointer">
              Sign Up
            </div>
          </Link>
        </GradientBorder>
      </>
    );
  };

  return (
    <nav 
      className={cn(
        "fixed top-0 w-full z-50 transition-all duration-300",
        isScrolled ? "bg-gray-900/90 border-b border-gray-800 backdrop-blur-md" : "bg-transparent"
      )}
    >
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href={user ? "/dashboard" : "/"}>
                <div className="text-2xl font-['SF Pro Display', 'Inter', 'sans-serif'] text-white font-extrabold tracking-tight flex items-center cursor-pointer">
                  <span className="bg-gradient-to-r from-purple-500 via-purple-600 to-indigo-600 text-transparent bg-clip-text">ASTRA</span>
                  <div className="w-1 h-6 mx-2 bg-gradient-to-b from-purple-500 to-indigo-600 rounded-full opacity-80"></div>
                  <span className="bg-gradient-to-r from-teal-400 via-teal-500 to-emerald-600 text-transparent bg-clip-text">INTELLIGENCE</span>
                </div>
            </Link>
          </div>
          
          {/* Desktop menu */}
          <div className="hidden md:flex md:items-center md:space-x-6">
            {getLinkItems()}
          </div>
          
          {/* Mobile menu button */}
          <div className="flex md:hidden items-center">
            <button 
              type="button" 
              className="text-gray-400 hover:text-white focus:outline-none"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? (
                <X className="h-6 w-6" />
              ) : (
                <Menu className="h-6 w-6" />
              )}
            </button>
          </div>
        </div>
      </div>
      
      {/* Mobile menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
            className="md:hidden bg-gray-900/95 backdrop-blur-md border-b border-gray-800"
          >
            <div className="px-2 pt-2 pb-4 space-y-1 sm:px-3 flex flex-col items-center">
              {user ? (
                <>
                  <Link href="/dashboard">
                    <div className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">Dashboard</div>
                  </Link>
                  <Link href="/business-setup">
                    <div className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">AI Training</div>
                  </Link>
                  <Link href="/mic-test">
                    <div className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">Mic Test</div>
                  </Link>
                  <Link href="/call-history">
                    <div className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">Call History</div>
                  </Link>
                  <Link href="/settings">
                    <div className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">Settings</div>
                  </Link>
                  <button 
                    onClick={handleLogout}
                    className="mt-4 w-full px-4 py-2 rounded-md text-sm font-medium bg-purple-700 hover:bg-purple-600 text-white"
                  >
                    Logout
                  </button>
                </>
              ) : isLandingPage ? (
                <>
                  <a href="#features" className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium">Features</a>
                  <a href="#how-it-works" className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium">How It Works</a>
                  <a href="#pricing" className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium">Pricing</a>
                  <a href="#faq" className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium">FAQ</a>
                  <Link href="/auth">
                    <div className="mt-4 w-full text-center px-4 py-2 rounded-md text-sm font-medium bg-purple-700 hover:bg-purple-600 text-white cursor-pointer">Login</div>
                  </Link>
                  <GradientBorder containerClassName="w-full mt-3">
                    <Link href="/auth">
                      <div className="w-full text-center block px-4 py-2 rounded-md text-sm font-medium bg-gray-900 text-white cursor-pointer">Sign Up</div>
                    </Link>
                  </GradientBorder>
                </>
              ) : (
                <>
                  <Link href="/">
                    <div className="text-gray-300 hover:text-white block px-3 py-2 text-base font-medium cursor-pointer">Home</div>
                  </Link>
                  <Link href="/auth">
                    <div className="mt-4 w-full text-center px-4 py-2 rounded-md text-sm font-medium bg-purple-700 hover:bg-purple-600 text-white cursor-pointer">Login</div>
                  </Link>
                  <GradientBorder containerClassName="w-full mt-3">
                    <Link href="/auth">
                      <div className="w-full text-center block px-4 py-2 rounded-md text-sm font-medium bg-gray-900 text-white cursor-pointer">Sign Up</div>
                    </Link>
                  </GradientBorder>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export default Navbar;

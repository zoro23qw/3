import React from "react";
import { motion } from "framer-motion";
import { format } from "date-fns";
import CardWithGradient from "@/components/ui/card-with-gradient";
import { Phone, User, Calendar, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

// Types for call data
export type CallType = {
  id: number;
  callerNumber: string;
  timestamp: string;
  transcription: string;
  category: string;
  status: "resolved" | "pending" | "missed";
};

interface RecentCallsProps {
  calls: CallType[];
  delay?: number;
}

const RecentCalls: React.FC<RecentCallsProps> = ({
  calls,
  delay = 0
}) => {
  // Function to get call category badge color
  const getCategoryColor = (category: string) => {
    switch (category.toLowerCase()) {
      case "appointment":
        return "bg-purple-600/20 text-purple-400";
      case "inquiry":
        return "bg-teal-500/20 text-teal-400";
      case "support":
        return "bg-blue-500/20 text-blue-400";
      case "pricing":
        return "bg-amber-500/20 text-amber-400";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };
  
  // Function to get call status badge color
  const getStatusColor = (status: "resolved" | "pending" | "missed") => {
    switch (status) {
      case "resolved":
        return "bg-green-500/20 text-green-400";
      case "pending":
        return "bg-amber-500/20 text-amber-400";
      case "missed":
        return "bg-red-500/20 text-red-400";
      default:
        return "bg-gray-500/20 text-gray-400";
    }
  };
  
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <CardWithGradient
        title="Recent Call Activity"
        color="teal"
        headerClassName="pb-2"
        contentClassName="px-0 py-0"
      >
        <div className="divide-y divide-gray-700">
          {calls.map((call, index) => {
            // Parse date
            const callDate = new Date(call.timestamp);
            
            return (
              <motion.div
                key={call.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: delay + index * 0.1 }}
                className="p-4 hover:bg-gray-700/30 transition-colors"
              >
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-teal-600/20 flex items-center justify-center flex-shrink-0">
                    <Phone className="h-5 w-5 text-teal-500" />
                  </div>
                  <div className="flex-1 overflow-hidden">
                    <div className="flex items-center justify-between mb-1">
                      <div className="font-medium text-white truncate">
                        {call.callerNumber}
                      </div>
                      <Badge 
                        variant="outline" 
                        className={cn("text-xs", getStatusColor(call.status))}
                      >
                        {call.status.charAt(0).toUpperCase() + call.status.slice(1)}
                      </Badge>
                    </div>
                    
                    <p className="text-sm text-gray-400 line-clamp-2 mb-2">
                      {call.transcription}
                    </p>
                    
                    <div className="flex items-center text-xs text-gray-500 space-x-3">
                      <div className="flex items-center">
                        <Clock className="h-3 w-3 mr-1" />
                        <span>{format(callDate, "h:mm a")}</span>
                      </div>
                      <div className="flex items-center">
                        <Calendar className="h-3 w-3 mr-1" />
                        <span>{format(callDate, "MMM d, yyyy")}</span>
                      </div>
                      <Badge className={cn("text-xs", getCategoryColor(call.category))}>
                        {call.category}
                      </Badge>
                    </div>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>
      </CardWithGradient>
    </motion.div>
  );
};

export default RecentCalls;

import React, { useState } from "react";
import { motion } from "framer-motion";
import CardWithGradient from "@/components/ui/card-with-gradient";
import { BarChart, Bar, XAxis, Tooltip, ResponsiveContainer, TooltipProps } from "recharts";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

// Types for the chart data
type ChartData = {
  name: string;
  value: number;
};

interface AnalyticsCardProps {
  title: string;
  data: ChartData[];
  timeRanges?: string[];
  barColor?: string;
  delay?: number;
}

// Custom tooltip component for the chart
const CustomTooltip = ({ active, payload, label }: TooltipProps<number, string>) => {
  if (active && payload && payload.length) {
    return (
      <Card className="bg-gray-800 border-gray-700 shadow-lg p-2 text-xs">
        <p className="text-white">{`${label}: ${payload[0].value}`}</p>
      </Card>
    );
  }

  return null;
};

const AnalyticsCard: React.FC<AnalyticsCardProps> = ({
  title,
  data,
  timeRanges = ["Daily", "Weekly", "Monthly"],
  barColor = "url(#colorGradient)",
  delay = 0
}) => {
  const [activeTimeRange, setActiveTimeRange] = useState(timeRanges[0]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <CardWithGradient
        title={title}
        headerClassName="flex justify-between items-center"
        contentClassName="pt-0"
        color="none"
      >
        <div className="flex justify-end space-x-2 mb-4">
          {timeRanges.map((range) => (
            <Button
              key={range}
              variant="ghost"
              size="sm"
              className={cn(
                "px-2 py-1 text-xs rounded",
                activeTimeRange === range
                  ? "bg-purple-600/30 text-purple-300"
                  : "bg-gray-700 text-gray-300"
              )}
              onClick={() => setActiveTimeRange(range)}
            >
              {range}
            </Button>
          ))}
        </div>
        
        <div className="h-60">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={data}
              margin={{ top: 5, right: 5, left: 5, bottom: 5 }}
            >
              <defs>
                <linearGradient id="colorGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#7c3aed" stopOpacity={0.8} />
                  <stop offset="95%" stopColor="#0ea5e9" stopOpacity={0.8} />
                </linearGradient>
              </defs>
              <XAxis 
                dataKey="name" 
                tick={{ fill: '#9ca3af', fontSize: 12 }}
                axisLine={{ stroke: '#374151' }}
                tickLine={{ stroke: '#374151' }}
              />
              <Tooltip content={<CustomTooltip />} cursor={{ fill: 'rgba(107, 114, 128, 0.1)' }} />
              <Bar 
                dataKey="value" 
                fill={barColor} 
                radius={[4, 4, 0, 0]}
                animationDuration={1500}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </CardWithGradient>
    </motion.div>
  );
};

export default AnalyticsCard;

import React from "react";
import { motion } from "framer-motion";
import CardWithGradient from "@/components/ui/card-with-gradient";
import { cn } from "@/lib/utils";

interface StatsCardProps {
  title: string;
  value: string | number;
  change?: {
    value: number;
    isPositive: boolean;
  };
  icon?: React.ReactNode;
  color?: "purple" | "teal" | "gradient";
  className?: string;
  delay?: number;
}

const StatsCard: React.FC<StatsCardProps> = ({
  title,
  value,
  change,
  icon,
  color = "purple",
  className,
  delay = 0
}) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <CardWithGradient
        color={color}
        className={cn("h-full", className)}
        contentClassName="p-5"
        icon={icon}
      >
        <div className="space-y-1">
          <p className="text-sm text-gray-400">{title}</p>
          <div className="flex items-end justify-between">
            <h3 className="text-2xl font-bold text-white">
              {value}
            </h3>
            
            {change && (
              <div className={cn(
                "text-xs flex items-center",
                change.isPositive ? "text-green-400" : "text-red-400"
              )}>
                <svg 
                  xmlns="http://www.w3.org/2000/svg" 
                  className={cn("h-4 w-4 mr-1", change.isPositive ? "" : "rotate-180")} 
                  fill="none" 
                  viewBox="0 0 24 24" 
                  stroke="currentColor"
                >
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                </svg>
                {change.value}%
              </div>
            )}
          </div>
        </div>
      </CardWithGradient>
    </motion.div>
  );
};

export default StatsCard;

import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface WaveformProps {
  isActive?: boolean;
  barCount?: number;
  color?: "purple" | "teal" | "gradient";
  height?: string;
}

const Waveform: React.FC<WaveformProps> = ({
  isActive = true,
  barCount = 10,
  color = "gradient",
  height = "60px",
}) => {
  const [bars, setBars] = useState<number[]>([]);

  useEffect(() => {
    // Generate random heights for bars
    const generateBars = () => {
      return Array.from({ length: barCount }, () => Math.random() * 100);
    };

    setBars(generateBars());

    if (isActive) {
      // Continuously update bar heights if active
      const interval = setInterval(() => {
        setBars(generateBars());
      }, 500);

      return () => clearInterval(interval);
    }
  }, [isActive, barCount]);

  // Define color classes based on prop
  const getBackgroundClass = (index: number) => {
    if (color === "purple") return "bg-purple-600";
    if (color === "teal") return "bg-teal-500";
    
    // Gradient - alternate between purple and teal
    return index % 2 === 0 ? "bg-gradient-to-t from-purple-600 to-teal-500" : "bg-gradient-to-t from-teal-500 to-purple-600";
  };

  return (
    <div className="flex justify-center items-center gap-1" style={{ height }}>
      {bars.map((height, index) => (
        <motion.div
          key={index}
          className={`w-1 rounded-full ${getBackgroundClass(index)}`}
          initial={{ height: "10%" }}
          animate={{ height: isActive ? `${height}%` : "10%" }}
          transition={{
            duration: 0.4,
            ease: "easeInOut",
            delay: index * 0.05,
          }}
        />
      ))}
    </div>
  );
};

export default Waveform;

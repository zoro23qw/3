import React from 'react';
import { cn } from '@/lib/utils';

interface GradientTextProps {
  children: React.ReactNode;
  className?: string;
}

export default function GradientText({ children, className }: GradientTextProps) {
  return (
    <span className={cn(
      "bg-gradient-to-r from-purple-600 via-indigo-500 to-teal-500 text-transparent bg-clip-text", 
      className
    )}>
      {children}
    </span>
  );
}
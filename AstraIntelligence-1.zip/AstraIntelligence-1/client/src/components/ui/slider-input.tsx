import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Slider } from "@/components/ui/slider";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";

interface SliderInputProps {
  min?: number;
  max?: number;
  defaultValue?: number[];
  step?: number;
  label?: string;
  showValue?: boolean;
  minLabel?: string;
  maxLabel?: string;
  valuePrefix?: string;
  valueSuffix?: string;
  onChange?: (value: number[]) => void;
  className?: string;
  color?: "purple" | "teal" | "gradient";
}

const SliderInput: React.FC<SliderInputProps> = ({
  min = 0,
  max = 100,
  defaultValue = [50],
  step = 1,
  label,
  showValue = true,
  minLabel,
  maxLabel,
  valuePrefix = "",
  valueSuffix = "",
  onChange,
  className,
  color = "purple"
}) => {
  const [value, setValue] = useState<number[]>(defaultValue);
  
  // Update external state when value changes
  useEffect(() => {
    if (onChange) {
      onChange(value);
    }
  }, [value, onChange]);
  
  const getSliderClass = () => {
    switch (color) {
      case "purple":
        return "bg-purple-600";
      case "teal":
        return "bg-teal-500";
      case "gradient":
        return "bg-gradient-to-r from-purple-600 to-teal-500";
      default:
        return "bg-purple-600";
    }
  };
  
  const getBadgeClass = () => {
    switch (color) {
      case "purple":
        return "bg-purple-600 text-white";
      case "teal":
        return "bg-teal-500 text-white";
      case "gradient":
        return "bg-gradient-to-r from-purple-600 to-teal-500 text-white";
      default:
        return "bg-purple-600 text-white";
    }
  };

  return (
    <div className={cn("space-y-3", className)}>
      {label && (
        <div className="flex items-center justify-between">
          <label className="text-sm font-medium text-gray-300">{label}</label>
          {showValue && (
            <motion.div
              key={value[0]}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              className={cn("px-2 py-1 rounded-full text-xs font-medium", getBadgeClass())}
            >
              {valuePrefix}{value[0]}{valueSuffix}
            </motion.div>
          )}
        </div>
      )}
      
      <Slider
        defaultValue={defaultValue}
        min={min}
        max={max}
        step={step}
        onValueChange={setValue}
        className={getSliderClass()}
      />
      
      {(minLabel || maxLabel) && (
        <div className="flex justify-between">
          {minLabel && <span className="text-xs text-gray-400">{minLabel}</span>}
          {maxLabel && <span className="text-xs text-gray-400">{maxLabel}</span>}
        </div>
      )}
    </div>
  );
};

export default SliderInput;

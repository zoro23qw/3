import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { X, ChevronRight, ChevronLeft, CheckCircle2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

export type TutorialStep = {
  title: string;
  description: string;
  image?: string;
  actionLabel?: string;
  action?: () => void;
};

interface TutorialCardProps {
  steps: TutorialStep[];
  onComplete: () => void;
  onDismiss: () => void;
  className?: string;
}

export function TutorialCard({ steps, onComplete, onDismiss, className }: TutorialCardProps) {
  const [currentStep, setCurrentStep] = useState(0);
  const [completed, setCompleted] = useState<boolean[]>(steps.map(() => false));
  const { toast } = useToast();

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCompleted(prev => {
        const newCompleted = [...prev];
        newCompleted[currentStep] = true;
        return newCompleted;
      });
      setCurrentStep(prev => prev + 1);
    } else {
      handleComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleComplete = () => {
    setCompleted(prev => {
      const newCompleted = [...prev];
      newCompleted[currentStep] = true;
      return newCompleted.map(() => true);
    });
    
    toast({
      title: "Tutorial completed!",
      description: "You're all set to use Astra Intelligence.",
      className: "bg-gradient-to-r from-purple-500 to-teal-500 text-white border-none",
    });
    
    onComplete();
  };

  const handleAction = () => {
    const currentStepData = steps[currentStep];
    if (currentStepData.action) {
      currentStepData.action();
      
      // Mark this step as completed when the action is performed
      setCompleted(prev => {
        const newCompleted = [...prev];
        newCompleted[currentStep] = true;
        return newCompleted;
      });
    }
  };

  return (
    <Card className={cn(
      "p-6 shadow-lg border-t-4 border-t-purple-500 max-w-2xl w-full bg-background/95 backdrop-blur-sm",
      className
    )}>
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-semibold">Tutorial ({currentStep + 1}/{steps.length})</h3>
        <Button variant="ghost" size="icon" onClick={onDismiss}>
          <X className="h-4 w-4" />
        </Button>
      </div>

      <div className="mb-4 w-full bg-gray-200 dark:bg-gray-700 h-1 rounded-full">
        <div 
          className="bg-gradient-to-r from-purple-500 to-teal-500 h-1 rounded-full transition-all duration-300"
          style={{ width: `${((currentStep + 1) / steps.length) * 100}%` }}
        />
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentStep}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -10 }}
          transition={{ duration: 0.3 }}
          className="mb-6"
        >
          <h4 className="text-xl font-semibold mb-2 text-gradient bg-gradient-to-r from-purple-500 to-teal-500 bg-clip-text text-transparent">
            {steps[currentStep].title}
          </h4>
          <p className="text-muted-foreground mb-4">{steps[currentStep].description}</p>
          
          {steps[currentStep].image && (
            <div className="mb-4 rounded-lg overflow-hidden border border-border">
              <img 
                src={steps[currentStep].image} 
                alt={steps[currentStep].title} 
                className="w-full object-cover"
              />
            </div>
          )}
          
          {steps[currentStep].action && (
            <Button
              onClick={handleAction}
              variant="outline"
              className="mb-4"
              disabled={completed[currentStep]}
            >
              {completed[currentStep] ? (
                <span className="flex items-center">
                  <CheckCircle2 className="mr-2 h-4 w-4 text-green-500" />
                  Completed
                </span>
              ) : (
                steps[currentStep].actionLabel || "Take Action"
              )}
            </Button>
          )}
        </motion.div>
      </AnimatePresence>

      <div className="flex justify-between">
        <Button
          variant="outline"
          onClick={handlePrevious}
          disabled={currentStep === 0}
          className="gap-1"
        >
          <ChevronLeft className="h-4 w-4" />
          Previous
        </Button>
        
        <Button
          onClick={handleNext}
          variant="default"
          className="bg-gradient-to-r from-purple-500 to-teal-500 border-none shadow-md hover:shadow-lg gap-1"
        >
          {currentStep === steps.length - 1 ? "Complete" : "Next"}
          {currentStep !== steps.length - 1 && <ChevronRight className="h-4 w-4" />}
        </Button>
      </div>
    </Card>
  );
}
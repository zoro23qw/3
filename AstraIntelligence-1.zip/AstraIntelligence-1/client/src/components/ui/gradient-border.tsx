import React from "react";
import { cn } from "@/lib/utils";

interface GradientBorderProps {
  children: React.ReactNode;
  className?: string;
  containerClassName?: string;
}

const GradientBorder: React.FC<GradientBorderProps> = ({ 
  children, 
  className,
  containerClassName
}) => {
  return (
    <div 
      className={cn(
        "relative rounded-md p-[1px] overflow-hidden", 
        "bg-gradient-to-r from-purple-600 to-teal-500",
        "before:content-[''] before:absolute before:inset-0 before:bg-gradient-to-r before:from-teal-500 before:to-purple-600 before:opacity-0 before:transition-opacity before:duration-300 hover:before:opacity-100 before:z-[-1]",
        containerClassName
      )}
    >
      {children}
    </div>
  );
};

export default GradientBorder;

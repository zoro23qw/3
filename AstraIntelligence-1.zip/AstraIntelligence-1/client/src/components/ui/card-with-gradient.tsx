import React, { ReactNode } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface CardWithGradientProps {
  className?: string;
  headerClassName?: string;
  contentClassName?: string;
  footerClassName?: string;
  title?: string | ReactNode;
  description?: string | ReactNode;
  children?: ReactNode;
  footer?: ReactNode;
  icon?: ReactNode;
  color?: "purple" | "teal" | "gradient" | "none";
  hover?: boolean;
}

const CardWithGradient: React.FC<CardWithGradientProps> = ({
  className,
  headerClassName,
  contentClassName,
  footerClassName,
  title,
  description,
  children,
  footer,
  icon,
  color = "purple",
  hover = true,
}) => {
  const getBorderClass = () => {
    switch (color) {
      case "purple":
        return "border-purple-500/30";
      case "teal":
        return "border-teal-500/30";
      case "gradient":
        return "border-gray-700 bg-gradient-to-r from-purple-500/10 to-teal-500/10";
      case "none":
      default:
        return "border-gray-700";
    }
  };
  
  const getIconClass = () => {
    switch (color) {
      case "purple":
        return "bg-purple-600/20 text-purple-500";
      case "teal":
        return "bg-teal-600/20 text-teal-500";
      case "gradient":
        return "bg-gradient-to-r from-purple-600/20 to-teal-600/20 text-white";
      case "none":
      default:
        return "bg-gray-700 text-gray-400";
    }
  };

  return (
    <Card className={cn(
      "bg-gray-800/50 border", 
      getBorderClass(),
      hover && "transition-transform duration-300 hover:scale-[1.02]",
      className
    )}>
      {(title || description || icon) && (
        <CardHeader className={cn(headerClassName)}>
          <div className="flex items-center gap-3">
            {icon && (
              <div className={cn("w-10 h-10 rounded-lg flex items-center justify-center", getIconClass())}>
                {icon}
              </div>
            )}
            <div>
              {title && (
                typeof title === "string" ? (
                  <CardTitle className="text-white">{title}</CardTitle>
                ) : (
                  title
                )
              )}
              {description && (
                typeof description === "string" ? (
                  <CardDescription className="text-gray-400">{description}</CardDescription>
                ) : (
                  description
                )
              )}
            </div>
          </div>
        </CardHeader>
      )}
      
      {children && (
        <CardContent className={cn(contentClassName)}>
          {children}
        </CardContent>
      )}
      
      {footer && (
        <CardFooter className={cn("border-t border-gray-700", footerClassName)}>
          {footer}
        </CardFooter>
      )}
    </Card>
  );
};

export default CardWithGradient;

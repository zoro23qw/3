import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import DashboardLayout from "@/components/layout/dashboard-layout";
import CardWithGradient from "@/components/ui/card-with-gradient";
import GradientText from "@/components/ui/gradient-text";
import SliderInput from "@/components/ui/slider-input";
import { CallType } from "@/components/dashboard/recent-calls";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { apiRequest, queryClient } from "@/lib/queryClient";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import {
  Phone,
  Search,
  Calendar,
  Clock,
  Mic,
  User,
  ThumbsUp,
  ThumbsDown,
  FileText,
  Star,
  Filter,
  ArrowUpDown,
  Play,
  Pause,
  Download,
  Loader2
} from "lucide-react";
import { cn } from "@/lib/utils";
import { gsap } from "gsap";

// Call Data Type
interface Call extends CallType {
  duration: string;
  aiResponseQuality: number;
  audioUrl?: string;
}

const CallHistory = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [sortBy, setSortBy] = useState<"newest" | "oldest" | "duration">("newest");
  const [categoryFilter, setCategoryFilter] = useState<string>("all");
  const [isPlaying, setIsPlaying] = useState<number | null>(null);
  const [expandedCallId, setExpandedCallId] = useState<number | null>(null);
  
  // Fetching call logs
  const { data: callLogs, isLoading } = useQuery({
    queryKey: ["/api/call-logs"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/call-logs", {
          credentials: "include",
        });
        
        if (!res.ok) {
          throw new Error("Failed to fetch call logs");
        }
        
        return await res.json();
      } catch (error) {
        console.error("Error fetching call logs:", error);
        return [];
      }
    }
  });
  
  // Example call data for demonstration
  const mockCalls: Call[] = [
    {
      id: 1,
      callerNumber: "+1 (555) 123-4567",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 2).toISOString(), // 2 hours ago
      duration: "3:42",
      transcription: "Hello, I'd like to book an appointment for next Tuesday afternoon if possible. I'm looking to discuss your premium services package. I'm thinking around 2 PM if that works.",
      category: "Appointment",
      status: "resolved",
      aiResponseQuality: 4,
      audioUrl: "https://example.com/call-recordings/123456.mp3"
    },
    {
      id: 2,
      callerNumber: "+1 (555) 987-6543",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 15).toISOString(), // 15 hours ago
      duration: "1:50",
      transcription: "I want to know more about your pricing for the monthly service plan. Does it include all the features mentioned on your website? Also, are there any discounts for annual subscriptions?",
      category: "Pricing",
      status: "resolved",
      aiResponseQuality: 5,
      audioUrl: "https://example.com/call-recordings/123457.mp3"
    },
    {
      id: 3,
      callerNumber: "+1 (555) 456-7890",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(), // 2 days ago
      duration: "4:15",
      transcription: "I'm having trouble with the product I purchased last week. The item arrived damaged and I'd like to request a replacement or refund. The order number is #A7890B.",
      category: "Support",
      status: "pending",
      aiResponseQuality: 3,
      audioUrl: "https://example.com/call-recordings/123458.mp3"
    },
    {
      id: 4,
      callerNumber: "+1 (555) 789-0123",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 3).toISOString(), // 3 days ago
      duration: "2:30",
      transcription: "I'm interested in your business consultation services. Can you tell me more about what's included and how the process works? I'd like to schedule an initial consultation.",
      category: "Inquiry",
      status: "resolved",
      aiResponseQuality: 4,
      audioUrl: "https://example.com/call-recordings/123459.mp3"
    },
    {
      id: 5,
      callerNumber: "+1 (555) 234-5678",
      timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24 * 5).toISOString(), // 5 days ago
      duration: "5:22",
      transcription: "I need to reschedule my existing appointment from Friday to sometime next week. My schedule has changed and I can no longer make it at the originally scheduled time.",
      category: "Appointment",
      status: "resolved",
      aiResponseQuality: 5,
      audioUrl: "https://example.com/call-recordings/123460.mp3"
    }
  ];
  
  // Use mockCalls only when actual data is empty
  const calls = callLogs && callLogs.length > 0 ? callLogs : mockCalls;
  
  // Apply filters based on active tab, search query, and category
  const filteredCalls = calls.filter((call) => {
    // Filter by tab (call status)
    if (activeTab !== "all" && call.status !== activeTab) return false;
    
    // Filter by search query (caller number or transcription)
    if (searchQuery && !call.callerNumber.includes(searchQuery) && 
        !call.transcription.toLowerCase().includes(searchQuery.toLowerCase())) return false;
    
    // Filter by category
    if (categoryFilter !== "all" && call.category.toLowerCase() !== categoryFilter.toLowerCase()) return false;
    
    return true;
  });
  
  // Sort the filtered calls
  const sortedCalls = [...filteredCalls].sort((a, b) => {
    switch (sortBy) {
      case "newest":
        return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
      case "oldest":
        return new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime();
      case "duration":
        // Parse duration string (e.g. "3:42" to seconds)
        const getDurationInSeconds = (duration: string) => {
          const [minutes, seconds] = duration.split(":").map(Number);
          return minutes * 60 + seconds;
        };
        return getDurationInSeconds(b.duration) - getDurationInSeconds(a.duration);
      default:
        return 0;
    }
  });
  
  // Get unique categories from calls
  const categories = ["all", ...Array.from(new Set(calls.map(call => call.category.toLowerCase())))];
  
  // Handle play/pause of call recording
  const handlePlayRecording = (callId: number) => {
    if (isPlaying === callId) {
      setIsPlaying(null);
      toast({
        title: "Playback stopped",
        description: "Call recording playback stopped",
      });
    } else {
      setIsPlaying(callId);
      toast({
        title: "Playing recording",
        description: "Call recording playback started",
      });
      
      // Simulate playback ending after 5 seconds
      setTimeout(() => {
        if (isPlaying === callId) {
          setIsPlaying(null);
        }
      }, 5000);
    }
  };
  
  // Rate AI response quality
  const handleRateResponse = async (callId: number, rating: number) => {
    try {
      toast({
        title: "Rating submitted",
        description: `You rated the AI response: ${rating}/5`,
      });
      
      // In a real implementation, this would update the rating on the server
      // const res = await apiRequest("PATCH", `/api/call-logs/${callId}/rate`, { rating });
      // queryClient.invalidateQueries({ queryKey: ["/api/call-logs"] });
    } catch (error) {
      toast({
        title: "Error submitting rating",
        description: "Failed to submit your rating. Please try again.",
        variant: "destructive",
      });
    }
  };
  
  // Expand/collapse call details
  const toggleCallDetails = (callId: number) => {
    setExpandedCallId(expandedCallId === callId ? null : callId);
  };
  
  // Animation for call quality stars
  useEffect(() => {
    gsap.fromTo(
      ".star-rating .star",
      { scale: 0.8, opacity: 0.5 },
      { 
        scale: 1, 
        opacity: 1, 
        duration: 0.3,
        stagger: 0.05,
        ease: "power2.out"
      }
    );
  }, [expandedCallId]);
  
  // Handle downloading call recording
  const handleDownloadRecording = (callId: number) => {
    toast({
      title: "Download started",
      description: "Your call recording download has started",
    });
  };

  return (
    <DashboardLayout title="Call History" subtitle="AI-Handled Calls">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <CardWithGradient
          color="purple"
          className="mb-6"
          icon={<FileText size={24} />}
          title={<GradientText className="text-xl">Call Logs & AI Responses</GradientText>}
          description="Review past customer calls handled by your AI assistant."
        >
          <div className="space-y-6">
            {/* Filters Section */}
            <div className="flex flex-col md:flex-row gap-4 items-center">
              <div className="relative flex-grow">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search by caller or content..."
                  className="pl-9 bg-gray-700 border-gray-600"
                  value={searchQuery}
                  onChange={e => setSearchQuery(e.target.value)}
                />
              </div>
              
              <div className="flex items-center gap-2 w-full md:w-auto">
                <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 w-full md:w-[180px]">
                    <div className="flex items-center">
                      <Filter className="h-4 w-4 mr-2 text-gray-400" />
                      <SelectValue placeholder="Filter by category" />
                    </div>
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    <SelectGroup>
                      <SelectLabel>Categories</SelectLabel>
                      <SelectItem value="all">All Categories</SelectItem>
                      {categories.filter(cat => cat !== "all").map(category => (
                        <SelectItem key={category} value={category}>
                          {category.charAt(0).toUpperCase() + category.slice(1)}
                        </SelectItem>
                      ))}
                    </SelectGroup>
                  </SelectContent>
                </Select>
                
                <Select value={sortBy} onValueChange={(value) => setSortBy(value as any)}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 w-full md:w-[180px]">
                    <div className="flex items-center">
                      <ArrowUpDown className="h-4 w-4 mr-2 text-gray-400" />
                      <SelectValue placeholder="Sort by" />
                    </div>
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    <SelectGroup>
                      <SelectLabel>Sort Order</SelectLabel>
                      <SelectItem value="newest">Newest First</SelectItem>
                      <SelectItem value="oldest">Oldest First</SelectItem>
                      <SelectItem value="duration">Longest Duration</SelectItem>
                    </SelectGroup>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            {/* Tabs for call status */}
            <Tabs defaultValue="all" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="bg-gray-800 border-gray-700">
                <TabsTrigger value="all" className="data-[state=active]:bg-gray-700">
                  All Calls
                </TabsTrigger>
                <TabsTrigger value="resolved" className="data-[state=active]:bg-gray-700">
                  Resolved
                </TabsTrigger>
                <TabsTrigger value="pending" className="data-[state=active]:bg-gray-700">
                  Pending
                </TabsTrigger>
                <TabsTrigger value="missed" className="data-[state=active]:bg-gray-700">
                  Missed
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="all" className="mt-4">
                {renderCallTable(sortedCalls)}
              </TabsContent>
              
              <TabsContent value="resolved" className="mt-4">
                {renderCallTable(sortedCalls)}
              </TabsContent>
              
              <TabsContent value="pending" className="mt-4">
                {renderCallTable(sortedCalls)}
              </TabsContent>
              
              <TabsContent value="missed" className="mt-4">
                {renderCallTable(sortedCalls)}
              </TabsContent>
            </Tabs>
          </div>
        </CardWithGradient>
      </motion.div>
      
      {/* Call Analytics */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.2 }}
      >
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <CardWithGradient
              color="teal"
              title="Quality Metrics"
              description="AI response quality and customer satisfaction metrics"
            >
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-gray-800/70 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-1">Average AI Rating</div>
                  <div className="text-2xl font-bold text-white">4.2/5</div>
                  <div className="flex items-center mt-2">
                    {[1, 2, 3, 4].map(i => (
                      <Star key={i} className="h-4 w-4 text-yellow-500 fill-yellow-500" />
                    ))}
                    <Star className="h-4 w-4 text-yellow-500 fill-yellow-500 opacity-20" />
                  </div>
                </div>
                
                <div className="bg-gray-800/70 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-1">Resolved Calls</div>
                  <div className="text-2xl font-bold text-white">87.3%</div>
                  <div className="w-full bg-gray-700 rounded-full h-2 mt-3">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: "87.3%" }}></div>
                  </div>
                </div>
                
                <div className="bg-gray-800/70 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-1">Avg. Call Duration</div>
                  <div className="text-2xl font-bold text-white">3:12</div>
                  <div className="text-xs text-green-400 mt-2 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                    </svg>
                    12% decrease from last month
                  </div>
                </div>
              </div>
              
              <div className="mt-6 bg-gray-800/70 rounded-lg p-4">
                <h3 className="text-white font-medium mb-3">AI Improvement Suggestions</h3>
                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-600/20 flex items-center justify-center flex-shrink-0">
                      <Mic className="h-4 w-4 text-purple-500" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-white">Add More Business Terms</h4>
                      <p className="text-xs text-gray-400 mt-1">
                        Train your AI with industry-specific terminology to improve response accuracy.
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-teal-600/20 flex items-center justify-center flex-shrink-0">
                      <FileText className="h-4 w-4 text-teal-500" />
                    </div>
                    <div>
                      <h4 className="text-sm font-medium text-white">Review Common Questions</h4>
                      <p className="text-xs text-gray-400 mt-1">
                        Analyze recent call transcripts to identify new common questions to add to your AI training.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </CardWithGradient>
          </div>
          
          <div>
            <CardWithGradient
              color="purple"
              title="Call Distribution"
              description="Overview of call categories and timing"
            >
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-white mb-2">Call Categories</h4>
                  
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-400">Appointments</span>
                        <span className="text-white">42%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: "42%" }}
                          transition={{ duration: 1 }}
                          className="bg-purple-600 h-2 rounded-full"
                        ></motion.div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-400">Inquiries</span>
                        <span className="text-white">28%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: "28%" }}
                          transition={{ duration: 1, delay: 0.1 }}
                          className="bg-teal-500 h-2 rounded-full"
                        ></motion.div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-400">Support</span>
                        <span className="text-white">18%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: "18%" }}
                          transition={{ duration: 1, delay: 0.2 }}
                          className="bg-purple-600 h-2 rounded-full"
                        ></motion.div>
                      </div>
                    </div>
                    
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="text-gray-400">Pricing</span>
                        <span className="text-white">12%</span>
                      </div>
                      <div className="w-full bg-gray-700 rounded-full h-2">
                        <motion.div
                          initial={{ width: 0 }}
                          animate={{ width: "12%" }}
                          transition={{ duration: 1, delay: 0.3 }}
                          className="bg-teal-500 h-2 rounded-full"
                        ></motion.div>
                      </div>
                    </div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h4 className="text-sm font-medium text-white mb-2">Call Time Distribution</h4>
                  <div className="bg-gray-800/70 rounded-lg p-3">
                    <div className="grid grid-cols-7 gap-1">
                      {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day, i) => (
                        <div key={day} className="text-center">
                          <div className="text-xs text-gray-400 mb-1">{day}</div>
                          <div className="flex flex-col items-center gap-1">
                            {[0, 1, 2, 3].map((block) => {
                              // Generate random intensity for the heatmap
                              const intensity = Math.floor(Math.random() * 4);
                              return (
                                <motion.div 
                                  key={`${day}-${block}`}
                                  initial={{ opacity: 0 }}
                                  animate={{ opacity: 1 }}
                                  transition={{ duration: 0.5, delay: 0.1 * i + 0.05 * block }}
                                  className={cn(
                                    "w-full h-6 rounded-sm",
                                    intensity === 0 && "bg-gray-700",
                                    intensity === 1 && "bg-purple-900/40",
                                    intensity === 2 && "bg-purple-800/60",
                                    intensity === 3 && "bg-purple-600/80"
                                  )}
                                  title={`${day} ${block * 6}:00 - ${(block + 1) * 6}:00`}
                                ></motion.div>
                              );
                            })}
                          </div>
                        </div>
                      ))}
                    </div>
                    <div className="flex justify-between text-xs text-gray-500 mt-2">
                      <span>12 AM</span>
                      <span>12 PM</span>
                      <span>12 AM</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardWithGradient>
          </div>
        </div>
      </motion.div>
    </DashboardLayout>
  );
  
  // Helper function to render the call table
  function renderCallTable(calls: Call[]) {
    if (isLoading) {
      return (
        <div className="py-10 text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto text-purple-600" />
          <p className="mt-2 text-gray-400">Loading call history...</p>
        </div>
      );
    }
    
    if (calls.length === 0) {
      return (
        <div className="py-10 text-center">
          <Phone className="h-12 w-12 mx-auto text-gray-500 mb-3" />
          <h3 className="text-xl font-semibold text-white">No calls found</h3>
          <p className="text-gray-400 mt-2">
            {searchQuery || categoryFilter !== "all" 
              ? "Try adjusting your search or filters" 
              : "When calls are received, they will appear here"}
          </p>
        </div>
      );
    }
    
    return (
      <div className="rounded-md border border-gray-700 overflow-hidden">
        <Table>
          <TableHeader className="bg-gray-800">
            <TableRow className="hover:bg-gray-800/80 border-gray-700">
              <TableHead className="w-[160px] text-gray-300">Caller</TableHead>
              <TableHead className="text-gray-300">Conversation</TableHead>
              <TableHead className="w-[100px] text-gray-300">Category</TableHead>
              <TableHead className="w-[100px] text-gray-300">Date</TableHead>
              <TableHead className="w-[80px] text-gray-300 text-right">Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {calls.map((call) => (
              <React.Fragment key={call.id}>
                <TableRow 
                  className={cn(
                    "cursor-pointer border-gray-700",
                    expandedCallId === call.id ? "bg-gray-700/50" : "hover:bg-gray-800/50"
                  )}
                  onClick={() => toggleCallDetails(call.id)}
                >
                  <TableCell className="font-medium text-white">
                    {call.callerNumber}
                  </TableCell>
                  <TableCell className="max-w-md">
                    <p className="line-clamp-2 text-gray-300">
                      {call.transcription}
                    </p>
                  </TableCell>
                  <TableCell>
                    <Badge 
                      variant="outline" 
                      className={cn(
                        "border-0",
                        call.category.toLowerCase() === "appointment" && "bg-purple-600/20 text-purple-400",
                        call.category.toLowerCase() === "inquiry" && "bg-teal-500/20 text-teal-400",
                        call.category.toLowerCase() === "support" && "bg-blue-500/20 text-blue-400",
                        call.category.toLowerCase() === "pricing" && "bg-amber-500/20 text-amber-400"
                      )}
                    >
                      {call.category}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-gray-300 text-sm">
                    {format(new Date(call.timestamp), "MMM d, yyyy")}
                  </TableCell>
                  <TableCell className="text-right">
                    <Badge 
                      variant="outline" 
                      className={cn(
                        "border-0",
                        call.status === "resolved" && "bg-green-500/20 text-green-400",
                        call.status === "pending" && "bg-amber-500/20 text-amber-400",
                        call.status === "missed" && "bg-red-500/20 text-red-400"
                      )}
                    >
                      {call.status.charAt(0).toUpperCase() + call.status.slice(1)}
                    </Badge>
                  </TableCell>
                </TableRow>
                
                {/* Expanded Details */}
                {expandedCallId === call.id && (
                  <TableRow className="border-gray-700 bg-gray-800/30">
                    <TableCell colSpan={5} className="py-4">
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        transition={{ duration: 0.3 }}
                        className="px-4"
                      >
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                          {/* Call Details */}
                          <div className="md:col-span-2 space-y-4">
                            <h4 className="text-white font-medium flex items-center">
                              <FileText className="h-4 w-4 mr-2 text-gray-400" />
                              Call Transcript
                            </h4>
                            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                              <p className="text-gray-300 whitespace-pre-line">{call.transcription}</p>
                            </div>
                            
                            {/* Playback Controls */}
                            <div className="flex flex-wrap items-center gap-3">
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="border-gray-700 hover:bg-gray-700"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handlePlayRecording(call.id);
                                }}
                              >
                                {isPlaying === call.id ? (
                                  <>
                                    <Pause className="h-4 w-4 mr-2" />
                                    Pause Recording
                                  </>
                                ) : (
                                  <>
                                    <Play className="h-4 w-4 mr-2" />
                                    Play Recording
                                  </>
                                )}
                              </Button>
                              
                              <Button 
                                size="sm" 
                                variant="outline" 
                                className="border-gray-700 hover:bg-gray-700"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDownloadRecording(call.id);
                                }}
                              >
                                <Download className="h-4 w-4 mr-2" />
                                Download
                              </Button>
                            </div>
                          </div>
                          
                          {/* Metrics */}
                          <div className="space-y-4">
                            <h4 className="text-white font-medium flex items-center">
                              <Star className="h-4 w-4 mr-2 text-gray-400" />
                              Call Metrics
                            </h4>
                            
                            <div className="bg-gray-800 rounded-lg p-4 border border-gray-700 space-y-3">
                              <div className="flex justify-between items-center">
                                <span className="text-sm text-gray-400">Duration:</span>
                                <span className="text-white font-medium flex items-center">
                                  <Clock className="h-4 w-4 mr-1 text-gray-500" />
                                  {call.duration}
                                </span>
                              </div>
                              
                              <div className="flex justify-between items-center">
                                <span className="text-sm text-gray-400">Time:</span>
                                <span className="text-white font-medium">
                                  {format(new Date(call.timestamp), "h:mm a")}
                                </span>
                              </div>
                              
                              <div className="flex justify-between items-center">
                                <span className="text-sm text-gray-400">AI Response Quality:</span>
                                <div className="star-rating flex">
                                  {[1, 2, 3, 4, 5].map(rating => (
                                    <Star 
                                      key={rating}
                                      className={cn(
                                        "h-4 w-4 star cursor-pointer transition-all", 
                                        rating <= call.aiResponseQuality 
                                          ? "text-yellow-500 fill-yellow-500" 
                                          : "text-gray-600"
                                      )}
                                      onClick={(e) => {
                                        e.stopPropagation();
                                        handleRateResponse(call.id, rating);
                                      }}
                                    />
                                  ))}
                                </div>
                              </div>
                              
                              <div className="pt-2">
                                <div className="text-sm text-gray-400 mb-1">Rate This Response:</div>
                                <div className="flex justify-between gap-2">
                                  <Button 
                                    size="sm" 
                                    variant="outline" 
                                    className="border-gray-700 hover:bg-red-900/20 hover:text-red-400 hover:border-red-900/50 w-1/2"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleRateResponse(call.id, 1);
                                    }}
                                  >
                                    <ThumbsDown className="h-4 w-4 mr-1" />
                                    Poor
                                  </Button>
                                  
                                  <Button 
                                    size="sm" 
                                    variant="outline" 
                                    className="border-gray-700 hover:bg-green-900/20 hover:text-green-400 hover:border-green-900/50 w-1/2"
                                    onClick={(e) => {
                                      e.stopPropagation();
                                      handleRateResponse(call.id, 5);
                                    }}
                                  >
                                    <ThumbsUp className="h-4 w-4 mr-1" />
                                    Good
                                  </Button>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </motion.div>
                    </TableCell>
                  </TableRow>
                )}
              </React.Fragment>
            ))}
          </TableBody>
        </Table>
      </div>
    );
  }
};

export default CallHistory;

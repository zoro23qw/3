import { Helmet } from 'react-helmet';
import Footer from '@/components/site/footer';
import Navbar from '@/components/site/navbar';

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gray-900">
      <Helmet>
        <title>Privacy Policy | Astra Intelligence</title>
      </Helmet>
      <Navbar />
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-24 text-gray-300 max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-extrabold mb-8 text-white">
          Privacy Policy
        </h1>
        
        <div className="prose prose-invert max-w-none">
          <p className="text-gray-300 text-lg mb-6">
            Last updated: April 2, 2025
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">1. Introduction</h2>
          <p>
            Astra Intelligence ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our AI voice assistant service.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">2. Information We Collect</h2>
          <p>
            We collect the following types of information:
          </p>
          <ul className="list-disc pl-6 mt-2 mb-4 space-y-2">
            <li><strong>Account Information:</strong> When you register, we collect your name, email address, business name, and phone number.</li>
            <li><strong>Voice Data:</strong> We collect and process voice recordings when you or your customers interact with our AI assistant.</li>
            <li><strong>Call Logs:</strong> We maintain records of calls handled by our system, including transcriptions, timestamps, and call metadata.</li>
            <li><strong>Business Information:</strong> We collect information about your business to properly configure the AI assistant.</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">3. How We Use Your Information</h2>
          <p>
            We use the information we collect to:
          </p>
          <ul className="list-disc pl-6 mt-2 mb-4 space-y-2">
            <li>Provide, maintain, and improve our AI voice assistant service</li>
            <li>Process and complete transactions</li>
            <li>Train and improve our AI models</li>
            <li>Respond to your inquiries and support requests</li>
            <li>Send you technical notices, updates, security alerts, and support messages</li>
            <li>Communicate with you about products, services, and events</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">4. Data Security</h2>
          <p>
            We implement appropriate technical and organizational security measures to protect your personal information from unauthorized access, disclosure, alteration, and destruction.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">5. Data Retention</h2>
          <p>
            We retain your personal information for as long as necessary to fulfill the purposes outlined in this Privacy Policy, unless a longer retention period is required or permitted by law.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">6. Your Rights</h2>
          <p>
            Depending on your location, you may have the right to:
          </p>
          <ul className="list-disc pl-6 mt-2 mb-4 space-y-2">
            <li>Access personal information we hold about you</li>
            <li>Request correction of inaccurate information</li>
            <li>Request deletion of your personal information</li>
            <li>Object to our processing of your information</li>
            <li>Request restriction of processing</li>
            <li>Request transfer of your personal information</li>
            <li>Withdraw consent</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">7. Changes to This Privacy Policy</h2>
          <p>
            We may update this Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page and updating the "Last Updated" date.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">8. Contact Us</h2>
          <p>
            If you have any questions about this Privacy Policy, please contact us at:
          </p>
          <p className="mt-2">
            <strong>Email:</strong> privacy@astraintelligence.com
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
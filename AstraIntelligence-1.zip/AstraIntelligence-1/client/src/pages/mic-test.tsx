import React, { useState, useRef, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { speakText, getAvailableVoices, SUPPORTED_LANGUAGES, detectLanguage } from "@/lib/speech";
import { handleCustomerQuery, initializeGeminiAPI, generateBusinessDataset } from "@/lib/gemini";
import { Mic, MicOff, Volume2, Phone, PhoneOff, AlertCircle, MessageCircle, Info, Settings, RefreshCw, Users, BarChart4, MessageSquare, Loader, Globe } from "lucide-react";
import GradientText from "@/components/ui/gradient-text";
import { useToast } from "@/hooks/use-toast";
import { Badge } from "@/components/ui/badge";
import CardWithGradient from "@/components/ui/card-with-gradient";
import { motion, AnimatePresence } from "framer-motion";
import { Progress } from "@/components/ui/progress";

export default function MicTest() {
  const { toast } = useToast();
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [response, setResponse] = useState("");
  const [selectedLanguage, setSelectedLanguage] = useState("en-IN");
  const [availableVoices, setAvailableVoices] = useState<any[]>([]);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [apiInitialized, setApiInitialized] = useState(false);
  const [isInitializing, setIsInitializing] = useState(true);
  const [inCall, setInCall] = useState(false);
  const [callEnded, setCallEnded] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [callDuration, setCallDuration] = useState(0);
  const [durationInterval, setDurationInterval] = useState<NodeJS.Timeout | null>(null);
  const [audioOnlyMode, setAudioOnlyMode] = useState(false);
  const [datasetGenerating, setDatasetGenerating] = useState(false);
  const [datasetProgress, setDatasetProgress] = useState(0);
  const recognitionRef = useRef<any>(null);
  const [totalCalls, setTotalCalls] = useState(0);
  const [successfulCalls, setSuccessfulCalls] = useState(0);
  const [samplePrompts, setSamplePrompts] = useState<string[]>([
    "Do you have any tables available for tonight at 8pm for 2 people?",
    "मैं शाकाहारी मेनू के बारे में जानना चाहता हूं",
    "What are your most popular dishes?",
    "क्या आप डिलीवरी करते हैं?",
    "તમારી પાસે કોઈ ખાસ ઓફર છે?",
    "Do you have gluten-free options?",
    "क्या आपके यहां बर्थडे पार्टी का आयोजन हो सकता है?"
  ]);
  
  const [businessInfo, setBusinessInfo] = useState({
    name: "Aroma Restaurant",
    industry: "Restaurant/Food",
    services: "North Indian and South Indian cuisine, catering services, takeout and delivery, private event hosting",
    businessHours: "Monday-Sunday: 11am-10pm",
    commonQuestions: "Do you take reservations?\nDo you have vegetarian options?\nHow spicy is your food?\nDo you offer delivery?\nWhat are your most popular dishes?\nAre you open on holidays?\nDo you cater events?\nDo you have parking available?",
    aiResponseStyle: "friendly"
  });
  
  // Initialize Gemini API
  useEffect(() => {
    const init = async () => {
      setIsInitializing(true);
      try {
        const success = await initializeGeminiAPI();
        setApiInitialized(success);
        if (!success) {
          toast({
            title: "API Initialization Failed",
            description: "Could not initialize the Gemini API. Some features may not work.",
            variant: "destructive",
          });
        }
      } catch (error) {
        console.error("Error initializing API:", error);
        setApiInitialized(false);
        toast({
          title: "API Initialization Error",
          description: "An error occurred while initializing the Gemini API.",
          variant: "destructive",
        });
      } finally {
        setIsInitializing(false);
      }
    };
    
    init();
  }, [toast]);

  // Handle language changes
  useEffect(() => {
    if (recognitionRef.current) {
      console.log(`Language changed to: ${selectedLanguage}`);
      
      // Update the recognition language
      recognitionRef.current.lang = selectedLanguage;
      
      // If currently listening, restart for the language change to take effect
      if (isListening) {
        try {
          // Stop and restart recognition
          recognitionRef.current.stop();
          
          // Small delay before restarting
          setTimeout(() => {
            if (recognitionRef.current && isListening) {
              recognitionRef.current.start();
              console.log(`Restarted recognition with language: ${selectedLanguage}`);
            }
          }, 300);
        } catch (error) {
          console.error("Error restarting recognition after language change:", error);
        }
      }
    }
  }, [selectedLanguage, isListening]);

  // Initialize speech recognition
  useEffect(() => {
    if (typeof window !== 'undefined') {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (SpeechRecognition) {
        // Create new recognition instance
        recognitionRef.current = new SpeechRecognition();
        recognitionRef.current.continuous = true;
        recognitionRef.current.interimResults = true;
        recognitionRef.current.lang = selectedLanguage; // Set selected language
        recognitionRef.current.maxAlternatives = 3; // Get multiple alternatives for better accuracy
        
        recognitionRef.current.onresult = (event: any) => {
          let interimTranscript = '';
          let finalTranscript = '';
          
          for (let i = event.resultIndex; i < event.results.length; i++) {
            // Get the most confident transcript from the alternatives
            const transcript = event.results[i][0].transcript;
            
            if (event.results[i].isFinal) {
              finalTranscript += transcript;
              console.log("Final transcript:", transcript);
              console.log("Confidence:", event.results[i][0].confidence);
            } else {
              interimTranscript += transcript;
            }
          }
          
          // Update transcript with final or interim results
          if (finalTranscript || interimTranscript) {
            setTranscript(prevTranscript => {
              // Add a space between existing transcript and new text
              const space = prevTranscript && (finalTranscript || interimTranscript) ? ' ' : '';
              const newText = prevTranscript + (space ? space : '') + finalTranscript + 
                (interimTranscript ? ` ${interimTranscript}` : '');
              return newText.trim();
            });
          }
          
          // Auto-generate response when there's a final transcript and we're in a call
          if (finalTranscript && inCall && !isSpeaking) {
            generateResponseForTranscript(finalTranscript);
          }
        };
        
        recognitionRef.current.onerror = (event: any) => {
          console.error('Speech recognition error', event.error);
          
          // Handle network errors by restarting recognition after a delay
          if (event.error === 'network') {
            setTimeout(() => {
              if (isListening && recognitionRef.current) {
                recognitionRef.current.start();
              }
            }, 1000);
          } else {
            // For other errors, stop listening
            setIsListening(false);
            toast({
              title: "Speech Recognition Error",
              description: `Error: ${event.error}. Please try again.`,
              variant: "destructive",
            });
          }
        };
        
        recognitionRef.current.onend = () => {
          // Auto-restart recognition if we're still supposed to be listening
          if (isListening) {
            try {
              // Use timeout to ensure the previous recognition has fully ended
              setTimeout(() => {
                if (recognitionRef.current && isListening) {
                  // Make sure to set language again before restarting
                  recognitionRef.current.lang = selectedLanguage;
                  try {
                    recognitionRef.current.start();
                    console.log("Speech recognition restarted successfully");
                  } catch (innerError) {
                    console.error("Error during delayed restart:", innerError);
                  }
                }
              }, 300); // Small delay to ensure clean restart
            } catch (error) {
              console.error("Error setting up speech recognition restart:", error);
            }
          }
        };
      } else {
        console.error('Speech recognition not supported in this browser');
        toast({
          title: "Browser Not Supported",
          description: "Speech recognition is not supported in this browser. Please use Chrome, Edge, or Safari.",
          variant: "destructive",
        });
      }
      
      // Get available voices
      getAvailableVoices().then(voices => {
        setAvailableVoices(voices);
        console.log("Available voices:", voices);
      });
    }
    
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (error) {
          console.error("Error stopping speech recognition:", error);
        }
      }
      if (durationInterval) {
        clearInterval(durationInterval);
      }
    };
  }, [isListening, inCall, isSpeaking, selectedLanguage, toast]);

  // Handle stopping speech recognition
  const stopRecognition = () => {
    try {
      // First update state, then stop recognition
      setIsListening(false);
      
      // Add a safety check to prevent errors when stopping
      setTimeout(() => {
        try {
          if (recognitionRef.current) {
            // Check if already stopped to prevent errors
            try {
              recognitionRef.current.stop();
              console.log("Speech recognition stopped successfully");
            } catch (innerError) {
              // Ignore "recognition has not started" errors
              console.log("Recognition was already stopped");
            }
          }
        } catch (error) {
          console.error("Error stopping speech recognition:", error);
        }
      }, 100);
    } catch (error) {
      console.error("Error in stopRecognition:", error);
    }
  };
  
  // Handle starting speech recognition
  const startRecognition = () => {
    try {
      if (recognitionRef.current) {
        // First try to stop any existing recognition to prevent errors
        try {
          recognitionRef.current.stop();
        } catch (stopError) {
          // Ignore errors from stopping - it might not be running
        }
        
        // Make sure to set language before starting
        recognitionRef.current.lang = selectedLanguage;
        
        // Set state first, then start recognition with a small delay
        setIsListening(true);
        setTimeout(() => {
          try {
            if (recognitionRef.current) {
              // Use another try-catch just for starting to handle this error separately
              try {
                recognitionRef.current.start();
                console.log("Speech recognition started successfully");
              } catch (startError: any) {
                // Check if it's an "already started" error, which we can ignore
                if (startError.message && startError.message.includes("already started")) {
                  console.log("Recognition was already running");
                } else {
                  // For other errors, we need to revert state
                  throw startError;
                }
              }
            }
          } catch (error) {
            console.error("Error starting speech recognition:", error);
            setIsListening(false); // Revert state on failure
            
            toast({
              title: "Recognition Error",
              description: "Failed to start speech recognition. Please try again.",
              variant: "destructive",
            });
          }
        }, 300); // Increased delay for better reliability
      }
    } catch (error) {
      console.error("Error in startRecognition:", error);
      setIsListening(false);
    }
  };

  // Toggle listening with safety check for speech recognition state
  const toggleListening = () => {
    try {
      if (isListening) {
        stopRecognition();
      } else {
        startRecognition();
      }
    } catch (error) {
      console.error("Error in toggleListening:", error);
      // Reset state to be safe
      setIsListening(false);
    }
  };

  // Handle clearing transcript
  const clearTranscript = () => {
    setTranscript("");
    setResponse("");
  };

  // Generate AI response for new transcript
  const generateResponseForTranscript = async (newTranscript: string) => {
    if (!newTranscript.trim()) return;
    
    // Detect language from transcript
    const detectedLanguage = detectLanguage(newTranscript);
    
    try {
      // Set loading state by showing intermediate message (only visible in text mode)
      if (!audioOnlyMode) {
        setResponse(prev => prev + "\n\nProcessing your request...");
      }
      
      // Get AI response using Gemini with detected language
      const aiResponse = await handleCustomerQuery(newTranscript, businessInfo, detectedLanguage);
      
      // Update response
      setResponse(aiResponse);
      
      // Don't start speaking if we're already speaking
      if (isSpeaking) {
        window.speechSynthesis.cancel();
      }
      
      // Speak the response
      setIsSpeaking(true);
      
      // Play a subtle notification sound in audio-only mode
      if (audioOnlyMode) {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const oscillator = ctx.createOscillator();
        const gainNode = ctx.createGain();
        
        oscillator.type = 'sine';
        oscillator.frequency.value = 880;
        gainNode.gain.value = 0.1;
        
        oscillator.connect(gainNode);
        gainNode.connect(ctx.destination);
        
        oscillator.start();
        setTimeout(() => oscillator.stop(), 150);
      }
      
      speakText(aiResponse, detectedLanguage)
        .then(() => setIsSpeaking(false))
        .catch(error => {
          console.error('TTS error:', error);
          setIsSpeaking(false);
          toast({
            title: "Speech Error",
            description: "There was an error with text-to-speech. Please try again.",
            variant: "destructive",
          });
        });
    } catch (error) {
      console.error('Error generating response:', error);
      setResponse("Sorry, I couldn't generate a response at the moment. Please try again.");
      
      toast({
        title: "Response Error",
        description: "Failed to generate AI response. Please check your connection.",
        variant: "destructive",
      });
    }
  };

  // Start a simulated call
  const startCall = () => {
    try {
      // Clear previous data
      clearTranscript();
      setInCall(true);
      setCallEnded(false);
      
      // Track call duration
      let duration = 0;
      const interval = setInterval(() => {
        duration += 1;
        setCallDuration(duration);
      }, 1000);
      setDurationInterval(interval);
      
      // Play a ringing sound in audio-only mode
      if (audioOnlyMode) {
        try {
          const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
          
          // Play a phone ring tone
          const playRing = () => {
            try {
              const osc = ctx.createOscillator();
              const gain = ctx.createGain();
              
              osc.type = 'sine';
              osc.frequency.value = 480;
              gain.gain.value = 0.2;
              
              osc.connect(gain);
              gain.connect(ctx.destination);
              
              osc.start();
              setTimeout(() => {
                try {
                  osc.stop();
                } catch (stopError) {
                  console.error("Error stopping oscillator:", stopError);
                }
              }, 400);
            } catch (ringError) {
              console.error("Error playing ring tone:", ringError);
            }
          };
          
          // Play ring twice with a gap
          playRing();
          setTimeout(playRing, 600);
        } catch (audioError) {
          console.error("Error initializing audio context:", audioError);
        }
      }
      
      // Safely start listening with a delay to ensure proper initialization
      setTimeout(() => {
        // Set state first
        setIsListening(true);
        
        // Then start actual recognition after a small delay
        setTimeout(() => {
          try {
            if (recognitionRef.current) {
              recognitionRef.current.lang = selectedLanguage;
              recognitionRef.current.start();
              console.log("Call started, speech recognition initialized");
            }
          } catch (error) {
            console.error("Error starting speech recognition for call:", error);
            // Don't revert isListening state as we still want the call active
          }
        }, 100);
        
        // Play welcome message after recognition starts
        setTimeout(() => {
          try {
            const businessName = businessInfo?.name || "our business";
            const welcomeMessage = `Hello, thank you for calling ${businessName}. How may I assist you today?`;
            setIsSpeaking(true);
            setResponse(welcomeMessage);
            
            speakText(welcomeMessage, selectedLanguage)
              .then(() => setIsSpeaking(false))
              .catch(error => {
                console.error('TTS error:', error);
                setIsSpeaking(false);
              });
          } catch (speechError) {
            console.error("Error in welcome message:", speechError);
            setIsSpeaking(false);
          }
        }, 800);
      }, 500);
    } catch (error) {
      console.error("Error starting call:", error);
      // Reset to safe state
      setInCall(false);
      setIsListening(false);
      setIsSpeaking(false);
      
      toast({
        title: "Call Error",
        description: "Failed to start the call. Please try again.",
        variant: "destructive",
      });
    }
  };

  // End the call
  const endCall = () => {
    try {
      // First update state to prevent UI issues
      setIsListening(false);
      setInCall(false);
      setCallEnded(true);
      
      // Stop listening with a safe approach
      setTimeout(() => {
        try {
          if (recognitionRef.current) {
            recognitionRef.current.stop();
            console.log("Speech recognition stopped for call end");
          }
        } catch (error) {
          console.error("Error stopping speech recognition on call end:", error);
        }
      }, 100);
      
      // Stop tracking duration
      if (durationInterval) {
        try {
          clearInterval(durationInterval);
          setDurationInterval(null);
        } catch (error) {
          console.error("Error clearing interval:", error);
        }
      }
      
      // Stop any speaking
      try {
        if ('speechSynthesis' in window) {
          window.speechSynthesis.cancel();
          setIsSpeaking(false);
        }
      } catch (error) {
        console.error("Error stopping speech synthesis:", error);
      }
      
      // Play an ending message after a small delay to ensure proper cleanup
      setTimeout(() => {
        try {
          const businessName = businessInfo?.name || "our business";
          const endMessage = `Thank you for calling ${businessName}. Have a great day!`;
          
          // Update the response text
          setResponse(prevResponse => `${prevResponse}\n\n${endMessage}`);
          
          // Wait a bit before starting to speak to avoid conflicts
          setTimeout(() => {
            setIsSpeaking(true);
            
            speakText(endMessage, selectedLanguage)
              .then(() => setIsSpeaking(false))
              .catch(error => {
                console.error('TTS error:', error);
                setIsSpeaking(false);
              });
          }, 300);
        } catch (speechError) {
          console.error("Error in ending message:", speechError);
        }
      }, 500);
    } catch (error) {
      console.error("Error ending call:", error);
      
      // Reset to safe state
      setInCall(false);
      setIsListening(false);
      setIsSpeaking(false);
      setCallEnded(true);
      
      // Clear interval as a safety measure
      if (durationInterval) {
        clearInterval(durationInterval);
        setDurationInterval(null);
      }
    }
  };
  
  // Generate sample dataset using Gemini
  const generateSampleDataset = async (count = 25) => {
    if (!apiInitialized) {
      toast({
        title: "API Not Initialized",
        description: "Please wait for the Gemini API to initialize before generating samples.",
        variant: "destructive",
      });
      return;
    }
    
    setDatasetGenerating(true);
    setDatasetProgress(0);
    
    toast({
      title: "Generating Dataset",
      description: `Generating ${count} sample business customer queries in ${
        selectedLanguage === "en-IN" ? "English" : 
        selectedLanguage === "hi-IN" ? "Hindi" : "Gujarati"
      }...`,
    });
    
    try {
      // For large datasets, generate in batches
      if (count > 25) {
        const batches = Math.ceil(count / 25);
        let allPrompts: string[] = [];
        
        for (let i = 0; i < batches; i++) {
          setDatasetProgress(Math.round((i / batches) * 100));
          
          // Generate a batch
          const dataset = await generateBusinessDataset(businessInfo, 25, selectedLanguage);
          
          if (dataset && Array.isArray(dataset) && dataset.length > 0) {
            // Extract and filter prompts
            const batchPrompts = dataset
              .map((item: any) => item.transcription || "")
              .filter((text: string) => text && text.length > 10 && text.length < 200);
            
            allPrompts = [...allPrompts, ...batchPrompts];
            
            // Update progress display
            setTotalCalls(prev => prev + dataset.length);
            setSuccessfulCalls(prev => prev + batchPrompts.length);
          }
        }
        
        // Limit final dataset to the requested count
        const finalPrompts = allPrompts.slice(0, count);
        
        if (finalPrompts.length > 0) {
          setSamplePrompts(finalPrompts);
          toast({
            title: "Dataset Generated",
            description: `Successfully generated ${finalPrompts.length} sample customer queries.`,
          });
        } else {
          toast({
            title: "Generation Issue",
            description: "Could not generate enough valid samples. Please try again.",
            variant: "destructive",
          });
        }
      } else {
        // For smaller datasets, generate in one request
        const dataset = await generateBusinessDataset(businessInfo, count, selectedLanguage);
        
        if (dataset && Array.isArray(dataset) && dataset.length > 0) {
          // Extract sample prompts from the dataset
          const newPrompts = dataset
            .map((item: any) => item.transcription || "")
            .filter((text: string) => text && text.length > 10 && text.length < 200);
          
          if (newPrompts.length > 0) {
            setSamplePrompts(newPrompts);
            setTotalCalls(dataset.length);
            setSuccessfulCalls(newPrompts.length);
            
            toast({
              title: "Dataset Generated",
              description: `Generated ${newPrompts.length} sample customer queries in ${
                selectedLanguage === "en-IN" ? "English" : 
                selectedLanguage === "hi-IN" ? "Hindi" : "Gujarati"
              }.`,
            });
          } else {
            toast({
              title: "No Valid Samples",
              description: "Couldn't find usable samples in the generated dataset. Please try again.",
              variant: "destructive",
            });
          }
        } else {
          toast({
            title: "Empty Dataset",
            description: "The API returned an empty dataset. Please try again.",
            variant: "destructive",
          });
        }
      }
    } catch (error) {
      console.error("Error generating dataset:", error);
      toast({
        title: "Generation Failed",
        description: "Failed to generate sample dataset. Please check your connection and try again.",
        variant: "destructive",
      });
    } finally {
      setDatasetGenerating(false);
      setDatasetProgress(100);
    }
  };
  
  // Generate a large dataset of 1000+ samples
  const generateLargeDataset = async () => {
    if (selectedLanguage === "en-IN") {
      setTotalCalls(0);
      setSuccessfulCalls(0);
      generateSampleDataset(1000);
    } else {
      // For non-English languages, generate smaller datasets to avoid overloading
      setTotalCalls(0);
      setSuccessfulCalls(0);
      generateSampleDataset(300);
    }
  };
  
  // Use a sample prompt
  const usePrompt = (prompt: string) => {
    setTranscript(prompt);
    generateResponseForTranscript(prompt);
  };

  // Format call duration
  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="container mx-auto py-8">
      <div className="max-w-4xl mx-auto space-y-8">
        <div className="text-center">
          <GradientText className="text-4xl font-bold mb-2">
            Business AI Voice Assistant
          </GradientText>
          <p className="text-muted-foreground mb-2">
            This demo shows how a customer would interact with your business when they call
          </p>
          <div className="flex flex-col items-center mb-6">
            <div className="flex items-center gap-2 mb-2">
              <Globe className="w-4 h-4 text-purple-500" />
              <span className="text-sm font-medium text-gray-300">Select Voice Assistant Language:</span>
            </div>
            <div className="flex justify-center gap-2 flex-wrap">
              {SUPPORTED_LANGUAGES.map(lang => (
                <Badge 
                  key={lang.code} 
                  variant={selectedLanguage === lang.code ? "default" : "outline"}
                  className={`cursor-pointer text-sm px-3 py-1 ${
                    selectedLanguage === lang.code 
                      ? "bg-gradient-to-r from-purple-600 to-teal-500 hover:from-purple-700 hover:to-teal-600" 
                      : "hover:bg-gray-700"
                  }`}
                  onClick={() => {
                    console.log(`Changing language to ${lang.code}`);
                    setSelectedLanguage(lang.code);
                    // Update recognition language if it's already initialized
                    if (recognitionRef.current) {
                      recognitionRef.current.lang = lang.code;
                      console.log(`Updated recognition language to ${lang.code}`);
                      
                      // If currently listening, restart recognition with new language
                      if (isListening) {
                        try {
                          recognitionRef.current.stop();
                          setTimeout(() => {
                            if (recognitionRef.current && isListening) {
                              recognitionRef.current.start();
                              console.log(`Restarted recognition with language ${lang.code}`);
                            }
                          }, 300);
                        } catch (error) {
                          console.error("Error restarting recognition with new language:", error);
                        }
                      }
                    }
                  }}
                >
                  {lang.name}
                </Badge>
              ))}
            </div>
          </div>
        </div>
        
        <div className="grid gap-6 grid-cols-1 lg:grid-cols-12">
          {/* Main call interface */}
          <div className="lg:col-span-8">
            <CardWithGradient 
              color="purple" 
              className="relative overflow-hidden"
              headerClassName="pt-6"
              title={
                <div className="flex items-center justify-between w-full">
                  <div className="flex items-center">
                    <Phone className="h-5 w-5 mr-2" />
                    <span>Business Phone Call</span>
                  </div>
                  {inCall && (
                    <Badge variant="outline" className="animate-pulse">
                      {formatDuration(callDuration)}
                    </Badge>
                  )}
                </div>
              }
            >
              <div className="flex flex-col h-[420px]">
                {/* Call visualization */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-transparent to-blue-900/5 rounded-md">
                  {isInitializing ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-primary rounded-full mr-2"></div>
                      <span>Connecting to AI services...</span>
                    </div>
                  ) : !apiInitialized ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center space-y-3">
                        <AlertCircle className="h-10 w-10 text-red-500 mx-auto" />
                        <h3 className="font-semibold text-lg">AI Service Unavailable</h3>
                        <p className="text-sm text-muted-foreground">
                          The AI service could not be initialized. Please check your internet connection and try again.
                        </p>
                      </div>
                    </div>
                  ) : !inCall && !callEnded ? (
                    <div className="flex items-center justify-center h-full">
                      <div className="text-center space-y-3">
                        <Phone className="h-12 w-12 text-green-500 mx-auto mb-4" />
                        <h3 className="font-semibold text-xl">Ready to Start a Test Call</h3>
                        <p className="text-sm text-muted-foreground max-w-md mx-auto">
                          Click "Start Call" below to simulate a customer calling your business.
                          The AI will respond to your voice just like it would on a real phone call.
                        </p>
                      </div>
                    </div>
                  ) : (
                    <>
                      {response && !audioOnlyMode && (
                        <div className="flex items-start">
                          <div className="flex items-center justify-center h-8 w-8 rounded-full bg-purple-600 text-white text-xs mr-2 flex-shrink-0 mt-1">
                            AI
                          </div>
                          <div className="bg-gray-800 rounded-lg p-3 max-w-[80%]">
                            <p className="text-gray-100">{response}</p>
                            <span className="text-xs text-gray-400 mt-1 block">
                              {inCall ? "Now" : "Call ended"}
                            </span>
                          </div>
                        </div>
                      )}
                      
                      {audioOnlyMode && isSpeaking && (
                        <div className="flex items-center justify-center">
                          <div className="bg-purple-900/20 rounded-full px-4 py-2 animate-pulse flex items-center">
                            <Volume2 className="h-4 w-4 mr-2 text-purple-400" />
                            <span className="text-purple-300 text-sm">AI Speaking...</span>
                          </div>
                        </div>
                      )}
                      
                      {transcript && (showTranscript || !audioOnlyMode) && (
                        <div className="flex items-start justify-end">
                          <div className="bg-blue-900/30 rounded-lg p-3 max-w-[80%]">
                            <p className="text-gray-100">{transcript}</p>
                            <span className="text-xs text-gray-400 mt-1 block">
                              {inCall ? "Now" : "Call ended"}
                            </span>
                          </div>
                          <div className="flex items-center justify-center h-8 w-8 rounded-full bg-blue-600 text-white text-xs ml-2 flex-shrink-0 mt-1">
                            You
                          </div>
                        </div>
                      )}
                      
                      {inCall && isListening && (
                        <div className="flex justify-center">
                          <div className="flex items-center space-x-1">
                            <span className="animate-ping inline-flex h-2 w-2 rounded-full bg-green-500 opacity-75"></span>
                            <span className="text-xs text-gray-400">Listening...</span>
                          </div>
                        </div>
                      )}
                    </>
                  )}
                </div>
                
                {/* Call controls */}
                <div className="p-4 bg-gray-800/50 border-t border-gray-700">
                  <div className="flex flex-col items-center gap-4">
                    {/* Main action button */}
                    {!inCall ? (
                      <Button
                        className="bg-green-600 hover:bg-green-700 text-white px-8 py-6 h-auto"
                        onClick={startCall}
                        disabled={isInitializing || !apiInitialized}
                      >
                        <Phone className="mr-2 h-5 w-5" />
                        Start Call
                      </Button>
                    ) : (
                      <div className="flex flex-col items-center gap-3">
                        {/* Animated microphone button */}
                        <motion.div
                          className="relative mb-2"
                          animate={isListening ? { scale: [1, 1.05, 1] } : { scale: 1 }}
                          transition={isListening ? { 
                            repeat: Infinity, 
                            duration: 1.5
                          } : {}}
                        >
                          <Button
                            variant={isListening ? "default" : "outline"}
                            className={`${isListening ? "bg-teal-600 hover:bg-teal-700" : "bg-gray-700 hover:bg-gray-600"} rounded-full h-16 w-16 p-0`}
                            onClick={() => {
                              if (isListening) {
                                stopRecognition();
                              } else {
                                startRecognition();
                              }
                            }}
                          >
                            {isListening ? (
                              <motion.div
                                animate={{ opacity: [1, 0.7, 1] }}
                                transition={{ repeat: Infinity, duration: 1 }}
                              >
                                <Mic className="h-6 w-6 text-white" />
                              </motion.div>
                            ) : (
                              <Mic className="h-6 w-6 text-gray-300" />
                            )}
                          </Button>
                          
                          {/* Animated rings when listening */}
                          {isListening && (
                            <>
                              <motion.div 
                                className="absolute top-0 left-0 right-0 bottom-0 rounded-full border-2 border-teal-500"
                                initial={{ opacity: 1, scale: 1 }}
                                animate={{ opacity: 0, scale: 1.8 }}
                                transition={{ 
                                  repeat: Infinity, 
                                  duration: 1.5,
                                  repeatType: "loop"
                                }}
                              />
                              <motion.div 
                                className="absolute top-0 left-0 right-0 bottom-0 rounded-full border-2 border-teal-500"
                                initial={{ opacity: 1, scale: 1 }}
                                animate={{ opacity: 0, scale: 1.4 }}
                                transition={{ 
                                  repeat: Infinity, 
                                  duration: 1.5,
                                  delay: 0.5,
                                  repeatType: "loop"
                                }}
                              />
                            </>
                          )}
                        </motion.div>
                        
                        {/* Secondary controls */}
                        <div className="flex gap-3">
                          <Button
                            variant="destructive"
                            onClick={endCall}
                          >
                            <PhoneOff className="mr-2 h-4 w-4" />
                            End Call
                          </Button>
                          
                          <Button
                            variant="outline"
                            className="bg-gray-700 hover:bg-gray-600"
                            onClick={() => setShowTranscript(!showTranscript)}
                          >
                            <MessageCircle className="h-4 w-4" />
                          </Button>
                          
                          <Button
                            variant="outline"
                            className="bg-gray-700 hover:bg-gray-600"
                            onClick={() => setShowSettings(!showSettings)}
                          >
                            <Settings className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    )}
                  </div>
                  
                  <AnimatePresence>
                    {showSettings && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="mt-4 p-3 bg-gray-850 rounded-md border border-gray-700 grid gap-4">
                          <div className="grid gap-4">
                            <div className="flex items-center justify-between border-b border-gray-700 pb-2">
                              <div className="flex items-center group relative">
                                <Volume2 className="h-4 w-4 mr-2 text-teal-500" />
                                <Label htmlFor="audio-only-mode" className="text-sm font-medium">
                                  Audio-Only Mode
                                </Label>
                                <span className="ml-1 cursor-help">
                                  <AlertCircle className="h-3 w-3 text-gray-500" />
                                  <div className="absolute bottom-full left-0 mb-2 w-56 bg-gray-800 text-xs p-2 rounded-md border border-gray-700 shadow-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none z-10">
                                    In Audio-Only Mode, you'll experience only sound without seeing conversation text. This creates a more realistic phone call experience, simulating how real customers will interact with your phone system.
                                  </div>
                                </span>
                              </div>
                              <Switch
                                id="audio-only-mode"
                                checked={audioOnlyMode}
                                onCheckedChange={setAudioOnlyMode}
                              />
                            </div>
                            
                            <div className="grid grid-cols-2 gap-4">
                              <Button
                                variant="ghost"
                                className="text-xs h-8"
                                onClick={() => generateSampleDataset()}
                                disabled={!apiInitialized || datasetGenerating}
                              >
                                <RefreshCw className={`h-3 w-3 mr-1 ${datasetGenerating ? 'animate-spin' : ''}`} />
                                Generate {selectedLanguage === "en-IN" ? "English" : selectedLanguage === "hi-IN" ? "Hindi" : "Gujarati"} Samples
                              </Button>
                              
                              <Button
                                variant="ghost"
                                className="text-xs h-8"
                                onClick={clearTranscript}
                              >
                                Clear Conversation
                              </Button>
                            </div>
                            
                            <Button
                              variant="outline"
                              className="text-xs h-8 bg-purple-600/20 hover:bg-purple-600/30 border-purple-500/50"
                              onClick={generateLargeDataset}
                              disabled={!apiInitialized || datasetGenerating}
                            >
                              {datasetGenerating ? (
                                <>
                                  <Loader className="h-3 w-3 mr-1 animate-spin" />
                                  Generating Large Dataset ({datasetProgress}%)
                                </>
                              ) : (
                                <>
                                  <BarChart4 className="h-3 w-3 mr-1" />
                                  Generate 1000+ Business Queries
                                </>
                              )}
                            </Button>
                            
                            {(totalCalls > 0 || datasetGenerating) && (
                              <div className="mt-1">
                                <div className="flex justify-between text-xs mb-1">
                                  <span>Dataset Generation:</span>
                                  <span>{successfulCalls} / {totalCalls} queries</span>
                                </div>
                                <Progress value={datasetProgress} className="h-1" />
                              </div>
                            )}
                          </div>
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>
            </CardWithGradient>
          </div>
          
          {/* Sample prompts */}
          <div className="lg:col-span-4">
            <CardWithGradient
              color="teal"
              title={
                <div className="flex items-center">
                  <Info className="h-4 w-4 mr-2" />
                  <span>Sample Customer Queries</span>
                </div>
              }
              className="h-full"
            >
              <div className="space-y-3 max-h-[390px] overflow-y-auto pr-1">
                <p className="text-sm text-gray-400">
                  Click on any sample query below to test it with the AI:
                </p>
                
                {samplePrompts.map((prompt, index) => (
                  <div 
                    key={index}
                    className="p-2 rounded-md bg-gray-800 hover:bg-gray-700 cursor-pointer border border-gray-700 text-sm transition-colors"
                    onClick={() => usePrompt(prompt)}
                  >
                    "{prompt}"
                  </div>
                ))}
                
                <div className="mt-4 text-xs text-center text-gray-500">
                  <p>Click the settings icon to generate more samples in different languages</p>
                </div>
              </div>
            </CardWithGradient>
          </div>
        </div>
        
        <div className="text-center text-sm text-gray-400 max-w-2xl mx-auto">
          <p>This demo simulates how your business phone calls will be handled by Astra Intelligence.</p>
          <p className="mt-1">The AI voice assistant can understand and respond in English, Hindi, and Gujarati, automatically detecting the caller's language.</p>
          <p className="mt-1">For a more realistic experience, enable Audio-Only Mode in settings to simulate actual phone call interactions without text.</p>
          <p className="mt-2 text-xs">Note: For the best experience, use Chrome or Edge browser which have better speech recognition support.</p>
        </div>
      </div>
    </div>
  );
}
import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useQuery } from "@tanstack/react-query";
import { gsap } from "gsap";
import DashboardLayout from "@/components/layout/dashboard-layout";
import StatsCard from "@/components/dashboard/stats-card";
import AnalyticsCard from "@/components/dashboard/analytics-card";
import RecentCalls, { CallType } from "@/components/dashboard/recent-calls";
import CardWithGradient from "@/components/ui/card-with-gradient";
import GradientText from "@/components/ui/gradient-text";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useTutorial } from "@/hooks/use-tutorial";
import { TutorialCard } from "@/components/ui/tutorial-card";
import { Brain, Phone, Mic, Calendar, ArrowUpRight, CheckCircle2 } from "lucide-react";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";

const Dashboard = () => {
  const { user } = useAuth();
  const { showTutorial, completeTutorial, dismissTutorial, tutorialSteps } = useTutorial();
  const [progress, setProgress] = useState(0);
  
  // Fetch call logs
  const { data: callLogs } = useQuery({
    queryKey: ["/api/call-logs"],
    queryFn: async () => {
      // If there's no data yet, return empty array for the demo
      return [] as CallType[];
    },
  });
  
  // Fetch business info for onboarding progress
  const { data: businessInfo } = useQuery({
    queryKey: ["/api/business-info"],
    queryFn: async () => {
      // If there's no data yet, return null
      return null;
    },
  });
  
  // Example chart data
  const callVolumeTrendData = [
    { name: "Mon", value: 25 },
    { name: "Tue", value: 40 },
    { name: "Wed", value: 30 },
    { name: "Thu", value: 50 },
    { name: "Fri", value: 60 },
    { name: "Sat", value: 55 },
    { name: "Sun", value: 65 },
    { name: "Mon", value: 75 },
    { name: "Tue", value: 70 },
    { name: "Wed", value: 60 },
    { name: "Thu", value: 80 },
    { name: "Fri", value: 90 },
  ];
  
  // Example category data
  const categoryData = [
    { name: "Appointment", value: 42 },
    { name: "Inquiry", value: 28 },
    { name: "Pricing", value: 18 },
    { name: "Support", value: 12 },
  ];
  
  // Example recent calls data
  const recentCalls: CallType[] = [
    {
      id: 1,
      callerNumber: "+1 (555) 123-4567",
      timestamp: new Date(Date.now() - 1000 * 60 * 10).toISOString(), // 10 minutes ago
      transcription: "I'd like to book an appointment for a consultation on Tuesday afternoon if possible.",
      category: "Appointment",
      status: "resolved"
    },
    {
      id: 2,
      callerNumber: "+1 (555) 987-6543",
      timestamp: new Date(Date.now() - 1000 * 60 * 27).toISOString(), // 27 minutes ago
      transcription: "I want to know more about your premium services and what's included in the package.",
      category: "Inquiry",
      status: "resolved"
    },
    {
      id: 3,
      callerNumber: "+1 (555) 456-7890",
      timestamp: new Date(Date.now() - 1000 * 60 * 60).toISOString(), // 1 hour ago
      transcription: "Hello, I'd like to get a price quote for your monthly service plan for a small business.",
      category: "Pricing",
      status: "pending"
    }
  ];
  
  // Calculate onboarding progress
  useEffect(() => {
    let completed = 0;
    const total = 4; // Total number of onboarding steps
    
    // User registered
    if (user) completed++;
    
    // Business info provided
    if (businessInfo) completed++;
    
    // Phone number connected
    if (user?.numberConnected) completed++;
    
    // At least one call handled
    if (callLogs && callLogs.length > 0) completed++;
    
    // Animate progress bar
    const targetProgress = Math.floor((completed / total) * 100);
    gsap.to({ progress: progress }, {
      progress: targetProgress,
      duration: 1.5,
      ease: "power2.out",
      onUpdate: function() {
        setProgress(Math.round(this.targets()[0].progress));
      }
    });
  }, [user, businessInfo, callLogs, progress]);
  
  // Prepare the list of setup tasks
  const setupTasks = [
    {
      id: "register",
      title: "Create Account",
      completed: Boolean(user),
      path: "/auth"
    },
    {
      id: "business",
      title: "Set Up Business Information",
      completed: Boolean(businessInfo),
      path: "/business-setup"
    },
    {
      id: "connect",
      title: "Connect Phone Number",
      completed: Boolean(user?.numberConnected),
      path: "/connect-number"
    },
    {
      id: "calls",
      title: "Handle First Customer Call",
      completed: Boolean(callLogs && callLogs.length > 0),
      path: "/call-history"
    }
  ];

  return (
    <DashboardLayout title="Dashboard">
      {/* Tutorial Card */}
      {showTutorial && (
        <div className="fixed inset-0 flex items-center justify-center z-50 p-4 bg-black/50 backdrop-blur-sm">
          <TutorialCard
            steps={tutorialSteps}
            onComplete={completeTutorial}
            onDismiss={dismissTutorial}
          />
        </div>
      )}
      
      {/* Onboarding Progress Card */}
      {progress < 100 && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-6"
        >
          <CardWithGradient
            color="gradient"
            className="overflow-hidden"
          >
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h3 className="text-lg font-semibold text-white">Complete Setup</h3>
                  <p className="text-sm text-gray-400">Finish setting up your AI assistant</p>
                </div>
                <div className="bg-gray-900/50 px-3 py-1 rounded-full text-sm">
                  <GradientText>{progress}% complete</GradientText>
                </div>
              </div>
              
              <Progress value={progress} className="mb-6 h-2 bg-gray-700" />
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {setupTasks.map((task) => (
                  <Link key={task.id} href={task.path}>
                    <div className="block cursor-pointer">
                      <CardWithGradient
                        color={task.completed ? "teal" : "purple"}
                        className="hover:border-white/20"
                        contentClassName="p-4"
                      >
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium text-white">{task.title}</span>
                          {task.completed ? (
                            <CheckCircle2 className="h-5 w-5 text-green-500" />
                          ) : (
                            <ArrowUpRight className="h-5 w-5 text-purple-500" />
                          )}
                        </div>
                      </CardWithGradient>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </CardWithGradient>
        </motion.div>
      )}
      
      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <StatsCard
          title="Total Calls"
          value="1,248"
          change={{ value: 14, isPositive: true }}
          color="purple"
          icon={<Phone size={20} />}
          delay={0.1}
        />
        
        <StatsCard
          title="Success Rate"
          value="94.7%"
          change={{ value: 3.2, isPositive: true }}
          color="teal"
          icon={<CheckCircle2 size={20} />}
          delay={0.2}
        />
        
        <StatsCard
          title="Avg. Call Duration"
          value="2m 18s"
          change={{ value: 5, isPositive: false }}
          color="purple"
          icon={<Clock size={20} />}
          delay={0.3}
        />
        
        <StatsCard
          title="Active Integrations"
          value="3"
          color="teal"
          icon={<Zap size={20} />}
          delay={0.4}
        />
      </div>
      
      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-2">
          <AnalyticsCard
            title="Call Volume Trend"
            data={callVolumeTrendData}
            timeRanges={["Daily", "Weekly", "Monthly"]}
            delay={0.3}
          />
        </div>
        
        <div>
          <CategoryDistribution
            title="Call Categories"
            data={categoryData}
            delay={0.4}
          />
        </div>
      </div>
      
      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <RecentCalls
            calls={recentCalls}
            delay={0.5}
          />
        </div>
        
        <div>
          <QuickActions delay={0.6} />
        </div>
      </div>
    </DashboardLayout>
  );
};

// Helper components

const Clock: React.FC<{ size?: number }> = ({ size = 20 }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle>
    <polyline points="12 6 12 12 16 14"></polyline>
  </svg>
);

const Zap: React.FC<{ size?: number }> = ({ size = 20 }) => (
  <svg xmlns="http://www.w3.org/2000/svg" width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
  </svg>
);

// Category Distribution Component
const CategoryDistribution: React.FC<{
  title: string;
  data: { name: string; value: number }[];
  delay?: number;
}> = ({ title, data, delay = 0 }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <CardWithGradient
        title={title}
        color="purple"
      >
        <div className="space-y-4">
          {data.map((category, index) => (
            <div key={category.name}>
              <div className="flex justify-between text-sm mb-1">
                <span className="text-gray-400">{category.name}</span>
                <span className="text-white">{category.value}%</span>
              </div>
              <div className="w-full bg-gray-700 rounded-full h-2">
                <motion.div
                  initial={{ width: 0 }}
                  animate={{ width: `${category.value}%` }}
                  transition={{ duration: 1, delay: delay + index * 0.1 }}
                  className={`h-2 rounded-full ${index % 2 === 0 ? 'bg-purple-600' : 'bg-teal-500'}`}
                ></motion.div>
              </div>
            </div>
          ))}
        </div>
      </CardWithGradient>
    </motion.div>
  );
};

// Quick Actions Component
const QuickActions: React.FC<{ delay?: number }> = ({ delay = 0 }) => {
  const quickLinks = [
    {
      icon: <Brain size={20} />,
      title: "Train Your AI",
      description: "Improve AI responses by adding business details",
      path: "/business-setup",
      color: "bg-purple-600/20 text-purple-500"
    },
    {
      icon: <Mic size={20} />,
      title: "Test Microphone",
      description: "Check your mic is working correctly",
      path: "/mic-test",
      color: "bg-teal-600/20 text-teal-500"
    },
    {
      icon: <Calendar size={20} />,
      title: "Connect Calendar",
      description: "Link your Google Calendar for scheduling",
      path: "/calendar",
      color: "bg-purple-600/20 text-purple-500"
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay }}
    >
      <CardWithGradient
        title="Quick Actions"
        color="teal"
      >
        <div className="space-y-4">
          {quickLinks.map((link, index) => (
            <Link key={index} href={link.path}>
              <div className="block cursor-pointer">
                <motion.div
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.3, delay: delay + index * 0.1 }}
                  className="flex items-center p-3 rounded-lg bg-gray-800/70 hover:bg-gray-700/70 transition-colors"
                >
                  <div className={`w-10 h-10 rounded-md flex items-center justify-center mr-3 ${link.color}`}>
                    {link.icon}
                  </div>
                  <div>
                    <h4 className="font-medium text-white">{link.title}</h4>
                    <p className="text-xs text-gray-400">{link.description}</p>
                  </div>
                  <ArrowUpRight className="ml-auto h-4 w-4 text-gray-400" />
                </motion.div>
              </div>
            </Link>
          ))}
          
          <Button
            variant="outline"
            className="w-full border-gray-700 hover:bg-gray-700 text-gray-400 hover:text-white mt-2"
          >
            View All Features
          </Button>
        </div>
      </CardWithGradient>
    </motion.div>
  );
};

export default Dashboard;

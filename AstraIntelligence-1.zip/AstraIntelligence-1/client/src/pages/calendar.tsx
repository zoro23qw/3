import { useState } from "react";
import { motion } from "framer-motion";
import DashboardLayout from "@/components/layout/dashboard-layout";
import CardWithGradient from "@/components/ui/card-with-gradient";
import GradientText from "@/components/ui/gradient-text";
import { Calendar as CalendarIcon, Clock, Plus, Settings } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const Calendar = () => {
  const [view, setView] = useState<"month" | "week" | "day">("month");
  
  return (
    <DashboardLayout title="Calendar" subtitle="Scheduling">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <CardWithGradient
          color="purple"
          icon={<CalendarIcon size={24} />}
          title={<GradientText className="text-xl">Calendar Integration</GradientText>}
          description="Connect your calendar to automate scheduling with your AI assistant."
        >
          <div className="p-6 flex flex-col items-center justify-center space-y-6 text-center">
            <div className="w-16 h-16 rounded-full bg-gray-700 flex items-center justify-center mb-2">
              <CalendarIcon size={32} className="text-purple-500" />
            </div>
            
            <h3 className="text-xl font-medium text-white">Calendar Integration</h3>
            
            <p className="text-gray-400 max-w-md">
              Connect your Google Calendar or Microsoft Outlook to allow your AI assistant to schedule appointments automatically.
            </p>
            
            <Alert className="bg-gray-800 border-gray-700 max-w-md text-left">
              <Clock className="h-4 w-4" />
              <AlertTitle>Coming Soon</AlertTitle>
              <AlertDescription>
                Calendar integration is currently in development and will be available soon. 
                When enabled, your AI assistant will be able to check your availability and 
                schedule appointments with customers.
              </AlertDescription>
            </Alert>
            
            <div className="flex flex-wrap gap-3 pt-4">
              <Button variant="outline" className="border-gray-700 hover:bg-gray-700">
                <Plus className="mr-2 h-4 w-4" />
                Connect Google Calendar
              </Button>
              
              <Button variant="outline" className="border-gray-700 hover:bg-gray-700">
                <Plus className="mr-2 h-4 w-4" />
                Connect Microsoft Outlook
              </Button>
              
              <Button variant="outline" className="border-gray-700 hover:bg-gray-700">
                <Settings className="mr-2 h-4 w-4" />
                Calendar Settings
              </Button>
            </div>
          </div>
        </CardWithGradient>
      </motion.div>
    </DashboardLayout>
  );
};

export default Calendar;
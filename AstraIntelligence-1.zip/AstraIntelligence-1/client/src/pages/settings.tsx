import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { motion } from "framer-motion";
import { z } from "zod";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertUserSettingsSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";

import DashboardLayout from "@/components/layout/dashboard-layout";
import CardWithGradient from "@/components/ui/card-with-gradient";
import GradientText from "@/components/ui/gradient-text";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Separator } from "@/components/ui/separator";
import {
  Settings as SettingsIcon,
  User,
  Globe,
  Mail,
  MessageCircle,
  Phone,
  Lock,
  Bell,
  Calendar,
  ChevronRight,
  Languages,
  MoonStar,
  Zap,
  Mic,
  Save,
  Loader2,
  Check,
  Shield,
  ClipboardCopy,
  Trash,
  LogOut,
  AlertCircle
} from "lucide-react";

// Create a settings form schema based on the shared schema
const userSettingsSchema = insertUserSettingsSchema.omit({ id: true });

const profileSchema = z.object({
  name: z.string().min(1, "Name is required"),
  businessName: z.string().min(1, "Business name is required"),
  email: z.string().email("Please enter a valid email address"),
  phoneNumber: z.string().optional(),
});

const securitySchema = z.object({
  currentPassword: z.string().min(1, "Current password is required"),
  newPassword: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string().min(1, "Please confirm your password"),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

// Available languages
const languages = [
  { code: "en", name: "English" },
  { code: "es", name: "Spanish" },
  { code: "fr", name: "French" },
  { code: "de", name: "German" },
  { code: "it", name: "Italian" },
  { code: "zh", name: "Chinese" },
  { code: "ja", name: "Japanese" },
  { code: "ko", name: "Korean" },
  { code: "ru", name: "Russian" },
  { code: "ar", name: "Arabic" },
  { code: "hi", name: "Hindi" },
];

const Settings = () => {
  const [activeTab, setActiveTab] = useState("general");
  const { toast } = useToast();
  const { user, logoutMutation } = useAuth();
  
  // Fetch user settings
  const { data: userSettings, isLoading: isLoadingSettings } = useQuery({
    queryKey: ["/api/settings"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/settings", {
          credentials: "include",
        });
        
        if (res.status === 404) {
          // Return default settings if none exist yet
          return {
            userId: user?.id,
            inputLanguage: "en",
            outputLanguage: "en",
            autoDetectLanguage: true,
            aiResponseStyle: "formal",
            aiCallHandlingEnabled: true,
            calendarSyncEnabled: false,
          };
        }
        
        if (!res.ok) {
          throw new Error("Failed to fetch settings");
        }
        
        return await res.json();
      } catch (error) {
        console.error("Error fetching settings:", error);
        return null;
      }
    },
    enabled: !!user,
  });
  
  // Settings form
  const settingsForm = useForm<z.infer<typeof userSettingsSchema>>({
    resolver: zodResolver(userSettingsSchema),
    defaultValues: {
      userId: user?.id || 0,
      inputLanguage: "en",
      outputLanguage: "en",
      autoDetectLanguage: true,
      aiResponseStyle: "formal",
      aiCallHandlingEnabled: true,
      calendarSyncEnabled: false,
    },
  });
  
  // Profile form
  const profileForm = useForm<z.infer<typeof profileSchema>>({
    resolver: zodResolver(profileSchema),
    defaultValues: {
      name: user?.name || "",
      businessName: user?.businessName || "",
      email: user?.email || "",
      phoneNumber: user?.phoneNumber || "",
    },
  });
  
  // Security form
  const securityForm = useForm<z.infer<typeof securitySchema>>({
    resolver: zodResolver(securitySchema),
    defaultValues: {
      currentPassword: "",
      newPassword: "",
      confirmPassword: "",
    },
  });
  
  // Update forms when data is loaded
  useEffect(() => {
    if (userSettings) {
      settingsForm.reset({
        userId: user?.id,
        inputLanguage: userSettings.inputLanguage,
        outputLanguage: userSettings.outputLanguage,
        autoDetectLanguage: userSettings.autoDetectLanguage,
        aiResponseStyle: userSettings.aiResponseStyle,
        aiCallHandlingEnabled: userSettings.aiCallHandlingEnabled,
        calendarSyncEnabled: userSettings.calendarSyncEnabled,
      });
    }
    
    if (user) {
      profileForm.reset({
        name: user.name,
        businessName: user.businessName,
        email: user.email,
        phoneNumber: user.phoneNumber || "",
      });
    }
  }, [userSettings, user, settingsForm, profileForm]);
  
  // Save settings mutation
  const saveSettingsMutation = useMutation({
    mutationFn: async (data: z.infer<typeof userSettingsSchema>) => {
      const res = await apiRequest("POST", "/api/settings", data);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Settings saved",
        description: "Your preferences have been updated successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
    },
    onError: (error) => {
      toast({
        title: "Error saving settings",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  // Update profile mutation
  const updateProfileMutation = useMutation({
    mutationFn: async (data: z.infer<typeof profileSchema>) => {
      // In a real app, this would update the user profile
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Profile updated",
        description: "Your profile information has been updated successfully.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error updating profile",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  // Change password mutation
  const changePasswordMutation = useMutation({
    mutationFn: async (data: z.infer<typeof securitySchema>) => {
      // In a real app, this would change the password
      return { success: true };
    },
    onSuccess: () => {
      toast({
        title: "Password changed",
        description: "Your password has been changed successfully.",
      });
      securityForm.reset();
    },
    onError: (error) => {
      toast({
        title: "Error changing password",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  // Handle settings form submission
  const onSettingsSubmit = (values: z.infer<typeof userSettingsSchema>) => {
    if (user) {
      values.userId = user.id;
      saveSettingsMutation.mutate(values);
    }
  };
  
  // Handle profile form submission
  const onProfileSubmit = (values: z.infer<typeof profileSchema>) => {
    updateProfileMutation.mutate(values);
  };
  
  // Handle security form submission
  const onSecuritySubmit = (values: z.infer<typeof securitySchema>) => {
    changePasswordMutation.mutate(values);
  };
  
  // Copy API key to clipboard
  const handleCopyApiKey = () => {
    navigator.clipboard.writeText("sk_test_astra_intelligence_api_key");
    toast({
      title: "API key copied",
      description: "API key has been copied to clipboard.",
    });
  };
  
  // Delete account
  const handleDeleteAccount = () => {
    toast({
      title: "Account deletion",
      description: "Please contact support to delete your account.",
    });
  };
  
  return (
    <DashboardLayout title="Settings" subtitle="Preferences">
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {/* Settings navigation sidebar */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="lg:col-span-1"
        >
          <CardWithGradient
            color="purple"
            className="lg:sticky lg:top-24"
          >
            <div className="space-y-1">
              <Button
                variant="ghost"
                className={`w-full justify-start ${activeTab === "general" ? "bg-gray-700/70" : ""}`}
                onClick={() => setActiveTab("general")}
              >
                <SettingsIcon className="h-4 w-4 mr-3 text-gray-400" />
                General
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start ${activeTab === "profile" ? "bg-gray-700/70" : ""}`}
                onClick={() => setActiveTab("profile")}
              >
                <User className="h-4 w-4 mr-3 text-gray-400" />
                Profile
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start ${activeTab === "language" ? "bg-gray-700/70" : ""}`}
                onClick={() => setActiveTab("language")}
              >
                <Globe className="h-4 w-4 mr-3 text-gray-400" />
                Language
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start ${activeTab === "ai" ? "bg-gray-700/70" : ""}`}
                onClick={() => setActiveTab("ai")}
              >
                <Mic className="h-4 w-4 mr-3 text-gray-400" />
                AI Behavior
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start ${activeTab === "notifications" ? "bg-gray-700/70" : ""}`}
                onClick={() => setActiveTab("notifications")}
              >
                <Bell className="h-4 w-4 mr-3 text-gray-400" />
                Notifications
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start ${activeTab === "integration" ? "bg-gray-700/70" : ""}`}
                onClick={() => setActiveTab("integration")}
              >
                <Calendar className="h-4 w-4 mr-3 text-gray-400" />
                Integrations
              </Button>
              <Button
                variant="ghost"
                className={`w-full justify-start ${activeTab === "security" ? "bg-gray-700/70" : ""}`}
                onClick={() => setActiveTab("security")}
              >
                <Lock className="h-4 w-4 mr-3 text-gray-400" />
                Security
              </Button>
              <Separator className="my-2 bg-gray-700" />
              <Button
                variant="ghost"
                className="w-full justify-start text-red-400 hover:text-red-300 hover:bg-red-900/20"
                onClick={() => logoutMutation.mutate()}
              >
                <LogOut className="h-4 w-4 mr-3" />
                Log Out
              </Button>
            </div>
          </CardWithGradient>
        </motion.div>
        
        {/* Settings content */}
        <motion.div
          key={activeTab}
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="lg:col-span-4"
        >
          {/* General Settings */}
          {activeTab === "general" && (
            <CardWithGradient
              color="gradient"
              icon={<SettingsIcon size={24} />}
              title={<GradientText className="text-xl">General Settings</GradientText>}
              description="Configure your Astra Intelligence preferences."
            >
              <Form {...settingsForm}>
                <form onSubmit={settingsForm.handleSubmit(onSettingsSubmit)} className="space-y-6">
                  <div className="space-y-4">
                    <h3 className="text-lg font-medium text-white">Theme Preferences</h3>
                    
                    <FormField
                      control={settingsForm.control}
                      name="aiCallHandlingEnabled"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">
                              <div className="flex items-center">
                                <MoonStar className="h-4 w-4 mr-2 text-gray-400" />
                                Dark Mode
                              </div>
                            </FormLabel>
                            <FormDescription>
                              Enable or disable dark mode
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={true}
                              disabled={true}
                              onCheckedChange={() => {}}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <h3 className="text-lg font-medium text-white pt-4">Performance Settings</h3>
                    
                    <FormField
                      control={settingsForm.control}
                      name="aiCallHandlingEnabled"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">
                              <div className="flex items-center">
                                <Zap className="h-4 w-4 mr-2 text-gray-400" />
                                AI Call Handling
                              </div>
                            </FormLabel>
                            <FormDescription>
                              Allow the AI to handle incoming calls
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      className="bg-purple-600 hover:bg-purple-700"
                      disabled={saveSettingsMutation.isPending}
                    >
                      {saveSettingsMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Changes
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardWithGradient>
          )}
          
          {/* Profile Settings */}
          {activeTab === "profile" && (
            <CardWithGradient
              color="purple"
              icon={<User size={24} />}
              title={<GradientText className="text-xl">Profile Information</GradientText>}
              description="Manage your account details and business information."
            >
              <div className="mb-6 flex items-center gap-4">
                <div className="w-16 h-16 rounded-full bg-gray-700 flex items-center justify-center">
                  <span className="text-xl font-medium">
                    {user?.name.split(' ').map(part => part[0]).join('').toUpperCase()}
                  </span>
                </div>
                <div>
                  <h3 className="text-lg font-medium text-white">{user?.name}</h3>
                  <p className="text-sm text-gray-400">{user?.businessName}</p>
                </div>
              </div>
              
              <Form {...profileForm}>
                <form onSubmit={profileForm.handleSubmit(onProfileSubmit)} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={profileForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Full Name</FormLabel>
                          <FormControl>
                            <Input 
                              className="bg-gray-700 border-gray-600" 
                              {...field} 
                              placeholder="Your name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="businessName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Name</FormLabel>
                          <FormControl>
                            <Input 
                              className="bg-gray-700 border-gray-600" 
                              {...field} 
                              placeholder="Your business name"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email Address</FormLabel>
                          <FormControl>
                            <Input 
                              className="bg-gray-700 border-gray-600" 
                              {...field} 
                              placeholder="Your email address"
                              type="email"
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={profileForm.control}
                      name="phoneNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Phone Number</FormLabel>
                          <FormControl>
                            <Input 
                              className="bg-gray-700 border-gray-600" 
                              {...field} 
                              placeholder="Your phone number"
                            />
                          </FormControl>
                          <FormMessage />
                          <FormDescription>
                            This is the number you have connected with Astra.
                          </FormDescription>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      className="bg-purple-600 hover:bg-purple-700"
                      disabled={updateProfileMutation.isPending}
                    >
                      {updateProfileMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Updating...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Profile
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardWithGradient>
          )}
          
          {/* Language Settings */}
          {activeTab === "language" && (
            <CardWithGradient
              color="teal"
              icon={<Globe size={24} />}
              title={<GradientText className="text-xl">Language Settings</GradientText>}
              description="Configure the languages your AI assistant can understand and speak."
            >
              <Form {...settingsForm}>
                <form onSubmit={settingsForm.handleSubmit(onSettingsSubmit)} className="space-y-6">
                  <div className="space-y-6">
                    <FormField
                      control={settingsForm.control}
                      name="autoDetectLanguage"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">
                              <div className="flex items-center">
                                <Languages className="h-4 w-4 mr-2 text-gray-400" />
                                Auto-Detect Language
                              </div>
                            </FormLabel>
                            <FormDescription>
                              Automatically detect the caller's language
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={settingsForm.control}
                        name="inputLanguage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Input Language</FormLabel>
                            <Select
                              value={field.value}
                              onValueChange={field.onChange}
                              disabled={settingsForm.watch("autoDetectLanguage")}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-gray-700 border-gray-600">
                                  <SelectValue placeholder="Select language" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-gray-800 border-gray-700">
                                {languages.map(lang => (
                                  <SelectItem key={lang.code} value={lang.code}>
                                    {lang.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Language that your AI will understand from callers
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={settingsForm.control}
                        name="outputLanguage"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Output Language</FormLabel>
                            <Select
                              value={field.value}
                              onValueChange={field.onChange}
                            >
                              <FormControl>
                                <SelectTrigger className="bg-gray-700 border-gray-600">
                                  <SelectValue placeholder="Select language" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent className="bg-gray-800 border-gray-700">
                                {languages.map(lang => (
                                  <SelectItem key={lang.code} value={lang.code}>
                                    {lang.name}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormDescription>
                              Language that your AI will speak to callers
                            </FormDescription>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Alert className="bg-gray-800 border-gray-700">
                      <Languages className="h-4 w-4" />
                      <AlertTitle>Multi-language Support</AlertTitle>
                      <AlertDescription>
                        Astra can handle multiple languages simultaneously. Auto-detection works best when you set your most common input languages.
                      </AlertDescription>
                    </Alert>
                  </div>
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      className="bg-teal-600 hover:bg-teal-700"
                      disabled={saveSettingsMutation.isPending}
                    >
                      {saveSettingsMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Language Settings
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardWithGradient>
          )}
          
          {/* AI Behavior */}
          {activeTab === "ai" && (
            <CardWithGradient
              color="purple"
              icon={<Mic size={24} />}
              title={<GradientText className="text-xl">AI Behavior Settings</GradientText>}
              description="Customize how your AI assistant interacts with customers."
            >
              <Form {...settingsForm}>
                <form onSubmit={settingsForm.handleSubmit(onSettingsSubmit)} className="space-y-6">
                  <div className="space-y-6">
                    <h3 className="text-lg font-medium text-white">Response Style</h3>
                    
                    <FormField
                      control={settingsForm.control}
                      name="aiResponseStyle"
                      render={({ field }) => (
                        <FormItem>
                          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                            {[
                              { value: "formal", label: "Formal", desc: "Professional, traditional, reserved" },
                              { value: "friendly", label: "Friendly", desc: "Warm, personable, approachable" },
                              { value: "casual", label: "Casual", desc: "Relaxed, conversational, laid-back" },
                              { value: "professional", label: "Professional", desc: "Expert, informative, precise" },
                              { value: "sales", label: "Sales-Oriented", desc: "Persuasive, enthusiastic, engaging" },
                            ].map((style) => (
                              <FormControl key={style.value}>
                                <div 
                                  className={`cursor-pointer rounded-lg p-4 border transition-all ${
                                    field.value === style.value
                                      ? "bg-gray-700 border-purple-500 shadow-md"
                                      : "bg-gray-800 border-gray-700 hover:border-gray-500"
                                  }`}
                                  onClick={() => settingsForm.setValue("aiResponseStyle", style.value as any)}
                                >
                                  <h4 className="text-white font-medium">{style.label}</h4>
                                  <p className="text-sm text-gray-400">{style.desc}</p>
                                </div>
                              </FormControl>
                            ))}
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="rounded-lg p-4 border border-gray-700 bg-gray-800/50">
                      <h4 className="text-white font-medium mb-2">Response Preview</h4>
                      <div className="p-4 bg-gray-700 rounded-lg">
                        <p className="text-sm text-gray-300 italic">
                          {settingsForm.watch("aiResponseStyle") === "formal" && (
                            "Hello, thank you for calling. I would be happy to assist you with your inquiry. How may I help you today?"
                          )}
                          {settingsForm.watch("aiResponseStyle") === "friendly" && (
                            "Hi there! Thanks so much for calling! I'm excited to help you out today. What can I do for you?"
                          )}
                          {settingsForm.watch("aiResponseStyle") === "casual" && (
                            "Hey, thanks for calling! What's up? How can I help you out today?"
                          )}
                          {settingsForm.watch("aiResponseStyle") === "professional" && (
                            "Thank you for calling. I'm your AI assistant and I'm ready to provide you with detailed and accurate information. How may I assist you today?"
                          )}
                          {settingsForm.watch("aiResponseStyle") === "sales" && (
                            "Thanks for calling! You've made a great choice reaching out to us today. I'd love to tell you about our amazing offers and how we can help you. What are you looking for?"
                          )}
                        </p>
                      </div>
                    </div>
                    
                    <h3 className="text-lg font-medium text-white pt-4">Call Handling</h3>
                    
                    <FormField
                      control={settingsForm.control}
                      name="aiCallHandlingEnabled"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">
                              <div className="flex items-center">
                                <Phone className="h-4 w-4 mr-2 text-gray-400" />
                                AI Call Handling
                              </div>
                            </FormLabel>
                            <FormDescription>
                              Allow the AI to handle incoming calls
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      className="bg-purple-600 hover:bg-purple-700"
                      disabled={saveSettingsMutation.isPending}
                    >
                      {saveSettingsMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save AI Settings
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardWithGradient>
          )}
          
          {/* Notifications */}
          {activeTab === "notifications" && (
            <CardWithGradient
              color="teal"
              icon={<Bell size={24} />}
              title={<GradientText className="text-xl">Notification Settings</GradientText>}
              description="Control when and how you receive notifications from Astra."
            >
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium text-white">Email Notifications</h3>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                      <div className="space-y-0.5">
                        <div className="text-base font-medium">
                          <div className="flex items-center">
                            <Mail className="h-4 w-4 mr-2 text-gray-400" />
                            Daily Summary
                          </div>
                        </div>
                        <div className="text-sm text-gray-400">
                          Receive a daily summary of all AI-handled calls
                        </div>
                      </div>
                      <Switch defaultChecked={true} />
                    </div>
                    
                    <div className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                      <div className="space-y-0.5">
                        <div className="text-base font-medium">
                          <div className="flex items-center">
                            <Mail className="h-4 w-4 mr-2 text-gray-400" />
                            Missed Call Alert
                          </div>
                        </div>
                        <div className="text-sm text-gray-400">
                          Get notified when the AI couldn't handle a call completely
                        </div>
                      </div>
                      <Switch defaultChecked={true} />
                    </div>
                    
                    <div className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                      <div className="space-y-0.5">
                        <div className="text-base font-medium">
                          <div className="flex items-center">
                            <Mail className="h-4 w-4 mr-2 text-gray-400" />
                            Product Updates
                          </div>
                        </div>
                        <div className="text-sm text-gray-400">
                          Receive updates about new Astra features and improvements
                        </div>
                      </div>
                      <Switch defaultChecked={false} />
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-medium text-white pt-4">SMS Notifications</h3>
                  
                  <div className="space-y-2">
                    <div className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                      <div className="space-y-0.5">
                        <div className="text-base font-medium">
                          <div className="flex items-center">
                            <MessageCircle className="h-4 w-4 mr-2 text-gray-400" />
                            Urgent Calls
                          </div>
                        </div>
                        <div className="text-sm text-gray-400">
                          Get SMS alerts for high-priority calls
                        </div>
                      </div>
                      <Switch defaultChecked={true} />
                    </div>
                    
                    <div className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                      <div className="space-y-0.5">
                        <div className="text-base font-medium">
                          <div className="flex items-center">
                            <MessageCircle className="h-4 w-4 mr-2 text-gray-400" />
                            System Status
                          </div>
                        </div>
                        <div className="text-sm text-gray-400">
                          Receive SMS notifications about system outages or maintenance
                        </div>
                      </div>
                      <Switch defaultChecked={false} />
                    </div>
                  </div>
                </div>
                
                <div className="flex justify-end">
                  <Button 
                    className="bg-teal-600 hover:bg-teal-700"
                    onClick={() => {
                      toast({
                        title: "Notification settings saved",
                        description: "Your notification preferences have been updated.",
                      });
                    }}
                  >
                    <Save className="mr-2 h-4 w-4" />
                    Save Notification Settings
                  </Button>
                </div>
              </div>
            </CardWithGradient>
          )}
          
          {/* Integrations */}
          {activeTab === "integration" && (
            <CardWithGradient
              color="gradient"
              icon={<Calendar size={24} />}
              title={<GradientText className="text-xl">Integrations</GradientText>}
              description="Connect Astra with your other tools and services."
            >
              <Form {...settingsForm}>
                <form onSubmit={settingsForm.handleSubmit(onSettingsSubmit)} className="space-y-6">
                  <div className="space-y-6">
                    <h3 className="text-lg font-medium text-white">Calendar Integration</h3>
                    
                    <FormField
                      control={settingsForm.control}
                      name="calendarSyncEnabled"
                      render={({ field }) => (
                        <FormItem className="flex items-center justify-between rounded-lg border border-gray-700 p-4">
                          <div className="space-y-0.5">
                            <FormLabel className="text-base">
                              <div className="flex items-center">
                                <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                                Google Calendar Sync
                              </div>
                            </FormLabel>
                            <FormDescription>
                              Allow the AI to access your calendar for scheduling
                            </FormDescription>
                          </div>
                          <FormControl>
                            <Switch
                              checked={field.value}
                              onCheckedChange={field.onChange}
                            />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    
                    {settingsForm.watch("calendarSyncEnabled") && (
                      <div className="rounded-lg border border-gray-700 p-4 bg-gray-800/50">
                        <div className="flex justify-between items-center">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 rounded-full bg-blue-600/20 flex items-center justify-center">
                              <svg className="h-5 w-5 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M20.571 19.419a3.142 3.142 0 11-6.284 0 3.142 3.142 0 016.284 0zM6.858 7.858a3.142 3.142 0 11-6.284 0 3.142 3.142 0 016.284 0zM20.571 7.858a3.142 3.142 0 11-6.284 0 3.142 3.142 0 016.284 0z" />
                                <path fillRule="evenodd" clipRule="evenodd" d="M17.429 23a6.571 6.571 0 110-13.143 6.571 6.571 0 010 13.143zm-10.858-8.57a6.572 6.572 0 01-4.243-1.6 6.571 6.571 0 118.814-9.757 6.571 6.571 0 019.201 0 6.57 6.57 0 11-4.486 11.329 8.342 8.342 0 00-1.2-1.371 4.286 4.286 0 10-8.086 1.4z" />
                              </svg>
                            </div>
                            <div>
                              <div className="font-medium text-white">Google Calendar</div>
                              <div className="text-sm text-gray-400">Connected as {user?.email}</div>
                            </div>
                          </div>
                          <Badge className="bg-green-500/20 text-green-400 border-0">Connected</Badge>
                        </div>
                        
                        <div className="mt-4 space-y-2">
                          <div className="text-sm font-medium text-white">Connected Calendars</div>
                          <div className="rounded-md bg-gray-700 p-3 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-blue-400" />
                              <span className="text-sm text-gray-300">Primary Calendar</span>
                            </div>
                            <Switch defaultChecked={true} />
                          </div>
                          <div className="rounded-md bg-gray-700 p-3 flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <Calendar className="h-4 w-4 text-red-400" />
                              <span className="text-sm text-gray-300">Work Calendar</span>
                            </div>
                            <Switch defaultChecked={true} />
                          </div>
                        </div>
                      </div>
                    )}
                    
                    <h3 className="text-lg font-medium text-white pt-4">Other Integrations</h3>
                    
                    <div className="rounded-lg border border-gray-700 p-4 bg-gray-800/50 flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
                          <svg className="h-5 w-5 text-blue-400" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M19.7 3.037c-.86 0-1.66.244-2.255.812-.562.529-.895 1.27-.895 2.155 0 .87.324 1.59.894 2.092.597.562 1.494.87 2.255.87.761 0 1.658-.308 2.254-.87.58-.502.903-1.221.903-2.092 0-.944-.339-1.69-.895-2.179-.588-.53-1.317-.788-2.261-.788zm-9.945 0c-.856 0-1.655.244-2.246.812-.537.486-.869 1.237-.886 2.155.017.871.35 1.59.886 2.092.591.562 1.39.87 2.246.87s1.655-.307 2.246-.87c.546-.502.886-1.221.886-2.092 0-.885-.339-1.634-.886-2.155-.591-.568-1.39-.812-2.246-.812zm-9.945 0c-.861 0-1.661.244-2.25.812-.562.554-.902 1.295-.902 2.155 0 .896.357 1.614.902 2.116.58.537 1.394.845 2.128.845.887 0 1.674-.307 2.254-.87.571-.502.895-1.221.895-2.092 0-.885-.324-1.634-.895-2.155-.58-.568-1.342-.812-2.132-.812zM10.012 13.96c-.862 0-1.662.244-2.255.812-.563.529-.903 1.27-.903 2.155 0 .87.324 1.59.886 2.091.597.562 1.495.87 2.255.87.767 0 1.664-.308 2.255-.87.58-.502.903-1.221.903-2.092 0-.885-.324-1.634-.886-2.155-.597-.567-1.403-.811-2.255-.811zm9.945 0c-.856 0-1.655.244-2.246.812-.562.528-.903 1.27-.903 2.155 0 .87.324 1.59.886 2.091.597.562 1.494.87 2.263.87s1.65-.308 2.246-.87c.546-.502.886-1.221.886-2.092 0-.885-.339-1.634-.886-2.155-.597-.567-1.39-.811-2.246-.811zm-9.945 0c-.856 0-1.655.244-2.246.812-.58.528-.886 1.27-.886 2.155 0 .87.322 1.59.886 2.091.582.562 1.39.87 2.246.87s1.647-.308 2.254-.87c.554-.502.886-1.221.886-2.092 0-.885-.34-1.634-.903-2.155-.59-.567-1.39-.811-2.237-.811z" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-medium text-white">Slack</div>
                          <div className="text-sm text-gray-400">Connect for call notifications</div>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        className="border-gray-700 hover:bg-gray-700"
                      >
                        Connect
                      </Button>
                    </div>
                    
                    <div className="rounded-lg border border-gray-700 p-4 bg-gray-800/50 flex justify-between items-center">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-gray-700 flex items-center justify-center">
                          <svg className="h-5 w-5 text-blue-500" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M22.288 3.55H1.712C0.768 3.55 0 4.318 0 5.262v13.475c0 0.944 0.768 1.714 1.712 1.714h20.576c0.944 0 1.712-0.769 1.712-1.714V5.262C24 4.318 23.232 3.55 22.288 3.55zM7.742 17.994l-5.122 0.003V6.003L7.742 6v11.994zM13.371 12c0 2.206-1.794 4-4 4s-4-1.794-4-4c0-2.206 1.794-4 4-4S13.371 9.794 13.371 12zM21.371 17.556h-5.111V12.222h5.111V17.556z" />
                          </svg>
                        </div>
                        <div>
                          <div className="font-medium text-white">Zoom</div>
                          <div className="text-sm text-gray-400">Connect for video meetings</div>
                        </div>
                      </div>
                      <Button
                        variant="outline"
                        className="border-gray-700 hover:bg-gray-700"
                      >
                        Connect
                      </Button>
                    </div>
                  </div>
                  
                  <div className="flex justify-end">
                    <Button 
                      type="submit" 
                      className="bg-gradient-to-r from-purple-600 to-teal-500 hover:from-purple-700 hover:to-teal-600"
                      disabled={saveSettingsMutation.isPending}
                    >
                      {saveSettingsMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="mr-2 h-4 w-4" />
                          Save Integration Settings
                        </>
                      )}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardWithGradient>
          )}
          
          {/* Security Settings */}
          {activeTab === "security" && (
            <CardWithGradient
              color="purple"
              icon={<Lock size={24} />}
              title={<GradientText className="text-xl">Security Settings</GradientText>}
              description="Manage your account security and API access."
            >
              <div className="space-y-8">
                {/* Change Password */}
                <div>
                  <h3 className="text-lg font-medium text-white mb-4">Change Password</h3>
                  
                  <Form {...securityForm}>
                    <form onSubmit={securityForm.handleSubmit(onSecuritySubmit)} className="space-y-4">
                      <FormField
                        control={securityForm.control}
                        name="currentPassword"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Current Password</FormLabel>
                            <FormControl>
                              <Input 
                                type="password"
                                className="bg-gray-700 border-gray-600" 
                                {...field} 
                                placeholder="Enter your current password"
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <FormField
                          control={securityForm.control}
                          name="newPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>New Password</FormLabel>
                              <FormControl>
                                <Input 
                                  type="password"
                                  className="bg-gray-700 border-gray-600" 
                                  {...field} 
                                  placeholder="Enter new password"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={securityForm.control}
                          name="confirmPassword"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Confirm New Password</FormLabel>
                              <FormControl>
                                <Input 
                                  type="password"
                                  className="bg-gray-700 border-gray-600" 
                                  {...field} 
                                  placeholder="Confirm new password"
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>
                      
                      <div className="pt-2">
                        <Button 
                          type="submit" 
                          className="bg-purple-600 hover:bg-purple-700"
                          disabled={changePasswordMutation.isPending}
                        >
                          {changePasswordMutation.isPending ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Updating...
                            </>
                          ) : (
                            <>
                              <Lock className="mr-2 h-4 w-4" />
                              Change Password
                            </>
                          )}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </div>
                
                {/* API Access */}
                <div>
                  <h3 className="text-lg font-medium text-white mb-4">API Access</h3>
                  
                  <div className="rounded-lg border border-gray-700 p-4 bg-gray-800/50 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="font-medium text-white flex items-center">
                        <Shield className="h-4 w-4 mr-2 text-gray-400" />
                        API Key
                      </div>
                      <Badge className="bg-teal-500/20 text-teal-400 border-0">Active</Badge>
                    </div>
                    
                    <div className="flex items-center gap-2">
                      <div className="bg-gray-700 text-gray-300 p-2 rounded-md text-sm flex-grow font-mono">
                        sk_test_••••••••••••••••••••••••••
                      </div>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-gray-700 hover:bg-gray-700"
                        onClick={handleCopyApiKey}
                      >
                        <ClipboardCopy className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    <div className="text-sm text-gray-400">
                      This API key provides full access to your Astra Intelligence account. Keep it secure and never share it publicly.
                    </div>
                    
                    <div className="flex flex-wrap gap-2">
                      <Button
                        variant="outline"
                        className="border-gray-700 hover:bg-gray-700"
                        onClick={() => {
                          toast({
                            title: "API key regenerated",
                            description: "Your new API key has been generated. The old key is no longer valid.",
                          });
                        }}
                      >
                        <RefreshCw className="mr-2 h-4 w-4" />
                        Regenerate Key
                      </Button>
                      
                      <Button
                        variant="outline"
                        className="border-red-900/30 text-red-400 hover:bg-red-900/20 hover:text-red-300"
                        onClick={() => {
                          toast({
                            title: "API key revoked",
                            description: "Your API key has been revoked. Generate a new one when needed.",
                          });
                        }}
                      >
                        <XCircle className="mr-2 h-4 w-4" />
                        Revoke Key
                      </Button>
                    </div>
                  </div>
                </div>
                
                {/* Account Deletion */}
                <div>
                  <h3 className="text-lg font-medium text-white mb-4">Delete Account</h3>
                  
                  <Alert variant="destructive" className="bg-red-900/20 border-red-900/30 text-white">
                    <AlertCircle className="h-4 w-4" />
                    <AlertTitle>Warning</AlertTitle>
                    <AlertDescription>
                      Deleting your account will remove all your data and cannot be undone. You will lose access to your AI assistant and all call history.
                    </AlertDescription>
                  </Alert>
                  
                  <div className="mt-4">
                    <Button
                      variant="destructive"
                      className="bg-red-600 hover:bg-red-700"
                      onClick={handleDeleteAccount}
                    >
                      <Trash className="mr-2 h-4 w-4" />
                      Delete Account
                    </Button>
                  </div>
                </div>
              </div>
            </CardWithGradient>
          )}
        </motion.div>
      </div>
    </DashboardLayout>
  );
};

export default Settings;

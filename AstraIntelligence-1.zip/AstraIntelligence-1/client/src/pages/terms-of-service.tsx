import { Helmet } from 'react-helmet';
import Footer from '@/components/site/footer';
import Navbar from '@/components/site/navbar';

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-gray-900">
      <Helmet>
        <title>Terms of Service | Astra Intelligence</title>
      </Helmet>
      <Navbar />
      <main className="container mx-auto px-4 sm:px-6 lg:px-8 py-24 text-gray-300 max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-extrabold mb-8 text-white">
          Terms of Service
        </h1>
        
        <div className="prose prose-invert max-w-none">
          <p className="text-gray-300 text-lg mb-6">
            Last updated: April 2, 2025
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">1. Acceptance of Terms</h2>
          <p>
            By accessing or using the Astra Intelligence AI voice assistant service ("Service"), you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our Service.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">2. Description of Service</h2>
          <p>
            Astra Intelligence provides an AI-powered voice assistant that integrates with your existing phone number to handle customer calls and inquiries.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">3. User Accounts</h2>
          <p>
            To use certain features of the Service, you must create an account. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">4. Subscription and Payments</h2>
          <p>
            Astra Intelligence offers the following subscription plans:
          </p>
          <ul className="list-disc pl-6 mt-2 mb-4 space-y-2">
            <li><strong>Standard Plan:</strong> Rs. 2,000 per month</li>
            <li><strong>Enterprise Plan:</strong> Rs. 5,000 per month</li>
          </ul>
          <p>
            Subscription fees are charged in advance on a monthly basis. You may cancel your subscription at any time, but refunds are not provided for partial months.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">5. Acceptable Use</h2>
          <p>
            You agree not to use the Service for any unlawful purpose or in any way that could damage, disable, overburden, or impair the Service. You may not use the Service in connection with any content that:
          </p>
          <ul className="list-disc pl-6 mt-2 mb-4 space-y-2">
            <li>Is illegal or promotes illegal activities</li>
            <li>Is harassing, abusive, or threatening</li>
            <li>Is discriminatory or promotes discrimination</li>
            <li>Infringes on the intellectual property rights of others</li>
            <li>Contains sexually explicit content or promotes adult services</li>
            <li>Contains or promotes violence</li>
          </ul>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">6. Intellectual Property</h2>
          <p>
            All content, features, and functionality of the Service, including but not limited to the design, software, and algorithms, are owned by Astra Intelligence and are protected by copyright, trademark, and other intellectual property laws.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">7. Limitation of Liability</h2>
          <p>
            In no event shall Astra Intelligence be liable for any indirect, incidental, special, consequential, or punitive damages, including without limitation, loss of profits, data, or use, arising out of or in connection with the Service.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">8. Termination</h2>
          <p>
            We may terminate or suspend your account and access to the Service immediately, without prior notice or liability, for any reason, including without limitation if you breach these Terms of Service.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">9. Changes to Terms</h2>
          <p>
            We reserve the right to modify or replace these Terms of Service at any time. We will provide notice of any material changes by posting the new Terms of Service on this page and updating the "Last Updated" date.
          </p>
          
          <h2 className="text-2xl font-bold mt-8 mb-4 text-white">10. Contact Us</h2>
          <p>
            If you have any questions about these Terms of Service, please contact us at:
          </p>
          <p className="mt-2">
            <strong>Email:</strong> legal@astraintelligence.com
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
}
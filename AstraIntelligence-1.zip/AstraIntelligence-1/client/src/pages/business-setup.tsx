import React, { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "framer-motion";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/use-auth";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { insertBusinessInfoSchema } from "@shared/schema";

import DashboardLayout from "@/components/layout/dashboard-layout";
import CardWithGradient from "@/components/ui/card-with-gradient";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Loader2, Brain, Info, ArrowRight, Check } from "lucide-react";
import SliderInput from "@/components/ui/slider-input";
import GradientText from "@/components/ui/gradient-text";

// Extend the schema to add validation
const businessFormSchema = insertBusinessInfoSchema.extend({
  industry: z.string().min(1, "Please select an industry"),
  services: z.string().min(1, "Please describe your services"),
  businessHours: z.string().min(1, "Please provide your business hours"),
  commonQuestions: z.string().min(1, "Please add some common customer questions"),
  aiResponseStyle: z.enum(["formal", "casual", "friendly", "professional", "sales"]).default("professional"),
});

type BusinessFormValues = z.infer<typeof businessFormSchema>;

// Industry options
const industries = [
  "Healthcare",
  "Legal Services",
  "Real Estate",
  "Restaurant/Food",
  "Retail",
  "Technology",
  "Consulting",
  "Finance/Banking",
  "Education",
  "Beauty/Wellness",
  "Fitness",
  "Automotive",
  "Professional Services",
  "Other"
];

// Common questions based on industry
const commonQuestionsExamples: Record<string, string[]> = {
  "Healthcare": [
    "What are your office hours?",
    "Do you accept insurance?",
    "How do I schedule an appointment?",
    "What services do you offer?",
    "Is a doctor referral required?"
  ],
  "Legal Services": [
    "What areas of law do you specialize in?",
    "What are your fees?",
    "Do you offer free consultations?",
    "How long have you been practicing?",
    "Will I work directly with an attorney?"
  ],
  "Real Estate": [
    "What properties do you have available?",
    "What are your commission rates?",
    "How long does the buying/selling process take?",
    "Do you help with financing?",
    "What areas do you service?"
  ],
  "Restaurant/Food": [
    "What are your hours?",
    "Do you take reservations?",
    "Do you offer delivery?",
    "What are your most popular dishes?",
    "Do you cater events?"
  ],
  "Retail": [
    "What are your store hours?",
    "Do you have a return policy?",
    "Do you offer online shopping?",
    "Do you have gift cards available?",
    "Are there any current sales or promotions?"
  ],
  "Technology": [
    "What services do you offer?",
    "What are your rates?",
    "Do you offer support/maintenance?",
    "What is your typical project timeline?",
    "Do you have experience in our industry?"
  ],
  "Other": [
    "What services do you offer?",
    "What are your hours of operation?",
    "How much do your services cost?",
    "Do you offer consultations?",
    "What is your contact information?"
  ]
};

const BusinessSetup = () => {
  const [step, setStep] = useState(1);
  const [selectedIndustry, setSelectedIndustry] = useState<string>("");
  const { toast } = useToast();
  const { user } = useAuth();
  const [_, navigate] = useLocation();
  
  // Fetch business info if it exists
  const { data: businessInfo, isLoading } = useQuery({
    queryKey: ["/api/business-info"],
    queryFn: async () => {
      try {
        const res = await fetch("/api/business-info", {
          credentials: "include",
        });
        if (!res.ok) {
          if (res.status === 404) {
            return null;
          }
          throw new Error("Failed to fetch business info");
        }
        return await res.json();
      } catch (error) {
        console.error("Error fetching business info:", error);
        return null;
      }
    }
  });
  
  // Form setup
  const form = useForm<BusinessFormValues>({
    resolver: zodResolver(businessFormSchema),
    defaultValues: {
      userId: user?.id || 0,
      industry: businessInfo?.industry || "",
      services: businessInfo?.services || "",
      businessHours: businessInfo?.businessHours || "",
      commonQuestions: businessInfo?.commonQuestions || "",
      aiResponseStyle: businessInfo?.aiResponseStyle || "professional",
    },
  });
  
  // Update form when data is loaded
  useEffect(() => {
    if (businessInfo) {
      form.reset({
        userId: user?.id || 0,
        industry: businessInfo.industry || "",
        services: businessInfo.services || "",
        businessHours: businessInfo.businessHours || "",
        commonQuestions: businessInfo.commonQuestions || "",
        aiResponseStyle: businessInfo.aiResponseStyle || "professional",
      });
      
      if (businessInfo.industry) {
        setSelectedIndustry(businessInfo.industry);
      }
    } else if (user) {
      // If no business info but user exists, set default userId
      form.setValue("userId", user.id);
    }
  }, [businessInfo, form, user]);
  
  // When industry changes, suggest common questions
  const handleIndustryChange = (value: string) => {
    try {
      console.log("Industry selected:", value);
      setSelectedIndustry(value);
      form.setValue("industry", value);
      
      // If no common questions have been entered yet, suggest some based on industry
      const currentQuestions = form.getValues("commonQuestions");
      if (!currentQuestions || currentQuestions.trim() === "") {
        const suggestions = commonQuestionsExamples[value] || commonQuestionsExamples["Other"];
        if (Array.isArray(suggestions)) {
          form.setValue("commonQuestions", suggestions.join("\n"));
        } else {
          console.error("Expected array of suggestions, got:", suggestions);
          // Set default questions if suggestions aren't available
          form.setValue("commonQuestions", commonQuestionsExamples["Other"].join("\n"));
        }
      }
    } catch (error) {
      console.error("Error handling industry change:", error);
      toast({
        title: "Error setting industry",
        description: "Please try selecting again or choose a different industry.",
        variant: "destructive",
      });
    }
  };
  
  // Save business info
  const mutation = useMutation({
    mutationFn: async (data: BusinessFormValues) => {
      try {
        const res = await apiRequest("POST", "/api/business-info", data);
        if (!res.ok) {
          const errorData = await res.json().catch(() => ({}));
          throw new Error(errorData.message || "Failed to save business information");
        }
        return await res.json();
      } catch (error) {
        console.error("Business info save error:", error);
        throw error;
      }
    },
    onSuccess: () => {
      toast({
        title: "Business information saved",
        description: "Your AI assistant has been trained with your business details.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/business-info"] });
      
      // If it's the final step, navigate to dashboard
      if (step === 3) {
        console.log("Final step completed, navigating to dashboard...");
        // Force a longer delay to ensure the toast is shown before navigation
        setTimeout(() => {
          console.log("Executing navigation to /dashboard");
          navigate("/dashboard");
        }, 1500); // Increased delay for better reliability
      } else {
        // Move to next step
        console.log(`Moving from step ${step} to step ${step + 1}`);
        setStep(step + 1);
      }
    },
    onError: (error) => {
      toast({
        title: "Error saving business information",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (data: BusinessFormValues) => {
    if (user) {
      data.userId = user.id;
      // Use formState isValid to ensure the form validates
      if (form.formState.isValid) {
        console.log("Submitting valid form data:", data);
        mutation.mutate(data);
      } else {
        console.error("Form validation errors:", form.formState.errors);
        // If the form is invalid, display all validation errors
        // Display one toast with summary of validation errors
        toast({
          title: "Validation errors",
          description: "Please check the form for required fields and correct any errors.",
          variant: "destructive",
        });
      }
    } else {
      toast({
        title: "Error",
        description: "You must be logged in to save business information.",
        variant: "destructive",
      });
    }
  };
  
  // Loading state
  if (isLoading) {
    return (
      <DashboardLayout title="AI Training">
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-8 w-8 animate-spin text-purple-600" />
          <span className="ml-3 text-gray-400">Loading business information...</span>
        </div>
      </DashboardLayout>
    );
  }
  
  return (
    <DashboardLayout title="AI Training" subtitle="Business Information">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          {/* Step 1: Basic Business Info */}
          {step === 1 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <CardWithGradient
                color="purple"
                className="mb-6"
                icon={<Brain size={24} />}
                title={<GradientText className="text-xl">Step 1: Basic Business Information</GradientText>}
                description="Tell us about your business so your AI assistant can accurately represent your brand."
              >
                <div className="grid gap-6">
                  <FormField
                    control={form.control}
                    name="industry"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Industry</FormLabel>
                        <FormControl>
                          <Select
                            value={field.value || ""}
                            onValueChange={(value) => {
                              field.onChange(value); // Ensure field value is updated for form validation
                              if (value) handleIndustryChange(value);
                            }}
                          >
                            <SelectTrigger className="w-full bg-gray-700 border-gray-600">
                              <SelectValue placeholder="Select your industry" />
                            </SelectTrigger>
                            <SelectContent className="bg-gray-800 border-gray-700">
                              {industries && industries.length > 0 ? (
                                industries.map((industry) => (
                                  <SelectItem key={industry} value={industry}>
                                    {industry}
                                  </SelectItem>
                                ))
                              ) : (
                                <SelectItem value="loading" disabled>
                                  Loading industries...
                                </SelectItem>
                              )}
                            </SelectContent>
                          </Select>
                        </FormControl>
                        <FormDescription>
                          This helps us provide industry-specific AI training.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="services"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Services Offered</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="Describe the services your business offers"
                            className="bg-gray-700 border-gray-600 min-h-[120px]"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          List your main services, products, or specialties.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="businessHours"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Hours</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="E.g., Monday-Friday: 9am-5pm, Saturday: 10am-2pm, Sunday: Closed"
                            className="bg-gray-700 border-gray-600"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Your operating hours so the AI can inform customers.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardWithGradient>
              
              <div className="flex justify-end">
                <Button 
                  type="button" 
                  onClick={() => {
                    if (form.getValues("industry") && form.getValues("services") && form.getValues("businessHours")) {
                      setStep(2);
                    } else {
                      toast({
                        title: "Missing information",
                        description: "Please fill out all fields before proceeding.",
                        variant: "destructive",
                      });
                    }
                  }}
                  className="bg-purple-600 hover:bg-purple-700"
                >
                  Next Step
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          )}
          
          {/* Step 2: Common Questions */}
          {step === 2 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <CardWithGradient
                color="teal"
                className="mb-6"
                icon={<Info size={24} />}
                title={<GradientText className="text-xl">Step 2: Customer Questions</GradientText>}
                description="Add common questions customers ask so your AI can answer them accurately."
              >
                <div className="space-y-6">
                  <FormField
                    control={form.control}
                    name="commonQuestions"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Common Customer Questions</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder="List common questions your customers ask, one per line"
                            className="bg-gray-700 border-gray-600 min-h-[200px]"
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          Enter one question per line. Include questions about services, prices, hours, etc.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  {selectedIndustry && (
                    <div className="bg-gray-700/50 p-4 rounded-lg border border-gray-600">
                      <h4 className="text-sm font-medium text-white mb-2">Suggested Questions for {selectedIndustry}</h4>
                      <ul className="space-y-2 text-sm text-gray-300">
                        {(() => {
                          try {
                            const questions = commonQuestionsExamples[selectedIndustry] || commonQuestionsExamples["Other"] || [];
                            return Array.isArray(questions) ? questions.map((question, index) => (
                              <li key={index} className="flex items-start gap-2">
                                <Check className="h-4 w-4 text-teal-500 mt-0.5" />
                                <span>{question}</span>
                              </li>
                            )) : (
                              <li className="text-amber-400">
                                <span>Example questions not available. Please add your own questions.</span>
                              </li>
                            );
                          } catch (error) {
                            console.error("Error rendering suggested questions:", error);
                            return (
                              <li className="text-amber-400">
                                <span>Example questions not available. Please add your own questions.</span>
                              </li>
                            );
                          }
                        })()}
                      </ul>
                      <p className="text-xs text-gray-400 mt-3">
                        Click on a question to add it to your list if it's not already included.
                      </p>
                    </div>
                  )}
                </div>
              </CardWithGradient>
              
              <div className="flex justify-between">
                <Button 
                  type="button" 
                  onClick={() => setStep(1)}
                  variant="outline"
                  className="border-gray-700 hover:bg-gray-700"
                >
                  Back
                </Button>
                <Button 
                  type="button" 
                  onClick={() => {
                    if (form.getValues("commonQuestions")) {
                      setStep(3);
                    } else {
                      toast({
                        title: "Missing information",
                        description: "Please add some common customer questions before proceeding.",
                        variant: "destructive",
                      });
                    }
                  }}
                  className="bg-teal-600 hover:bg-teal-700"
                >
                  Next Step
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </motion.div>
          )}
          
          {/* Step 3: AI Personality */}
          {step === 3 && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
            >
              <CardWithGradient
                color="gradient"
                className="mb-6"
                icon={<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6">
                  <path d="M12 2a5 5 0 0 0-5 5v14a5 5 0 0 0 10 0V7a5 5 0 0 0-5-5Z"/>
                  <path d="M8 15a4 4 0 0 0 8 0"/>
                </svg>}
                title={<GradientText className="text-xl">Step 3: AI Response Style</GradientText>}
                description="Choose how your AI assistant should sound when communicating with customers."
              >
                <div className="space-y-6">
                  <FormField
                    control={form.control}
                    name="aiResponseStyle"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>AI Personality</FormLabel>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-3">
                          {[
                            { value: "formal", label: "Formal", desc: "Professional, traditional, reserved" },
                            { value: "friendly", label: "Friendly", desc: "Warm, personable, approachable" },
                            { value: "casual", label: "Casual", desc: "Relaxed, conversational, laid-back" },
                            { value: "professional", label: "Professional", desc: "Expert, informative, precise" },
                            { value: "sales", label: "Sales-Oriented", desc: "Persuasive, enthusiastic, engaging" },
                          ].map((style) => (
                            <div 
                              key={style.value}
                              className={`cursor-pointer rounded-lg p-4 border transition-all ${
                                field.value === style.value
                                  ? "bg-gray-700 border-purple-500 shadow-md"
                                  : "bg-gray-800 border-gray-700 hover:border-gray-500"
                              }`}
                              onClick={() => form.setValue("aiResponseStyle", style.value as any)}
                            >
                              <h4 className="text-white font-medium">{style.label}</h4>
                              <p className="text-sm text-gray-400">{style.desc}</p>
                            </div>
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <CardWithGradient
                    color="none"
                    className="border-gray-700"
                    headerClassName="pb-0"
                    contentClassName="pt-0"
                    title={
                      <div className="flex items-center gap-2">
                        <Info className="h-4 w-4 text-teal-500" />
                        <span className="text-white text-base">Example Response Preview</span>
                      </div>
                    }
                  >
                    <div className="p-4 bg-gray-700/50 rounded-lg mb-4 relative mt-6 ml-8">
                      <div className="absolute -left-6 top-5 w-3 h-3 bg-gray-700/50 rotate-45"></div>
                      <p className="text-sm text-gray-300">
                        Hello! I'd like to book an appointment for next Tuesday.
                      </p>
                    </div>
                    
                    <div className="p-4 bg-gradient-to-r from-purple-500/20 to-teal-500/20 rounded-lg relative ml-auto mr-8 max-w-[80%]">
                      <div className="absolute -right-6 top-5 w-3 h-3 bg-gradient-to-r from-purple-500/20 to-teal-500/20 rotate-45"></div>
                      <p className="text-sm text-white">
                        {form.watch("aiResponseStyle") === "formal" && (
                          "Thank you for contacting us. I would be happy to assist you with booking an appointment for next Tuesday. May I kindly inquire about your preferred time slot? Our available hours on Tuesday are from 9:00 AM to 5:00 PM."
                        )}
                        {form.watch("aiResponseStyle") === "friendly" && (
                          "Hi there! I'd be thrilled to help you book an appointment for next Tuesday! What time works best for you? We're open from 9 AM to 5 PM, and I'd be happy to find the perfect slot for your schedule!"
                        )}
                        {form.watch("aiResponseStyle") === "casual" && (
                          "Hey! Sure thing, we can get you booked for next Tuesday. What time are you thinking? We're open 9 to 5, so just let me know what works for you and we'll get it set up."
                        )}
                        {form.watch("aiResponseStyle") === "professional" && (
                          "I'll be happy to assist with scheduling your appointment for next Tuesday. We have availability between 9:00 AM and 5:00 PM. What time would be most convenient for you? I'll ensure your appointment is confirmed immediately."
                        )}
                        {form.watch("aiResponseStyle") === "sales" && (
                          "Fantastic! We'd love to get you scheduled for next Tuesday! It's a great time to come in as we're currently offering a special promotion for Tuesday appointments. We have premium slots available between 9 AM and 5 PM - which would you prefer?"
                        )}
                      </p>
                    </div>
                  </CardWithGradient>
                </div>
              </CardWithGradient>
              
              <div className="flex justify-between">
                <Button 
                  type="button" 
                  onClick={() => setStep(2)}
                  variant="outline"
                  className="border-gray-700 hover:bg-gray-700"
                >
                  Back
                </Button>
                <Button 
                  type="submit"
                  className="bg-gradient-to-r from-purple-600 to-teal-500 hover:from-purple-700 hover:to-teal-600"
                  disabled={mutation.isPending}
                >
                  {mutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Saving...
                    </>
                  ) : (
                    <>
                      Save & Complete
                      <Check className="ml-2 h-4 w-4" />
                    </>
                  )}
                </Button>
              </div>
            </motion.div>
          )}
        </form>
      </Form>
    </DashboardLayout>
  );
};

export default BusinessSetup;

import React, { useEffect, useRef } from "react";
import { motion, useAnimation } from "framer-motion";
import { Link, useLocation } from "wouter";
import { useInView } from "framer-motion";
import GradientText from "@/components/ui/gradient-text";
import GradientBorder from "@/components/ui/gradient-border";
import Navbar from "@/components/site/navbar";
import Footer from "@/components/site/footer";
import Waveform from "@/components/ui/waveform";
import { ChevronDown, Check, Phone, Play, Brain, Calendar, File, MessageSquare, Globe, Smartphone } from "lucide-react";
import { useAuth } from "@/hooks/use-auth";
import { setupScrollAnimations } from "@/lib/animations";

const LandingPage = () => {
  const [_, navigate] = useLocation();
  const { user } = useAuth();
  
  // Scroll animations setup
  useEffect(() => {
    setupScrollAnimations();
  }, []);
  
  // Redirect to dashboard if already logged in
  useEffect(() => {
    if (user) {
      navigate("/dashboard");
    }
  }, [user, navigate]);

  // Scroll to section when hash changes
  useEffect(() => {
    const handleHashChange = () => {
      const hash = window.location.hash;
      if (hash) {
        const section = document.querySelector(hash);
        if (section) {
          section.scrollIntoView({ behavior: "smooth" });
        }
      }
    };

    handleHashChange(); // Initial check
    window.addEventListener("hashchange", handleHashChange);
    return () => window.removeEventListener("hashchange", handleHashChange);
  }, []);

  // FAQ Accordion functionality
  const toggleAccordion = (index: number) => {
    const accordions = document.querySelectorAll(".faq-accordion");
    const currentAccordion = accordions[index] as HTMLElement;
    const content = currentAccordion.querySelector(".faq-content") as HTMLElement;
    const icon = currentAccordion.querySelector("svg");
    
    const isExpanded = currentAccordion.getAttribute("aria-expanded") === "true";
    
    // Close all accordions first
    accordions.forEach((accordion) => {
      accordion.setAttribute("aria-expanded", "false");
      const accordionContent = accordion.querySelector(".faq-content") as HTMLElement;
      accordionContent.style.maxHeight = "0px";
      const accordionIcon = accordion.querySelector("svg");
      accordionIcon?.classList.remove("rotate-180");
    });
    
    // If clicking the already open accordion, it stays closed
    if (!isExpanded) {
      currentAccordion.setAttribute("aria-expanded", "true");
      content.style.maxHeight = `${content.scrollHeight}px`;
      icon?.classList.add("rotate-180");
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-gray-200 font-sans">
      <Navbar />
      
      {/* Hero Section */}
      <section className="relative pt-20 pb-20 md:pt-40 md:pb-24 overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900 to-gray-800 z-0"></div>
        <div className="absolute inset-0 opacity-30 z-0">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(124,58,237,0.15),transparent_70%)]"></div>
        </div>
        
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              className="space-y-6 text-center lg:text-left"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8 }}
            >
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-['Playfair_Display'] font-bold">
                <GradientText>AI-Powered</GradientText> Voice Assistant for Your Business
              </h1>
              <p className="text-lg md:text-xl text-gray-300 max-w-2xl mx-auto lg:mx-0">
                Connect your phone, train the AI, and let it handle customer calls 24/7. Seamlessly integrates with your existing phone number.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <GradientBorder>
                  <Link href="/auth">
                    <div className="px-8 py-3 rounded-md font-medium bg-gray-900 text-white w-full sm:w-auto text-center block cursor-pointer">
                      Get Started Now
                    </div>
                  </Link>
                </GradientBorder>
                <button className="flex items-center justify-center gap-2 px-8 py-3 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors duration-200 w-full sm:w-auto">
                  <Play className="h-5 w-5" />
                  Watch Demo
                </button>
              </div>
              <div className="text-sm text-gray-400 flex items-center justify-center lg:justify-start gap-4 pt-4">
                <div className="flex -space-x-2">
                  <div className="w-8 h-8 rounded-full border-2 border-gray-900 bg-gray-300 flex items-center justify-center text-gray-900 text-xs font-bold">JD</div>
                  <div className="w-8 h-8 rounded-full border-2 border-gray-900 bg-gray-300 flex items-center justify-center text-gray-900 text-xs font-bold">SK</div>
                  <div className="w-8 h-8 rounded-full border-2 border-gray-900 bg-gray-300 flex items-center justify-center text-gray-900 text-xs font-bold">ML</div>
                </div>
                <span>500+ businesses trust Astra</span>
              </div>
            </motion.div>
            
            <motion.div 
              className="relative"
              initial={{ opacity: 0, x: 50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, delay: 0.2 }}
            >
              <div className="relative bg-gray-800 rounded-xl shadow-xl p-6 hover:scale-[1.03] transition-all duration-500">
                <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-teal-500/10 rounded-xl"></div>
                <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600/20 to-teal-600/20 rounded-xl blur-sm opacity-50"></div>
                <div className="relative">
                  <div className="w-12 h-12 bg-gradient-to-br from-purple-600 to-teal-500 rounded-lg mb-6 flex items-center justify-center shadow-md">
                    <MessageSquare className="h-6 w-6 text-white" />
                  </div>
                  <div className="p-3 bg-gray-700 rounded-lg mb-4 relative">
                    <div className="absolute -left-3 top-3 w-2 h-2 bg-gray-700 rotate-45"></div>
                    <p className="text-sm text-gray-300">Hello! I'd like to book an appointment for next Tuesday.</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-purple-600/30 to-teal-500/30 rounded-lg mb-4 relative ml-auto max-w-[80%]">
                    <div className="absolute -right-3 top-3 w-2 h-2 bg-gradient-to-r from-purple-600/30 to-teal-500/30 rotate-45"></div>
                    <p className="text-sm">I'd be happy to help you book an appointment for next Tuesday. What time works best for you?</p>
                  </div>
                  <div className="p-3 bg-gray-700 rounded-lg mb-4 relative">
                    <div className="absolute -left-3 top-3 w-2 h-2 bg-gray-700 rotate-45"></div>
                    <p className="text-sm text-gray-300">Around 2pm if possible.</p>
                  </div>
                  <div className="p-3 bg-gradient-to-r from-purple-600/30 to-teal-500/30 rounded-lg relative ml-auto max-w-[80%]">
                    <div className="absolute -right-3 top-3 w-2 h-2 bg-gradient-to-r from-purple-600/30 to-teal-500/30 rotate-45"></div>
                    <p className="text-sm">Perfect! I've scheduled your appointment for next Tuesday at 2:00 PM. You'll receive a confirmation email shortly. Is there anything else you need help with?</p>
                  </div>
                  <div className="mt-6 flex items-center justify-between">
                    <div className="flex items-center">
                      <div className="w-10 h-10 rounded-full bg-purple-600/20 flex items-center justify-center mr-3">
                        <Brain className="h-5 w-5 text-purple-500" />
                      </div>
                      <span className="text-sm text-gray-400">Astra AI Assistant</span>
                    </div>
                    <div className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-400">
                      <span>Active</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-purple-600/20 rounded-full blur-3xl"></div>
              <div className="absolute -top-8 -left-8 w-32 h-32 bg-teal-600/20 rounded-full blur-3xl"></div>
            </motion.div>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section id="features" className="py-20 bg-gray-900 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-gray-900 to-gray-800 z-0"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16" data-animation="fade-in-up">
            <h2 className="text-3xl md:text-4xl font-['Playfair_Display'] font-bold mb-4">
              <GradientText>Powerful Features</GradientText> for Your Business
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Astra Intelligence transforms how your business handles customer calls with cutting-edge AI technology.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard 
              icon={<Phone className="text-purple-500" />}
              title="AI Call Handling"
              description="Let our AI assistant answer calls 24/7, providing instant responses to customer queries based on your business data."
              delay={0}
              color="purple"
            />
            
            <FeatureCard 
              icon={<Globe className="text-teal-500" />}
              title="Multi-language Support"
              description="Automatically detect and respond in multiple languages, broadening your customer base globally."
              delay={0.1}
              color="teal"
            />
            
            <FeatureCard 
              icon={<Calendar className="text-purple-500" />}
              title="Calendar Integration"
              description="Sync with Google Calendar to automatically schedule appointments and manage your business calendar."
              delay={0.2}
              color="purple"
            />
            
            <FeatureCard 
              icon={<Smartphone className="text-teal-500" />}
              title="Use Your Existing Number"
              description="No need for a new phone number. Astra works with your existing business number for seamless integration."
              delay={0.3}
              color="teal"
            />
            
            <FeatureCard 
              icon={<File className="text-purple-500" />}
              title="Call Transcripts & Logs"
              description="Review all AI-handled conversations with detailed transcripts and actionable insights."
              delay={0.4}
              color="purple"
            />
            
            <FeatureCard 
              icon={<Brain className="text-teal-500" />}
              title="Customizable AI Training"
              description="Train the AI with your specific business information to ensure accurate and personalized responses."
              delay={0.5}
              color="teal"
            />
          </div>
        </div>
      </section>
      
      {/* How It Works */}
      <section id="how-it-works" className="py-20 relative bg-gray-800">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(14,165,233,0.1),transparent_70%)]"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16" data-animation="fade-in-up">
            <h2 className="text-3xl md:text-4xl font-['Playfair_Display'] font-bold mb-4">
              <GradientText>How It Works</GradientText>
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Setting up Astra Intelligence is simple and takes just a few minutes.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <div className="relative" data-animation="fade-in-up">
              <div className="absolute -left-3 top-0 w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center font-bold text-xl shadow-lg z-10">1</div>
              <div className="h-full bg-gray-800/80 rounded-xl p-6 pl-10 border border-gray-700 hover:border-purple-500/30 transition-all duration-300 hover:scale-[1.02]">
                <h3 className="text-xl font-semibold mb-4 text-white">Connect Your Number</h3>
                <p className="text-gray-400">
                  Link your existing business phone number with Astra. No need to change your number or use any third-party services.
                </p>
              </div>
              <div className="absolute right-0 left-10 -bottom-8 h-2 border-dashed border-b-2 border-purple-500/30 hidden md:block"></div>
            </div>
            
            <div className="relative mt-12 md:mt-8" data-animation="fade-in-up" data-delay="0.2">
              <div className="absolute -left-3 top-0 w-10 h-10 rounded-full bg-teal-500 text-white flex items-center justify-center font-bold text-xl shadow-lg z-10">2</div>
              <div className="h-full bg-gray-800/80 rounded-xl p-6 pl-10 border border-gray-700 hover:border-teal-500/30 transition-all duration-300 hover:scale-[1.02]">
                <h3 className="text-xl font-semibold mb-4 text-white">Train Your AI</h3>
                <p className="text-gray-400">
                  Input your business information, services, and common customer questions to personalize the AI assistant.
                </p>
              </div>
              <div className="absolute right-10 left-0 -bottom-8 h-2 border-dashed border-b-2 border-teal-500/30 hidden md:block"></div>
            </div>
            
            <div className="relative mt-12 md:mt-0" data-animation="fade-in-up" data-delay="0.4">
              <div className="absolute -left-3 top-0 w-10 h-10 rounded-full bg-purple-600 text-white flex items-center justify-center font-bold text-xl shadow-lg z-10">3</div>
              <div className="h-full bg-gray-800/80 rounded-xl p-6 pl-10 border border-gray-700 hover:border-purple-500/30 transition-all duration-300 hover:scale-[1.02]">
                <h3 className="text-xl font-semibold mb-4 text-white">Go Live</h3>
                <p className="text-gray-400">
                  Activate your AI assistant and let it handle calls automatically. Monitor performance through your dashboard.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Dashboard Preview */}
      <section className="py-20 bg-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-gray-900 to-gray-800 z-0"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16" data-animation="fade-in-up">
            <h2 className="text-3xl md:text-4xl font-['Playfair_Display'] font-bold mb-4">
              <GradientText>Powerful Dashboard</GradientText> at Your Fingertips
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Monitor and manage your AI assistant through our intuitive and feature-rich dashboard.
            </p>
          </div>
          
          <div className="relative max-w-5xl mx-auto" data-animation="fade-in-up">
            <div className="absolute inset-0 bg-gradient-to-r from-purple-500/10 to-teal-500/10 rounded-xl transform translate-x-4 translate-y-4 blur-2xl"></div>
            <div className="relative bg-gray-800 rounded-xl shadow-xl p-6 border border-gray-700 hover:scale-[1.02] transition-all duration-500">
              <div className="rounded-lg w-full shadow-md bg-gray-900 p-6">
                <div className="mb-6">
                  <h3 className="text-xl font-semibold text-white mb-2">Call Analytics Dashboard</h3>
                  <p className="text-gray-400 text-sm">Monitor and optimize your AI assistant's performance</p>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                  <div className="bg-gray-800 rounded-lg p-4">
                    <div className="text-sm text-gray-400 mb-1">Total Calls</div>
                    <div className="text-2xl font-bold text-white">1,248</div>
                    <div className="text-xs text-green-400 mt-2 flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                      </svg>
                      14% increase
                    </div>
                  </div>
                  
                  <div className="bg-gray-800 rounded-lg p-4">
                    <div className="text-sm text-gray-400 mb-1">Success Rate</div>
                    <div className="text-2xl font-bold text-white">94.7%</div>
                    <div className="text-xs text-green-400 mt-2 flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 10l7-7m0 0l7 7m-7-7v18" />
                      </svg>
                      3.2% increase
                    </div>
                  </div>
                  
                  <div className="bg-gray-800 rounded-lg p-4">
                    <div className="text-sm text-gray-400 mb-1">Avg. Call Duration</div>
                    <div className="text-2xl font-bold text-white">2m 18s</div>
                    <div className="text-xs text-teal-400 mt-2 flex items-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 14l-7 7m0 0l-7-7m7 7V3" />
                      </svg>
                      5% decrease
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-800 rounded-lg p-4 mb-6">
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-white font-medium">Call Volume Trend</div>
                    <div className="flex space-x-2">
                      <button className="px-2 py-1 bg-gray-700 text-xs rounded text-gray-300">Daily</button>
                      <button className="px-2 py-1 bg-purple-600/30 text-xs rounded text-purple-300">Weekly</button>
                      <button className="px-2 py-1 bg-gray-700 text-xs rounded text-gray-300">Monthly</button>
                    </div>
                  </div>
                  
                  <div className="h-40 flex items-end space-x-2">
                    {[25, 40, 30, 50, 60, 55, 65, 75, 70, 60, 80, 90].map((height, i) => (
                      <div key={i} className="bg-gradient-to-t from-purple-600/70 to-teal-500/70 rounded-t flex-1" style={{ height: `${height}%` }}></div>
                    ))}
                  </div>
                  
                  <div className="flex justify-between mt-2 text-xs text-gray-500">
                    <span>Mon</span>
                    <span>Tue</span>
                    <span>Wed</span>
                    <span>Thu</span>
                    <span>Fri</span>
                    <span>Sat</span>
                    <span>Sun</span>
                    <span>Mon</span>
                    <span>Tue</span>
                    <span>Wed</span>
                    <span>Thu</span>
                    <span>Fri</span>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="bg-gray-800 rounded-lg p-4">
                    <div className="text-white font-medium mb-3">Top Call Categories</div>
                    <div className="space-y-2">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-400">Appointment Booking</span>
                          <span className="text-white">42%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-purple-600 h-2 rounded-full" style={{ width: "42%" }}></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-400">Service Inquiries</span>
                          <span className="text-white">28%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-teal-500 h-2 rounded-full" style={{ width: "28%" }}></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-400">Pricing Questions</span>
                          <span className="text-white">18%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-purple-600 h-2 rounded-full" style={{ width: "18%" }}></div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span className="text-gray-400">Other</span>
                          <span className="text-white">12%</span>
                        </div>
                        <div className="w-full bg-gray-700 rounded-full h-2">
                          <div className="bg-teal-500 h-2 rounded-full" style={{ width: "12%" }}></div>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-gray-800 rounded-lg p-4">
                    <div className="text-white font-medium mb-3">Recent Call Activity</div>
                    <div className="space-y-3">
                      <div className="flex gap-3 items-center">
                        <div className="w-8 h-8 rounded-full bg-purple-600/20 flex items-center justify-center">
                          <Phone className="h-4 w-4 text-purple-500" />
                        </div>
                        <div className="flex-1">
                          <div className="text-sm text-white">Appointment Request</div>
                          <div className="text-xs text-gray-400">10 minutes ago</div>
                        </div>
                        <div className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-400">
                          Resolved
                        </div>
                      </div>
                      
                      <div className="flex gap-3 items-center">
                        <div className="w-8 h-8 rounded-full bg-teal-600/20 flex items-center justify-center">
                          <Phone className="h-4 w-4 text-teal-500" />
                        </div>
                        <div className="flex-1">
                          <div className="text-sm text-white">Service Inquiry</div>
                          <div className="text-xs text-gray-400">27 minutes ago</div>
                        </div>
                        <div className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-400">
                          Resolved
                        </div>
                      </div>
                      
                      <div className="flex gap-3 items-center">
                        <div className="w-8 h-8 rounded-full bg-purple-600/20 flex items-center justify-center">
                          <Phone className="h-4 w-4 text-purple-500" />
                        </div>
                        <div className="flex-1">
                          <div className="text-sm text-white">Product Information</div>
                          <div className="text-xs text-gray-400">1 hour ago</div>
                        </div>
                        <div className="text-xs px-2 py-1 rounded-full bg-green-500/20 text-green-400">
                          Resolved
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="absolute -top-8 -left-8 w-32 h-32 bg-purple-600/20 rounded-full blur-3xl"></div>
            <div className="absolute -bottom-8 -right-8 w-32 h-32 bg-teal-600/20 rounded-full blur-3xl"></div>
          </div>
        </div>
      </section>
      
      {/* Mic Testing */}
      <section className="py-20 bg-gray-800 relative">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(124,58,237,0.1),transparent_70%)]"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="order-2 lg:order-1" data-animation="fade-in-right">
              <div className="bg-gray-900 rounded-xl p-8 shadow-xl border border-gray-700 hover:scale-[1.02] transition-all duration-300">
                <h3 className="text-2xl font-semibold mb-6 text-white">Mic Testing Tool</h3>
                <p className="text-gray-400 mb-6">
                  Ensure optimal performance with our built-in microphone testing and troubleshooting system.
                </p>
                
                <div className="p-4 bg-gray-800 rounded-lg mb-6">
                  <div className="flex justify-between items-center mb-4">
                    <div className="text-sm font-medium text-gray-300">Select Input Device</div>
                    <div className="relative inline-block w-52">
                      <select className="block appearance-none w-full bg-gray-700 border border-gray-600 text-white py-2 px-4 pr-8 rounded leading-tight focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-purple-500">
                        <option>Default Microphone</option>
                        <option>Built-in Microphone</option>
                        <option>Headset Microphone</option>
                        <option>USB Microphone</option>
                      </select>
                      <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-2 text-white">
                        <ChevronDown className="h-4 w-4" />
                      </div>
                    </div>
                  </div>
                  
                  <div className="mb-4">
                    <Waveform barCount={10} color="gradient" height="60px" />
                  </div>
                  
                  <div className="text-center">
                    <div className="inline-block px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-sm">
                      Microphone is working properly
                    </div>
                  </div>
                </div>
                
                <GradientBorder>
                  <button className="w-full px-4 py-3 rounded-md font-medium bg-gray-900 text-white flex items-center justify-center gap-2">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
                    </svg>
                    Fix My Microphone
                  </button>
                </GradientBorder>
              </div>
            </div>
            
            <div className="order-1 lg:order-2 space-y-6 text-center lg:text-left" data-animation="fade-in-left">
              <h2 className="text-3xl md:text-4xl font-['Playfair_Display'] font-bold mb-4">
                <GradientText>Built-in Tools</GradientText> For Optimal Performance
              </h2>
              <p className="text-gray-400 max-w-2xl mx-auto lg:mx-0">
                Astra Intelligence comes with powerful built-in tools to ensure your AI assistant functions flawlessly.
              </p>
              <ul className="space-y-4 text-left">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-600/20 flex items-center justify-center mt-1 flex-shrink-0">
                    <Check className="h-4 w-4 text-purple-500" />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Real-time Microphone Testing</h4>
                    <p className="text-sm text-gray-400">Quickly identify and resolve any audio input issues.</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-600/20 flex items-center justify-center mt-1 flex-shrink-0">
                    <Check className="h-4 w-4 text-teal-500" />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Automated Troubleshooting</h4>
                    <p className="text-sm text-gray-400">Get instant solutions for common audio and connection problems.</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-600/20 flex items-center justify-center mt-1 flex-shrink-0">
                    <Check className="h-4 w-4 text-purple-500" />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">AI Quality Testing</h4>
                    <p className="text-sm text-gray-400">Verify your AI's responses before going live.</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-teal-600/20 flex items-center justify-center mt-1 flex-shrink-0">
                    <Check className="h-4 w-4 text-teal-500" />
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Connection Diagnostics</h4>
                    <p className="text-sm text-gray-400">Verify your phone number integration is working properly.</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>
      
      {/* Pricing */}
      <section id="pricing" className="py-20 bg-gray-900 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900 via-gray-900 to-gray-800 z-0"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16" data-animation="fade-in-up">
            <h2 className="text-3xl md:text-4xl font-['Playfair_Display'] font-bold mb-4">
              <GradientText>Premium Service</GradientText> for Your Business
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Enterprise-grade AI voice assistant at an affordable price.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            {/* Premium Plan */}
            <div 
              className="bg-gray-800 rounded-xl p-8 border border-purple-500/30 shadow-xl relative hover:scale-[1.02]" 
              data-animation="fade-in-up" 
              data-delay="0.2"
            >
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-purple-600 to-teal-500 text-white text-xs font-bold uppercase tracking-wider py-1 px-4 rounded-full shadow-md">
                Premium
              </div>
              <div className="text-center">
                <h3 className="text-2xl font-semibold mb-3 text-white">Professional</h3>
                <div className="mb-4">
                  <span className="text-4xl font-bold text-white">₹2,000</span>
                  <span className="text-gray-400 text-sm">/month</span>
                </div>
                <p className="text-gray-400 text-sm mb-6">Complete business communication solution</p>
                <GradientBorder className="mb-6">
                  <Link href="/auth">
                    <div className="w-full px-4 py-2 rounded-md text-sm font-medium bg-gray-900 text-white block text-center cursor-pointer">
                      Get Started
                    </div>
                  </Link>
                </GradientBorder>
              </div>
              <div className="space-y-4">
                <PricingFeature text="Unlimited AI-handled calls" included={true} color="purple" />
                <PricingFeature text="Full call transcripts & analytics" included={true} color="purple" />
                <PricingFeature text="Google Calendar integration" included={true} color="purple" />
                <PricingFeature text="Phone number integration" included={true} color="purple" />
                <PricingFeature text="24/7 priority support" included={true} color="purple" />
                <PricingFeature text="Advanced AI training" included={true} color="purple" />
                <PricingFeature text="Multi-language support" included={true} color="purple" />
              </div>
            </div>
            
            {/* Enterprise Plan */}
            <div 
              className="bg-gray-800 rounded-xl p-8 border border-teal-500/30 shadow-xl relative hover:scale-[1.02]" 
              data-animation="fade-in-up" 
              data-delay="0.4"
            >
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 bg-gradient-to-r from-teal-600 to-blue-500 text-white text-xs font-bold uppercase tracking-wider py-1 px-4 rounded-full shadow-md">
                Enterprise
              </div>
              <div className="text-center">
                <h3 className="text-xl font-semibold mb-2 text-white">Enterprise</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold text-white">₹5,000</span>
                  <span className="text-gray-400 text-sm">/month</span>
                </div>
                <p className="text-gray-400 text-sm mb-6">For larger organizations</p>
                <GradientBorder className="mb-6">
                  <Link href="/auth">
                    <div className="w-full px-4 py-2 rounded-md text-sm font-medium bg-gray-900 text-white block text-center cursor-pointer">
                      Contact Sales
                    </div>
                  </Link>
                </GradientBorder>
              </div>
              <div className="space-y-3">
                <PricingFeature text="Everything in Professional plan" included={true} color="teal" />
                <PricingFeature text="Advanced AI customization" included={true} color="teal" />
                <PricingFeature text="Unlimited phone numbers" included={true} color="teal" />
                <PricingFeature text="Full API access" included={true} color="teal" />
                <PricingFeature text="Dedicated account manager" included={true} color="teal" />
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* FAQ */}
      <section id="faq" className="py-20 bg-gray-800 relative">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(14,165,233,0.1),transparent_70%)]"></div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="text-center mb-16" data-animation="fade-in-up">
            <h2 className="text-3xl md:text-4xl font-['Playfair_Display'] font-bold mb-4">
              <GradientText>Frequently Asked</GradientText> Questions
            </h2>
            <p className="text-gray-400 max-w-2xl mx-auto">
              Get answers to common questions about Astra Intelligence.
            </p>
          </div>
          
          <div className="max-w-3xl mx-auto space-y-6" data-animation="fade-in-up">
            <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden faq-accordion" aria-expanded="false">
              <button 
                className="flex justify-between items-center w-full p-6 text-left"
                onClick={() => toggleAccordion(0)}
              >
                <h3 className="text-lg font-medium text-white">How does Astra work with my existing phone number?</h3>
                <ChevronDown className="h-6 w-6 text-gray-400 transition-transform duration-200" />
              </button>
              <div className="faq-content overflow-hidden transition-all duration-300 h-0" style={{ maxHeight: 0 }}>
                <div className="p-6 pt-0 text-gray-400">
                  <p>Astra uses advanced call forwarding technology to integrate with your existing phone number. There's no need to change your number or use virtual numbers. When a call comes in, Astra's AI assistant answers it based on your trained business data.</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden faq-accordion" aria-expanded="false">
              <button 
                className="flex justify-between items-center w-full p-6 text-left"
                onClick={() => toggleAccordion(1)}
              >
                <h3 className="text-lg font-medium text-white">How do I train the AI with my business information?</h3>
                <ChevronDown className="h-6 w-6 text-gray-400 transition-transform duration-200" />
              </button>
              <div className="faq-content overflow-hidden transition-all duration-300 h-0" style={{ maxHeight: 0 }}>
                <div className="p-6 pt-0 text-gray-400">
                  <p>After signing up, you'll access our AI Training page where you input important business details like services, pricing, hours, common customer questions, and your preferred response style. The AI learns from this information to provide accurate responses.</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden faq-accordion" aria-expanded="false">
              <button 
                className="flex justify-between items-center w-full p-6 text-left"
                onClick={() => toggleAccordion(2)}
              >
                <h3 className="text-lg font-medium text-white">Is Astra secure and private?</h3>
                <ChevronDown className="h-6 w-6 text-gray-400 transition-transform duration-200" />
              </button>
              <div className="faq-content overflow-hidden transition-all duration-300 h-0" style={{ maxHeight: 0 }}>
                <div className="p-6 pt-0 text-gray-400">
                  <p>Yes, security is our top priority. All call data and business information is encrypted both in transit and at rest. We implement enterprise-grade security measures and are compliant with industry standards for data protection.</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden faq-accordion" aria-expanded="false">
              <button 
                className="flex justify-between items-center w-full p-6 text-left"
                onClick={() => toggleAccordion(3)}
              >
                <h3 className="text-lg font-medium text-white">Can I monitor the quality of AI responses?</h3>
                <ChevronDown className="h-6 w-6 text-gray-400 transition-transform duration-200" />
              </button>
              <div className="faq-content overflow-hidden transition-all duration-300 h-0" style={{ maxHeight: 0 }}>
                <div className="p-6 pt-0 text-gray-400">
                  <p>Absolutely. The dashboard provides full access to call logs and transcripts. You can review AI responses, listen to call recordings, and make adjustments to the AI training if needed to improve future interactions.</p>
                </div>
              </div>
            </div>
            
            <div className="bg-gray-800 rounded-xl border border-gray-700 overflow-hidden faq-accordion" aria-expanded="false">
              <button 
                className="flex justify-between items-center w-full p-6 text-left"
                onClick={() => toggleAccordion(4)}
              >
                <h3 className="text-lg font-medium text-white">What languages does Astra support?</h3>
                <ChevronDown className="h-6 w-6 text-gray-400 transition-transform duration-200" />
              </button>
              <div className="faq-content overflow-hidden transition-all duration-300 h-0" style={{ maxHeight: 0 }}>
                <div className="p-6 pt-0 text-gray-400">
                  <p>Astra supports over 30 languages including English, Spanish, French, German, Chinese, Japanese, and more. The AI can automatically detect the caller's language and respond appropriately if you enable that feature.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      
      {/* Call To Action */}
      <section className="py-20 bg-gray-900 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-900 to-gray-800 z-0"></div>
        <div className="absolute top-0 left-0 right-0 bottom-0 w-full h-full">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 to-teal-900/20"></div>
        </div>
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="max-w-4xl mx-auto text-center" data-animation="fade-in-up">
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-['Playfair_Display'] font-bold mb-6">
              <GradientText>Ready to Transform</GradientText> Your Business?
            </h2>
            <p className="text-xl text-gray-300 mb-10 max-w-2xl mx-auto">
              Join thousands of businesses already using Astra Intelligence to handle customer calls 24/7.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <GradientBorder>
                <Link href="/auth">
                  <div className="px-8 py-4 rounded-md font-medium bg-gray-900 text-white w-full sm:w-auto text-lg block text-center cursor-pointer">
                    Get Started Now
                  </div>
                </Link>
              </GradientBorder>
              <button className="flex items-center justify-center gap-2 px-8 py-4 rounded-md bg-gray-800 text-white hover:bg-gray-700 transition-colors duration-200 w-full sm:w-auto text-lg">
                <Phone className="h-5 w-5" />
                Schedule Demo
              </button>
            </div>
            <p className="text-gray-400 mt-6">
              Premium service • Enhanced security • 24/7 support
            </p>
          </div>
        </div>
      </section>
      
      <Footer />
    </div>
  );
};

// Feature Card Component
interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  delay?: number;
  color?: "purple" | "teal";
}

const FeatureCard: React.FC<FeatureCardProps> = ({ icon, title, description, delay = 0, color = "purple" }) => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });
  const controls = useAnimation();
  
  useEffect(() => {
    if (isInView) {
      controls.start({ opacity: 1, y: 0, transition: { duration: 0.5, delay } });
    }
  }, [isInView, controls, delay]);
  
  return (
    <motion.div
      ref={ref}
      initial={{ opacity: 0, y: 50 }}
      animate={controls}
      className={`bg-gray-800/50 rounded-xl p-6 hover:scale-[1.03] transition-all duration-300 border border-gray-700/50 hover:border-${color}-500/30 group`}
    >
      <div className={`w-12 h-12 bg-${color}-600/20 rounded-lg mb-6 flex items-center justify-center group-hover:bg-${color}-600/30 transition-colors duration-300`}>
        {icon}
      </div>
      <h3 className="text-xl font-semibold mb-3 text-white">{title}</h3>
      <p className="text-gray-400">
        {description}
      </p>
    </motion.div>
  );
};

// Pricing Feature Component
interface PricingFeatureProps {
  text: string;
  included: boolean;
  color?: "teal" | "purple";
}

const PricingFeature: React.FC<PricingFeatureProps> = ({ text, included, color = "teal" }) => {
  return (
    <div className="flex items-center gap-3">
      {included ? (
        <Check className={`h-4 w-4 text-${color}-500`} />
      ) : (
        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
        </svg>
      )}
      <span className={`text-${included ? "gray-300" : "gray-500"} text-sm`}>{text}</span>
    </div>
  );
};

export default LandingPage;

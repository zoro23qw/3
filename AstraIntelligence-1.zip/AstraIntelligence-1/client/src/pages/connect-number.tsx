import React, { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import DashboardLayout from "@/components/layout/dashboard-layout";
import CardWithGradient from "@/components/ui/card-with-gradient";
import GradientText from "@/components/ui/gradient-text";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { cn } from "@/lib/utils";
import {
  Phone,
  Check,
  Smartphone,
  PhoneCall,
  PhoneForwarded,
  Loader2,
  CheckCircle2,
  ArrowRight,
  AlertCircle,
  Info,
  RefreshCw
} from "lucide-react";

import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const ConnectNumber = () => {
  const [activeTab, setActiveTab] = useState("existing");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [otpCode, setOtpCode] = useState(["", "", "", "", "", ""]);
  const [isVerificationSent, setIsVerificationSent] = useState(false);
  const [isVerified, setIsVerified] = useState(false);
  const [isForwarding, setIsForwarding] = useState(false);
  const [step, setStep] = useState(1);
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const { user } = useAuth();
  
  // Initialize phone number if it exists
  useEffect(() => {
    if (user?.phoneNumber) {
      setPhoneNumber(user.phoneNumber);
    }
    
    // If number is already connected, skip to final step
    if (user?.numberConnected) {
      setIsVerified(true);
      setIsVerificationSent(true);
      setStep(3);
    }
  }, [user]);
  
  // Format phone number as user types
  const formatPhoneNumber = (value: string) => {
    // Strip all non-numeric characters
    const cleaned = value.replace(/\D/g, "");
    
    // Format the number with proper spacing/dashes
    let formatted = cleaned;
    if (cleaned.length > 0) {
      // Different formats based on length
      if (cleaned.length <= 3) {
        formatted = cleaned;
      } else if (cleaned.length <= 6) {
        formatted = `${cleaned.slice(0, 3)}-${cleaned.slice(3)}`;
      } else if (cleaned.length <= 10) {
        formatted = `${cleaned.slice(0, 3)}-${cleaned.slice(3, 6)}-${cleaned.slice(6)}`;
      } else {
        formatted = `+${cleaned.slice(0, 1)} (${cleaned.slice(1, 4)}) ${cleaned.slice(4, 7)}-${cleaned.slice(7, 11)}`;
      }
    }
    
    return formatted;
  };
  
  // Handle phone number input change
  const handlePhoneChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setPhoneNumber(formatPhoneNumber(value));
  };
  
  // Handle OTP input change
  const handleOtpChange = (index: number, value: string) => {
    // Only allow numeric input
    if (value && !/^\d*$/.test(value)) return;
    
    // Update the OTP array
    const newOtp = [...otpCode];
    newOtp[index] = value;
    setOtpCode(newOtp);
    
    // If a digit was entered and we're not at the last input, focus the next one
    if (value && index < 5) {
      const nextInput = document.getElementById(`otp-${index + 1}`);
      if (nextInput) {
        nextInput.focus();
      }
    }
  };
  
  // Handle OTP keydown for backspace navigation
  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    // If backspace is pressed and the current field is empty, focus the previous field
    if (e.key === "Backspace" && !otpCode[index] && index > 0) {
      const prevInput = document.getElementById(`otp-${index - 1}`);
      if (prevInput) {
        prevInput.focus();
      }
    }
  };
  
  // Paste OTP from clipboard
  const handleOtpPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    e.preventDefault();
    const pastedData = e.clipboardData.getData("text").trim();
    
    // Check if pasted content is numeric and has a reasonable length
    if (/^\d+$/.test(pastedData) && pastedData.length <= 6) {
      // Split the pasted data into individual digits
      const digits = pastedData.split("").slice(0, 6);
      
      // Fill the OTP array with these digits
      const newOtp = [...otpCode];
      digits.forEach((digit, index) => {
        if (index < 6) newOtp[index] = digit;
      });
      
      setOtpCode(newOtp);
      
      // Focus the appropriate field based on how many digits were pasted
      if (digits.length < 6) {
        const nextInput = document.getElementById(`otp-${digits.length}`);
        if (nextInput) {
          nextInput.focus();
        }
      }
    }
  };
  
  // Send verification code
  const sendVerification = async () => {
    if (!phoneNumber || phoneNumber.length < 10) {
      toast({
        title: "Invalid phone number",
        description: "Please enter a valid phone number",
        variant: "destructive",
      });
      return;
    }
    
    try {
      toast({
        title: "Verification code sent",
        description: `A 6-digit code has been sent to ${phoneNumber}`,
      });
      
      // In a real implementation, this would send an OTP to the phone number
      setIsVerificationSent(true);
      
      // For demo purposes, set a success OTP
      // In production, this would be sent via SMS and not exposed here
      setOtpCode(["1", "2", "3", "4", "5", "6"]);
    } catch (error) {
      toast({
        title: "Failed to send verification",
        description: "Please try again later",
        variant: "destructive",
      });
    }
  };
  
  // Verify OTP code
  const verifyOtp = async () => {
    const enteredOtp = otpCode.join("");
    
    if (enteredOtp.length !== 6) {
      toast({
        title: "Invalid code",
        description: "Please enter all 6 digits of the verification code",
        variant: "destructive",
      });
      return;
    }
    
    try {
      // In a real implementation, this would verify the OTP with a server
      
      // For demo purposes, any 6-digit code will work
      toast({
        title: "Phone number verified",
        description: "Your phone number has been successfully verified",
      });
      
      setIsVerified(true);
      setStep(2);
    } catch (error) {
      toast({
        title: "Verification failed",
        description: "The code you entered is incorrect",
        variant: "destructive",
      });
    }
  };
  
  // Setup call forwarding
  const setupForwarding = async () => {
    setIsForwarding(true);
    
    try {
      // In a real implementation, this would setup call forwarding with a phone service
      const res = await apiRequest("POST", "/api/connect-number", { phoneNumber });
      
      // Simulate a delay for the demo
      setTimeout(() => {
        toast({
          title: "Call forwarding setup complete",
          description: "Your phone number is now connected to Astra Intelligence",
        });
        
        setIsForwarding(false);
        setStep(3);
        
        // Refresh user data to update the numberConnected flag
        queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      }, 2000);
    } catch (error) {
      setIsForwarding(false);
      toast({
        title: "Setup failed",
        description: "Failed to setup call forwarding. Please try again later.",
        variant: "destructive",
      });
    }
  };
  
  // Function to render the appropriate step content
  const renderStepContent = () => {
    switch (step) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="grid grid-cols-1 gap-6">
              <div>
                <label htmlFor="phoneNumber" className="block text-sm font-medium text-gray-300 mb-2">
                  Enter Your Phone Number
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                    <Phone className="h-5 w-5 text-gray-400" />
                  </div>
                  <Input
                    id="phoneNumber"
                    className="pl-10 bg-gray-700 border-gray-600"
                    placeholder="+1 (555) 123-4567"
                    value={phoneNumber}
                    onChange={handlePhoneChange}
                  />
                </div>
                <p className="mt-2 text-sm text-gray-400">
                  Enter the phone number you want to connect with Astra Intelligence
                </p>
              </div>
            </div>
            
            <div className="rounded-lg bg-gray-800 border border-gray-700 p-4 space-y-4">
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-purple-600/20 flex items-center justify-center mt-1 flex-shrink-0">
                  <Check className="h-4 w-4 text-purple-500" />
                </div>
                <div>
                  <h4 className="font-medium text-white">Keep Your Existing Number</h4>
                  <p className="text-sm text-gray-400">You'll continue to use your same phone number.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-teal-600/20 flex items-center justify-center mt-1 flex-shrink-0">
                  <Check className="h-4 w-4 text-teal-500" />
                </div>
                <div>
                  <h4 className="font-medium text-white">No Hardware Changes</h4>
                  <p className="text-sm text-gray-400">No need to change SIM cards or devices.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <div className="w-6 h-6 rounded-full bg-purple-600/20 flex items-center justify-center mt-1 flex-shrink-0">
                  <Check className="h-4 w-4 text-purple-500" />
                </div>
                <div>
                  <h4 className="font-medium text-white">Private & Secure</h4>
                  <p className="text-sm text-gray-400">Your communications remain private and encrypted.</p>
                </div>
              </div>
            </div>
            
            {isVerificationSent ? (
              <div className="space-y-6">
                <div>
                  <label className="block text-sm font-medium text-gray-300 mb-2">
                    Enter Verification Code
                  </label>
                  <div className="flex justify-between gap-2">
                    {[0, 1, 2, 3, 4, 5].map((index) => (
                      <Input
                        key={index}
                        id={`otp-${index}`}
                        className="w-12 h-12 text-center text-lg font-medium bg-gray-700 border-gray-600"
                        value={otpCode[index]}
                        onChange={(e) => handleOtpChange(index, e.target.value)}
                        onKeyDown={(e) => handleOtpKeyDown(index, e)}
                        onPaste={index === 0 ? handleOtpPaste : undefined}
                        maxLength={1}
                      />
                    ))}
                  </div>
                  <p className="mt-2 text-sm text-gray-400">
                    We've sent a 6-digit code to {phoneNumber}
                  </p>
                </div>
                
                <div className="flex justify-between">
                  <Button
                    variant="outline"
                    className="border-gray-700 hover:bg-gray-700"
                    onClick={() => setIsVerificationSent(false)}
                  >
                    Edit Number
                  </Button>
                  <Button
                    className="bg-gradient-to-r from-purple-600 to-teal-500 hover:from-purple-700 hover:to-teal-600"
                    onClick={verifyOtp}
                  >
                    Verify Code
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex justify-end">
                <Button
                  className="bg-purple-600 hover:bg-purple-700"
                  onClick={sendVerification}
                >
                  Send Verification Code
                </Button>
              </div>
            )}
          </div>
        );
      
      case 2:
        return (
          <div className="space-y-6">
            <div className="rounded-lg bg-gray-800 border border-gray-700 p-4">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-12 h-12 rounded-full bg-green-600/20 flex items-center justify-center">
                  <CheckCircle2 className="h-6 w-6 text-green-500" />
                </div>
                <div>
                  <h3 className="text-lg font-medium text-white">Phone Number Verified</h3>
                  <p className="text-sm text-gray-400">{phoneNumber} has been successfully verified</p>
                </div>
              </div>
              
              <div className="p-4 bg-gray-700 rounded-lg">
                <h4 className="font-medium text-white mb-2">Next Step: Setup Call Forwarding</h4>
                <p className="text-sm text-gray-300">
                  Astra will now set up call forwarding to allow the AI assistant to handle your calls. This process:
                </p>
                <ul className="mt-2 space-y-1 text-sm text-gray-300">
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-teal-500 flex-shrink-0" />
                    <span>Lets you keep your existing phone number</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-teal-500 flex-shrink-0" />
                    <span>Works with your current mobile carrier</span>
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-4 w-4 text-teal-500 flex-shrink-0" />
                    <span>Can be turned on or off anytime</span>
                  </li>
                </ul>
              </div>
            </div>
            
            <Alert className="bg-amber-900/20 border-amber-900/30">
              <Info className="h-4 w-4" />
              <AlertTitle>Important Information</AlertTitle>
              <AlertDescription>
                Once call forwarding is active, the AI will handle incoming calls based on your AI settings. You can always change these settings later.
              </AlertDescription>
            </Alert>
            
            <div className="flex justify-end">
              <Button
                className="bg-gradient-to-r from-purple-600 to-teal-500 hover:from-purple-700 hover:to-teal-600"
                onClick={setupForwarding}
                disabled={isForwarding}
              >
                {isForwarding ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Setting Up...
                  </>
                ) : (
                  <>
                    <PhoneForwarded className="mr-2 h-4 w-4" />
                    Setup Call Forwarding
                  </>
                )}
              </Button>
            </div>
          </div>
        );
      
      case 3:
        return (
          <div className="space-y-6">
            <div className="flex items-center justify-center py-8">
              <div className="text-center">
                <div className="w-20 h-20 rounded-full bg-green-600/20 flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 className="h-10 w-10 text-green-500" />
                </div>
                <h3 className="text-2xl font-semibold text-white mb-2">Setup Complete!</h3>
                <p className="text-gray-300">
                  Your phone number {phoneNumber} is now connected to Astra Intelligence
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <CardWithGradient
                color="purple"
                contentClassName="p-4"
                className="hover:border-purple-500/30"
              >
                <div className="flex flex-col items-center text-center">
                  <PhoneCall className="h-8 w-8 mb-3 text-purple-500" />
                  <h4 className="font-medium text-white mb-1">Active AI Assistant</h4>
                  <p className="text-sm text-gray-400">Your AI is now ready to handle calls</p>
                </div>
              </CardWithGradient>
              
              <CardWithGradient
                color="teal"
                contentClassName="p-4"
                className="hover:border-teal-500/30"
              >
                <div className="flex flex-col items-center text-center">
                  <Smartphone className="h-8 w-8 mb-3 text-teal-500" />
                  <h4 className="font-medium text-white mb-1">Keep Your Phone</h4>
                  <p className="text-sm text-gray-400">Continue using your device normally</p>
                </div>
              </CardWithGradient>
              
              <CardWithGradient
                color="purple"
                contentClassName="p-4"
                className="hover:border-purple-500/30"
              >
                <div className="flex flex-col items-center text-center">
                  <RefreshCw className="h-8 w-8 mb-3 text-purple-500" />
                  <h4 className="font-medium text-white mb-1">Reversible Anytime</h4>
                  <p className="text-sm text-gray-400">You can disconnect at any time</p>
                </div>
              </CardWithGradient>
            </div>
            
            <div className="rounded-lg bg-gray-800 border border-gray-700 p-4">
              <h4 className="font-medium text-white mb-3">What Happens Next?</h4>
              <div className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-gray-700 flex items-center justify-center mt-1 flex-shrink-0">
                    <span className="text-xs font-medium">1</span>
                  </div>
                  <p className="text-sm text-gray-300">Incoming calls to your number will now be handled by your Astra AI assistant.</p>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-gray-700 flex items-center justify-center mt-1 flex-shrink-0">
                    <span className="text-xs font-medium">2</span>
                  </div>
                  <p className="text-sm text-gray-300">The AI will answer according to the business information you provided during setup.</p>
                </div>
                
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-gray-700 flex items-center justify-center mt-1 flex-shrink-0">
                    <span className="text-xs font-medium">3</span>
                  </div>
                  <p className="text-sm text-gray-300">You'll receive notifications for calls and can review transcripts in your dashboard.</p>
                </div>
              </div>
            </div>
            
            <div className="flex justify-between">
              <Button
                variant="outline"
                className="border-gray-700 hover:bg-gray-700"
                onClick={() => {
                  setStep(1);
                  setIsVerificationSent(false);
                  setIsVerified(false);
                }}
              >
                Start Over
              </Button>
              
              <Button
                className="bg-gradient-to-r from-purple-600 to-teal-500 hover:from-purple-700 hover:to-teal-600"
                onClick={() => navigate("/dashboard")}
              >
                Go to Dashboard
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <DashboardLayout title="Connect Number" subtitle="Phone Setup">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <CardWithGradient
              color="gradient"
              icon={<Phone size={24} />}
              title={<GradientText className="text-xl">Connect Your Phone Number</GradientText>}
              description="Link your existing phone number with Astra Intelligence."
            >
              <Tabs defaultValue="existing" value={activeTab} onValueChange={setActiveTab} className="mb-6">
                <TabsList className="bg-gray-800 border-gray-700">
                  <TabsTrigger 
                    value="existing" 
                    className={cn(
                      "data-[state=active]:bg-gray-700",
                      step > 1 && "pointer-events-none opacity-50"
                    )}
                  >
                    Use Existing Number
                  </TabsTrigger>
                  <TabsTrigger 
                    value="new" 
                    className={cn(
                      "data-[state=active]:bg-gray-700",
                      step > 1 && "pointer-events-none opacity-50"
                    )}
                    disabled
                  >
                    Get New Number
                  </TabsTrigger>
                </TabsList>
                
                <TabsContent value="existing" className="pt-6">
                  {renderStepContent()}
                </TabsContent>
                
                <TabsContent value="new" className="pt-6">
                  <div className="text-center py-10">
                    <AlertCircle className="h-16 w-16 text-gray-500 mx-auto mb-4" />
                    <h3 className="text-xl font-medium text-white mb-2">Coming Soon</h3>
                    <p className="text-gray-400 max-w-md mx-auto">
                      The ability to get a new number is coming soon. For now, you can connect your existing number.
                    </p>
                  </div>
                </TabsContent>
              </Tabs>
            </CardWithGradient>
          </motion.div>
        </div>
        
        <div>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <CardWithGradient
              color="purple"
              title="Connection Process"
              description="How we connect your phone number"
              className="lg:sticky lg:top-24"
            >
              <div className="space-y-6">
                <div className={`flex items-start gap-4 ${step >= 1 ? "opacity-100" : "opacity-50"}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${step > 1 ? "bg-green-600/20 text-green-500" : "bg-purple-600/20 text-white"}`}>
                    {step > 1 ? <Check className="h-4 w-4" /> : <span>1</span>}
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Verify Ownership</h4>
                    <p className="text-sm text-gray-400">
                      We verify that you own the phone number by sending a code via SMS.
                    </p>
                  </div>
                </div>
                
                <div className={`flex items-start gap-4 ${step >= 2 ? "opacity-100" : "opacity-50"}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${step > 2 ? "bg-green-600/20 text-green-500" : "bg-purple-600/20 text-white"}`}>
                    {step > 2 ? <Check className="h-4 w-4" /> : <span>2</span>}
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Setup Forwarding</h4>
                    <p className="text-sm text-gray-400">
                      We configure call forwarding so the AI can answer calls to your number.
                    </p>
                  </div>
                </div>
                
                <div className={`flex items-start gap-4 ${step >= 3 ? "opacity-100" : "opacity-50"}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${step === 3 ? "bg-green-600/20 text-green-500" : "bg-purple-600/20 text-white"}`}>
                    {step === 3 ? <Check className="h-4 w-4" /> : <span>3</span>}
                  </div>
                  <div>
                    <h4 className="font-medium text-white">Start Using AI</h4>
                    <p className="text-sm text-gray-400">
                      Your AI assistant is ready to handle calls based on your business settings.
                    </p>
                  </div>
                </div>
                
                <div className="rounded-lg bg-gray-800 border border-gray-700 p-4 mt-6">
                  <h4 className="font-medium text-white mb-2 flex items-center">
                    <Info className="h-4 w-4 mr-2 text-teal-500" />
                    How It Works
                  </h4>
                  <p className="text-sm text-gray-400">
                    Astra uses conditional call forwarding technology, which means:
                  </p>
                  <ul className="mt-2 space-y-1 text-sm text-gray-400">
                    <li>• You keep your existing number</li>
                    <li>• No SIM card changes needed</li>
                    <li>• Works with all major carriers</li>
                    <li>• Can be disabled anytime</li>
                  </ul>
                </div>
              </div>
            </CardWithGradient>
          </motion.div>
        </div>
      </div>
    </DashboardLayout>
  );
};

export default ConnectNumber;

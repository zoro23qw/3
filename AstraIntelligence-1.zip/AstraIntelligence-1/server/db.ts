import { drizzle } from 'drizzle-orm/postgres-js';
import postgres from 'postgres';
import { eq, desc } from 'drizzle-orm';
import { Pool } from 'pg';

// Create a database connection using environment variables
const queryClient = postgres(process.env.DATABASE_URL!, { ssl: 'require' });
export const db = drizzle(queryClient);

// Define interfaces to match PostgreSQL pool requirements
interface PgPoolClient {
  release: () => void;
  query: (text: string, params: any[]) => Promise<any>;
}

// Export extended pool-compatible interface for session store
export const pool = {
  query: (text: string, params: any[]) => queryClient.unsafe(text, params),
  connect: () => Promise.resolve({
    release: () => {},
    query: (text: string, params: any[]) => queryClient.unsafe(text, params)
  }),
  // Add missing Pool properties to satisfy type checking
  totalCount: 0,
  idleCount: 0,
  waitingCount: 0,
  end: () => Promise.resolve(),
  on: () => ({}),
  // Add other required Pool methods with minimal implementations
  options: {},
  ended: false,
  status: 'ready',
  stats: () => ({}),
} as unknown as Pool;

// Export helpers
export { eq, desc };
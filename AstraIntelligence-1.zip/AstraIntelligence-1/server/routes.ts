import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBusinessInfoSchema, insertUserSettingsSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup auth routes (/api/register, /api/login, /api/logout, /api/user)
  setupAuth(app);

  // Business info routes
  app.get("/api/business-info", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    const businessInfo = await storage.getBusinessInfo(userId);
    if (!businessInfo) {
      return res.status(404).json({ message: "Business info not found" });
    }
    
    res.json(businessInfo);
  });

  app.post("/api/business-info", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      // Validate request body
      const validatedData = insertBusinessInfoSchema.parse({
        ...req.body,
        userId
      });
      
      // Check if business info already exists for this user
      const existingInfo = await storage.getBusinessInfo(userId);
      
      if (existingInfo) {
        // Update existing business info
        const updatedInfo = await storage.updateBusinessInfo(userId, validatedData);
        return res.json(updatedInfo);
      } else {
        // Create new business info
        const newInfo = await storage.createBusinessInfo(validatedData);
        return res.status(201).json(newInfo);
      }
    } catch (error) {
      next(error);
    }
  });

  // Call logs routes
  app.get("/api/call-logs", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    const callLogs = await storage.getCallLogs(userId);
    res.json(callLogs);
  });

  app.post("/api/call-logs", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      const callLog = await storage.createCallLog({
        ...req.body,
        userId
      });
      
      res.status(201).json(callLog);
    } catch (error) {
      next(error);
    }
  });

  // User settings routes
  app.get("/api/settings", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    const settings = await storage.getUserSettings(userId);
    if (!settings) {
      return res.status(404).json({ message: "User settings not found" });
    }
    
    res.json(settings);
  });

  app.post("/api/settings", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      // Validate request body
      const validatedData = insertUserSettingsSchema.parse({
        ...req.body,
        userId
      });
      
      // Check if settings already exist for this user
      const existingSettings = await storage.getUserSettings(userId);
      
      if (existingSettings) {
        // Update existing settings
        const updatedSettings = await storage.updateUserSettings(userId, validatedData);
        return res.json(updatedSettings);
      } else {
        // Create new settings
        const newSettings = await storage.createUserSettings(validatedData);
        return res.status(201).json(newSettings);
      }
    } catch (error) {
      next(error);
    }
  });
  
  app.patch("/api/settings/:userId", async (req, res, next) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const requestUserId = parseInt(req.params.userId);
    const currentUserId = req.user!.id;
    
    // Ensure users can only modify their own settings
    if (requestUserId !== currentUserId) {
      return res.status(403).json({ message: "Unauthorized to modify these settings" });
    }
    
    try {
      const updatedSettings = await storage.updateUserSettings(requestUserId, req.body);
      
      if (!updatedSettings) {
        // If settings don't exist yet, create them
        const newSettings = await storage.createUserSettings({
          userId: requestUserId,
          ...req.body,
          aiResponseStyle: req.body.aiResponseStyle || 'professional',
          inputLanguage: req.body.inputLanguage || 'auto',
          outputLanguage: req.body.outputLanguage || 'en-IN',
          autoDetectLanguage: req.body.autoDetectLanguage ?? true,
          aiCallHandlingEnabled: req.body.aiCallHandlingEnabled ?? true,
          calendarSyncEnabled: req.body.calendarSyncEnabled ?? false
        });
        return res.status(201).json(newSettings);
      }
      
      return res.json(updatedSettings);
    } catch (error) {
      next(error);
    }
  });

  // Phone number connection
  app.post("/api/connect-number", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = req.user!.id;
    
    try {
      // In a real app, this would connect to a phone service API
      // For now, we'll just update the numberConnected flag
      const user = await storage.updateUser(userId, { numberConnected: true });
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({ success: true, user });
    } catch (error) {
      res.status(500).json({ message: "Failed to connect phone number" });
    }
  });

  // API keys endpoint - available to all users for demo purposes
  app.get("/api/config", (req, res) => {
    res.json({
      geminiApiKey: process.env.GEMINI_API_KEY,
      firebaseConfig: {
        apiKey: process.env.FIREBASE_API_KEY,
        projectId: process.env.FIREBASE_PROJECT_ID,
        appId: process.env.FIREBASE_APP_ID,
        authDomain: process.env.FIREBASE_AUTH_DOMAIN,
        storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
        messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID
      }
    });
  });
  
  // AI assistant endpoints for the test page
  app.post("/api/ai/query", async (req, res) => {
    try {
      const { query, businessInfo, language } = req.body;
      
      if (!query || !businessInfo) {
        return res.status(400).json({ error: "Missing required parameters" });
      }
      
      // In a real application, this would call the Gemini API directly
      // For demo purposes, we'll proxy through the server
      const { GoogleGenerativeAI } = require("@google/generative-ai");
      const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
      
      // Determine language for response
      let languageInstructions = "";
      if (language === 'hi-IN') {
        languageInstructions = "Respond in Hindi using Devanagari script.";
      } else if (language === 'gu-IN') {
        languageInstructions = "Respond in Gujarati using Gujarati script.";
      } else if (language === 'auto') {
        languageInstructions = "Detect the language of the query and respond in the same language (English, Hindi, or Gujarati). If you're unsure, respond in English.";
      } else {
        languageInstructions = "Respond in English.";
      }
      
      // Restaurant-specific instructions
      const industrySpecificInstructions = businessInfo.industry === "Restaurant/Food" ? 
        `
        Since you are a restaurant voice assistant:
        - For reservations, ask for date, time, party size, and contact information if not provided
        - For menu inquiries, be detailed about ingredients, spice levels, and preparation methods
        - For delivery orders, confirm the items, address, and estimated delivery time
        - Be knowledgeable about special dietary options (vegetarian, vegan, gluten-free, etc.)
        - Politely handle complaints while promising to address the issue
        - Sound warm and hospitable, as if the caller is a valued guest
        ` : "";
      
      const model = genAI.getGenerativeModel({ model: "gemini-pro" });
      
      const prompt = `
      You are an AI voice assistant for the following business:
      
      Business Name: ${businessInfo.name || "Aroma Restaurant"}
      Industry: ${businessInfo.industry || "Restaurant/Food"}
      Services: ${businessInfo.services || "North Indian and South Indian cuisine, catering, takeout and delivery services"}
      Business Hours: ${businessInfo.businessHours || "Mon-Sun: 11am-10pm"}
      Common Questions: ${businessInfo.commonQuestions || "Not provided"}
      
      ${languageInstructions}
      ${industrySpecificInstructions}
      
      Please respond to the following customer query in a helpful, ${businessInfo.aiResponseStyle || "professional"} tone as if you are speaking on the phone:
      
      "${query}"
      
      Respond directly as the voice assistant without mentioning this prompt. Keep your response conversational and natural as if speaking, not writing.
      Make sure your response sounds like a real-time phone conversation. Use appropriate verbal expressions.
      `;
      
      const result = await model.generateContent(prompt);
      const response = await result.response;
      res.json({ response: response.text() });
    } catch (error) {
      console.error("Error generating AI response:", error);
      res.status(500).json({ error: "Failed to generate AI response" });
    }
  });
  
  // Generate sample dataset endpoint
  app.post("/api/ai/generate-dataset", async (req, res) => {
    try {
      const { businessInfo, count = 10, language = 'en-IN' } = req.body;
      
      if (!businessInfo) {
        return res.status(400).json({ error: "Missing business information" });
      }
      
      // Initialize Gemini API
      const { GoogleGenerativeAI } = require("@google/generative-ai");
      const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY || "");
      const model = genAI.getGenerativeModel({ model: "gemini-pro" });
      
      // Determine language for content generation
      let languageName = "English";
      let languageInstructions = "";
      
      if (language === 'hi-IN') {
        languageName = "Hindi";
        languageInstructions = "Make sure all customer queries are in Hindi language using Devanagari script.";
      } else if (language === 'gu-IN') {
        languageName = "Gujarati";
        languageInstructions = "Make sure all customer queries are in Gujarati language using Gujarati script.";
      } else {
        languageInstructions = "Make sure all customer queries are in English with some Indian English phrases and expressions.";
      }
      
      // Focus on restaurant-specific questions if the business is a restaurant
      const industrySpecificInstructions = businessInfo.industry === "Restaurant/Food" ? 
        `
        Since this is a restaurant, focus on these types of queries:
        - Menu item availability and descriptions
        - Reservation requests for specific dates, times, and party sizes
        - Special dietary requirements (vegetarian, vegan, gluten-free, etc.)
        - Questions about spice levels of dishes
        - Inquiries about business hours and wait times
        - Delivery and takeout options
        - Questions about special offers or thali/combo meals
        - Party/event booking inquiries
        - Complaints about food or service
        - Pricing questions
        ` : "";
      
      const prompt = `
      Generate a dataset of ${count} simulated customer calls for a restaurant business with the following information:
      
      Business Name: ${businessInfo.name || "Aroma Restaurant"}
      Industry: ${businessInfo.industry || "Restaurant/Food"}
      Services: ${businessInfo.services || "North Indian and South Indian cuisine, catering, takeout and delivery services"}
      Business Hours: ${businessInfo.businessHours || "Mon-Sun: 11am-10pm"}
      
      For each call entry, include:
      1. A unique caller phone number (in Indian format +91xxxxxxxxxx)
      2. A timestamp within the last 30 days (format: YYYY-MM-DD HH:MM:SS)
      3. A transcription of what the customer said in ${languageName}
      4. A category (e.g. "Reservation", "Menu Inquiry", "Delivery Order", "Complaint", "Feedback")
      5. A status ("resolved", "pending", "missed")
      
      ${languageInstructions}
      ${industrySpecificInstructions}
      
      Make the customer queries extremely realistic, varied, and natural-sounding as if spoken by real people.
      Include background noise indications and verbal hesitations where appropriate.
      
      Return the data as a JSON array of objects.
      `;
      
      const result = await model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Extract the JSON array from the response
      const jsonMatch = text.match(/\[\s*\{[\s\S]*\}\s*\]/);
      if (jsonMatch) {
        try {
          const dataset = JSON.parse(jsonMatch[0]);
          res.json({ dataset });
        } catch (e) {
          console.error("Error parsing generated dataset:", e);
          res.status(500).json({ error: "Failed to parse dataset" });
        }
      } else {
        res.status(500).json({ error: "Failed to generate dataset in proper format" });
      }
    } catch (error) {
      console.error("Error generating dataset:", error);
      res.status(500).json({ error: "Failed to generate dataset" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);
  return httpServer;
}

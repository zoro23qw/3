import * as admin from 'firebase-admin';
import { Request, Response } from 'express';
import type { Express } from 'express';
import session from 'express-session';
import { storage } from './storage';

// Extend the session to include userId
declare module 'express-session' {
  interface SessionData {
    userId: number;
  }
}

// Initialize Firebase Admin with environment variables
// For local development, we can use a service account key
// For production, we can use the built-in credentials on cloud platforms
let firebaseApp: admin.app.App;

try {
  // Check if an app has already been initialized
  firebaseApp = admin.app();
} catch (error) {
  // Initialize a new app if none exists
  firebaseApp = admin.initializeApp({
    projectId: process.env.FIREBASE_PROJECT_ID,
    storageBucket: process.env.FIREBASE_STORAGE_BUCKET,
  });
}

const auth = firebaseApp.auth();

// Helper function to verify Firebase ID tokens
export async function verifyFirebaseToken(token: string): Promise<admin.auth.DecodedIdToken> {
  try {
    const decodedToken = await auth.verifyIdToken(token);
    return decodedToken;
  } catch (error) {
    console.error('Error verifying Firebase token:', error);
    throw new Error('Invalid or expired authentication token');
  }
}

// Add Firebase authentication routes
export function setupFirebaseAuth(app: Express) {
  // Login with Firebase auth
  app.post('/api/firebase-login', async (req: Request, res: Response) => {
    try {
      const { token } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: 'Missing Firebase token' });
      }
      
      // Verify the token
      const decodedToken = await verifyFirebaseToken(token);
      const { uid, email, name } = decodedToken;
      
      // Check if user exists in our database
      let user = await storage.getUserByFirebaseId(uid);
      
      // If user doesn't exist yet, create them
      if (!user) {
        user = await storage.createUser({
          username: email || uid,
          name: name || 'User',
          email: email || '',
          businessName: '',
          password: '', // Not used with Firebase auth
          firebaseId: uid,
        });
      }
      
      // Set up session
      req.session.userId = user.id;
      
      return res.status(200).json(user);
    } catch (error) {
      console.error('Firebase login error:', error);
      return res.status(401).json({ error: 'Authentication failed' });
    }
  });
  
  // Register with Firebase auth
  app.post('/api/firebase-register', async (req: Request, res: Response) => {
    try {
      const { token, name, email, businessName, phone } = req.body;
      
      if (!token) {
        return res.status(400).json({ error: 'Missing Firebase token' });
      }
      
      // Verify the token
      const decodedToken = await verifyFirebaseToken(token);
      const { uid } = decodedToken;
      
      // Check if user already exists
      const existingUser = await storage.getUserByFirebaseId(uid);
      if (existingUser) {
        return res.status(409).json({ error: 'User already exists' });
      }
      
      // Create new user
      const user = await storage.createUser({
        username: email || uid,
        name: name || 'User',
        email: email || '',
        businessName: businessName || '',
        phoneNumber: phone || null,
        password: '', // Not used with Firebase auth
        firebaseId: uid,
      });
      
      // Set up session
      req.session.userId = user.id;
      
      return res.status(201).json(user);
    } catch (error) {
      console.error('Firebase registration error:', error);
      return res.status(400).json({ error: 'Registration failed' });
    }
  });
  
  // Get user profile with Firebase auth
  app.get('/api/firebase-user', async (req: Request, res: Response) => {
    try {
      const authHeader = req.headers.authorization;
      
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing authentication token' });
      }
      
      const token = authHeader.split('Bearer ')[1];
      const decodedToken = await verifyFirebaseToken(token);
      const { uid } = decodedToken;
      
      // Get user from database
      const user = await storage.getUserByFirebaseId(uid);
      
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }
      
      // Set up session
      req.session.userId = user.id;
      
      return res.status(200).json(user);
    } catch (error) {
      console.error('Error getting Firebase user:', error);
      return res.status(401).json({ error: 'Authentication failed' });
    }
  });
}
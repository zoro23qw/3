import { users, businessInfo, callLogs, userSettings } from "@shared/schema";
import type { User, InsertUser, BusinessInfo, InsertBusinessInfo, CallLog, InsertCallLog, UserSettings, InsertUserSettings } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";
import connectPg from "connect-pg-simple";
import { db, pool, eq, desc } from "./db";

const MemoryStore = createMemoryStore(session);
const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User CRUD operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByFirebaseId(firebaseId: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;
  
  // Business info operations
  getBusinessInfo(userId: number): Promise<BusinessInfo | undefined>;
  createBusinessInfo(info: InsertBusinessInfo): Promise<BusinessInfo>;
  updateBusinessInfo(userId: number, info: Partial<BusinessInfo>): Promise<BusinessInfo | undefined>;
  
  // Call logs operations
  getCallLogs(userId: number): Promise<CallLog[]>;
  createCallLog(log: InsertCallLog): Promise<CallLog>;
  
  // User settings operations
  getUserSettings(userId: number): Promise<UserSettings | undefined>;
  createUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  updateUserSettings(userId: number, settings: Partial<UserSettings>): Promise<UserSettings | undefined>;
  
  // Session store
  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    // Use memory storage for sessions for now
    // We'll switch to PostgreSQL once the issues are fixed
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // Prune expired entries every 24h
    });
    
    // Disabling PostgreSQL session store due to type errors
    // this.sessionStore = new PostgresSessionStore({
    //   pool, 
    //   createTableIfMissing: true,
    //   tableName: 'session' // Standard table name for connect-pg-simple
    // });
  }

  // User CRUD operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }
  
  async getUserByFirebaseId(firebaseId: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.firebaseId, firebaseId));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...insertUser,
      numberConnected: false
    }).returning();
    return user;
  }
  
  async updateUser(id: number, userData: Partial<User>): Promise<User | undefined> {
    const [user] = await db.update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return user;
  }
  
  // Business info operations
  async getBusinessInfo(userId: number): Promise<BusinessInfo | undefined> {
    const [info] = await db.select().from(businessInfo)
      .where(eq(businessInfo.userId, userId));
    return info;
  }
  
  async createBusinessInfo(info: InsertBusinessInfo): Promise<BusinessInfo> {
    const [businessInformation] = await db.insert(businessInfo)
      .values(info)
      .returning();
    return businessInformation;
  }
  
  async updateBusinessInfo(userId: number, infoData: Partial<BusinessInfo>): Promise<BusinessInfo | undefined> {
    const [info] = await db.update(businessInfo)
      .set(infoData)
      .where(eq(businessInfo.userId, userId))
      .returning();
    return info;
  }
  
  // Call logs operations
  async getCallLogs(userId: number): Promise<CallLog[]> {
    return await db.select().from(callLogs)
      .where(eq(callLogs.userId, userId))
      .orderBy(desc(callLogs.timestamp));
  }
  
  async createCallLog(log: InsertCallLog): Promise<CallLog> {
    const [callLog] = await db.insert(callLogs)
      .values(log)
      .returning();
    return callLog;
  }
  
  // User settings operations
  async getUserSettings(userId: number): Promise<UserSettings | undefined> {
    const [settings] = await db.select().from(userSettings)
      .where(eq(userSettings.userId, userId));
    return settings;
  }
  
  async createUserSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const [userSetting] = await db.insert(userSettings)
      .values(settings)
      .returning();
    return userSetting;
  }
  
  async updateUserSettings(userId: number, settingsData: Partial<UserSettings>): Promise<UserSettings | undefined> {
    const [settings] = await db.update(userSettings)
      .set(settingsData)
      .where(eq(userSettings.userId, userId))
      .returning();
    return settings;
  }
}

export const storage = new DatabaseStorage();

import express, { type Express } from 'express';
import webpack, { Configuration } from 'webpack';
import webpackDevMiddleware from 'webpack-dev-middleware';
import webpackHotMiddleware from 'webpack-hot-middleware';
import path, { dirname } from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import { type Server } from 'http';

// Import webpack config
// @ts-ignore - Ignore missing type declaration
import webpackConfigImport from '../webpack.config.js';

// Ensure it has the necessary properties
const webpackConfig: Configuration = {
  ...webpackConfigImport,
  output: webpackConfigImport.output || { publicPath: '/' }
};

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export function log(message: string, source = "express") {
  const formattedTime = new Date().toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  console.log(`${formattedTime} [${source}] ${message}`);
}

export async function setupWebpack(app: Express, server: Server) {
  // Add HMR entry point
  if (Array.isArray(webpackConfig.entry)) {
    webpackConfig.entry.unshift('webpack-hot-middleware/client?reload=true');
  } else if (typeof webpackConfig.entry === 'string') {
    webpackConfig.entry = ['webpack-hot-middleware/client?reload=true', webpackConfig.entry];
  } else {
    webpackConfig.entry = {
      ...webpackConfig.entry,
      client: ['webpack-hot-middleware/client?reload=true', './client/src/main.tsx'],
    };
  }

  // Add HMR plugin
  if (!webpackConfig.plugins) {
    webpackConfig.plugins = [];
  }
  webpackConfig.plugins.push(new webpack.HotModuleReplacementPlugin());

  const compiler = webpack(webpackConfig);

  // Setup webpack dev middleware
  app.use(
    webpackDevMiddleware(compiler, {
      publicPath: webpackConfig.output?.publicPath || '/',
      stats: 'minimal',
    })
  );

  // Setup webpack hot middleware
  app.use(webpackHotMiddleware(compiler));

  // Handle HTML5 routing
  app.use('*', (req, res, next) => {
    const filename = path.join(compiler.outputPath, 'index.html');
    
    if (compiler.outputFileSystem) {
      compiler.outputFileSystem.readFile(filename, (err, result) => {
        if (err) {
          return next(err);
        }
        res.set('content-type', 'text/html');
        res.send(result);
        res.end();
      });
    } else {
      return next(new Error('Webpack compiler outputFileSystem is not available'));
    }
  });
}

export function serveStatic(app: Express) {
  const distPath = path.resolve(__dirname, '../dist/public');

  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`,
    );
  }

  app.use(express.static(distPath));

  // fall through to index.html if the file doesn't exist
  app.use('*', (_req, res) => {
    res.sendFile(path.resolve(distPath, 'index.html'));
  });
}
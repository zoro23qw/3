import { pgTable, text, serial, integer, boolean, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  name: text("name").notNull(),
  businessName: text("business_name").notNull(),
  email: text("email").notNull().unique(),
  phoneNumber: text("phone_number"),
  numberConnected: boolean("number_connected").default(false),
  firebaseId: text("firebase_id").unique(),
});

export const businessInfo = pgTable("business_info", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  industry: text("industry"),
  services: text("services"),
  businessHours: text("business_hours"),
  commonQuestions: text("common_questions"),
  aiResponseStyle: text("ai_response_style").default("formal"),
});

export const callLogs = pgTable("call_logs", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  callerNumber: text("caller_number"),
  timestamp: timestamp("timestamp").defaultNow(),
  transcription: text("transcription"),
  aiResponseQuality: integer("ai_response_quality"),
});

export const userSettings = pgTable("user_settings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  inputLanguage: text("input_language").default("en"),
  outputLanguage: text("output_language").default("en"),
  autoDetectLanguage: boolean("auto_detect_language").default(true),
  aiResponseStyle: text("ai_response_style").default("formal"),
  aiCallHandlingEnabled: boolean("ai_call_handling_enabled").default(true),
  calendarSyncEnabled: boolean("calendar_sync_enabled").default(false),
  hasCompletedTutorial: boolean("has_completed_tutorial").default(false),
});

// Insert schemas
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  name: true,
  businessName: true,
  email: true,
  phoneNumber: true,
  firebaseId: true,
});

export const loginUserSchema = z.object({
  username: z.string().min(1, "Username is required"),
  password: z.string().min(1, "Password is required"),
});

export const insertBusinessInfoSchema = createInsertSchema(businessInfo).omit({ id: true });
export const insertCallLogSchema = createInsertSchema(callLogs).omit({ id: true });
export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({ id: true });

// Types
export type InsertUser = z.infer<typeof insertUserSchema>;
export type LoginUser = z.infer<typeof loginUserSchema>;
export type User = typeof users.$inferSelect;
export type BusinessInfo = typeof businessInfo.$inferSelect;
export type InsertBusinessInfo = z.infer<typeof insertBusinessInfoSchema>;
export type CallLog = typeof callLogs.$inferSelect;
export type InsertCallLog = z.infer<typeof insertCallLogSchema>;
export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;

declare module '../webpack.config.js' {
  import { Configuration } from 'webpack';
  const config: Configuration;
  export default config;
}